import React, { useState, useEffect, useRef } from 'react';
import { Play, Copy, Download, RotateCcw, Settings, Moon, Sun, Code, Terminal, Loader } from 'lucide-react';

interface Language {
  id: string;
  name: string;
  mode: string;
  template: string;
  icon: string;
  jdoodleLanguage: string;
  versionIndex: string;
}

const LANGUAGES: Language[] = [
  {
    id: 'javascript',
    name: 'JavaScript',
    mode: 'javascript',
    jdoodleLanguage: 'nodejs',
    versionIndex: '3',
    template: `// Welcome to CodeRunner
console.log("Hello, World!");

// Try some basic JavaScript
const numbers = [1, 2, 3, 4, 5];
const doubled = numbers.map(n => n * 2);
console.log("Doubled numbers:", doubled);

// Function example
function fibonacci(n) {
  if (n <= 1) return n;
  return fibonacci(n - 1) + fibonacci(n - 2);
}

console.log("Fibonacci(8):", fibonacci(8));`,
    icon: '🟨'
  },
  {
    id: 'python',
    name: 'Python',
    mode: 'python',
    jdoodleLanguage: 'python3',
    versionIndex: '3',
    template: `# Welcome to CodeRunner
print("Hello, World!")

# Try some basic Python
numbers = [1, 2, 3, 4, 5]
doubled = [n * 2 for n in numbers]
print("Doubled numbers:", doubled)

# Function example
def fibonacci(n):
    if n <= 1:
        return n
    return fibonacci(n - 1) + fibonacci(n - 2)

print("Fibonacci(8):", fibonacci(8))`,
    icon: '🐍'
  },
  {
    id: 'c',
    name: 'C',
    mode: 'c',
    jdoodleLanguage: 'c',
    versionIndex: '4',
    template: `#include <stdio.h>

int main() {
    printf("Hello, World!\\n");
    
    // Array example
    int numbers[] = {1, 2, 3, 4, 5};
    int size = sizeof(numbers) / sizeof(numbers[0]);
    
    printf("Original numbers: ");
    for(int i = 0; i < size; i++) {
        printf("%d ", numbers[i]);
    }
    printf("\\n");
    
    printf("Doubled numbers: ");
    for(int i = 0; i < size; i++) {
        printf("%d ", numbers[i] * 2);
    }
    printf("\\n");
    
    return 0;
}`,
    icon: '⚡'
  },
  {
    id: 'cpp',
    name: 'C++',
    mode: 'cpp',
    jdoodleLanguage: 'cpp17',
    versionIndex: '0',
    template: `#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    cout << "Hello, World!" << endl;
    
    // Vector example
    vector<int> numbers = {1, 2, 3, 4, 5};
    vector<int> doubled;
    
    cout << "Original numbers: ";
    for(int num : numbers) {
        cout << num << " ";
        doubled.push_back(num * 2);
    }
    cout << endl;
    
    cout << "Doubled numbers: ";
    for(int num : doubled) {
        cout << num << " ";
    }
    cout << endl;
    
    // Function example
    auto fibonacci = [](int n) -> int {
        if (n <= 1) return n;
        int a = 0, b = 1;
        for(int i = 2; i <= n; i++) {
            int temp = a + b;
            a = b;
            b = temp;
        }
        return b;
    };
    
    cout << "Fibonacci(8): " << fibonacci(8) << endl;
    
    return 0;
}`,
    icon: '🔷'
  },
  {
    id: 'java',
    name: 'Java',
    mode: 'java',
    jdoodleLanguage: 'java',
    versionIndex: '3',
    template: `public class Main {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
        
        // Array example
        int[] numbers = {1, 2, 3, 4, 5};
        
        System.out.print("Original numbers: ");
        for(int num : numbers) {
            System.out.print(num + " ");
        }
        System.out.println();
        
        System.out.print("Doubled numbers: ");
        for(int num : numbers) {
            System.out.print((num * 2) + " ");
        }
        System.out.println();
        
        // Function example
        System.out.println("Fibonacci(8): " + fibonacci(8));
    }
    
    public static int fibonacci(int n) {
        if (n <= 1) return n;
        return fibonacci(n - 1) + fibonacci(n - 2);
    }
}`,
    icon: '☕'
  },
  {
    id: 'html',
    name: 'HTML/CSS',
    mode: 'html',
    jdoodleLanguage: '',
    versionIndex: '',
    template: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CodeRunner HTML</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            min-height: 100vh;
        }
        .container {
            background: rgba(255, 255, 255, 0.1);
            padding: 30px;
            border-radius: 15px;
            backdrop-filter: blur(10px);
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
        }
        .feature {
            margin: 20px 0;
            padding: 15px;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 8px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🚀 Welcome to CodeRunner</h1>
        <div class="feature">
            <h3>✨ Modern Code Editor</h3>
            <p>Write and execute code with syntax highlighting</p>
        </div>
        <div class="feature">
            <h3>🌐 Multiple Languages</h3>
            <p>Support for JavaScript, Python, C, C++, Java and more</p>
        </div>
        <div class="feature">
            <h3>⚡ Real-time Execution</h3>
            <p>See your code results instantly</p>
        </div>
    </div>
</body>
</html>`,
    icon: '🌐'
  }
];

function App() {
  const [selectedLanguage, setSelectedLanguage] = useState<Language>(LANGUAGES[0]);
  const [code, setCode] = useState(LANGUAGES[0].template);
  const [output, setOutput] = useState('');
  const [isRunning, setIsRunning] = useState(false);
  const [isDarkTheme, setIsDarkTheme] = useState(true);
  const [isOutputVisible, setIsOutputVisible] = useState(true);
  const [stdin, setStdin] = useState('');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    // Load saved code from localStorage
    const savedCode = localStorage.getItem(`code-${selectedLanguage.id}`);
    if (savedCode) {
      setCode(savedCode);
    } else {
      setCode(selectedLanguage.template);
    }
  }, [selectedLanguage]);

  useEffect(() => {
    // Save code to localStorage
    localStorage.setItem(`code-${selectedLanguage.id}`, code);
  }, [code, selectedLanguage.id]);

  const handleLanguageChange = (language: Language) => {
    setSelectedLanguage(language);
    setOutput('');
    setStdin('');
  };

  const executeCode = async () => {
    setIsRunning(true);
    setOutput('Executing code...\n');
    
    try {
      if (selectedLanguage.id === 'html') {
        // For HTML, show a preview
        setOutput('HTML code is ready to preview. The webpage will be rendered above.');
        setIsRunning(false);
        return;
      }

      // Use JDoodle API for code execution
      const response = await fetch('https://api.jdoodle.com/v1/execute', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          clientId: 'aaadf7c16703c5d0f547f55cd1be4cda',
          clientSecret: 'a660f6d03960e638a1b217da30d9b270bd6876873c992a36a47e681b390d5cfe',
          script: code,
          stdin: stdin,
          language: selectedLanguage.jdoodleLanguage,
          versionIndex: selectedLanguage.versionIndex,
          compileOnly: false
        })
      });

      const result = await response.json();
      
      if (result.error) {
        setOutput(`Error: ${result.error}`);
      } else {
        let outputText = '';
        if (result.output) {
          outputText += result.output;
        }
        if (result.statusCode && result.statusCode !== 200) {
          outputText += `\nExit Code: ${result.statusCode}`;
        }
        if (result.memory) {
          outputText += `\nMemory: ${result.memory} KB`;
        }
        if (result.cpuTime) {
          outputText += `\nCPU Time: ${result.cpuTime}s`;
        }
        
        setOutput(outputText || 'Code executed successfully (no output)');
      }
    } catch (error) {
      setOutput(`Network Error: ${error.message}\n\nPlease check your internet connection and try again.`);
    }

    setIsRunning(false);
  };

  const clearCode = () => {
    setCode('');
    setOutput('');
  };

  const resetToTemplate = () => {
    setCode(selectedLanguage.template);
    setOutput('');
  };

  const copyCode = () => {
    navigator.clipboard.writeText(code);
  };

  const downloadCode = () => {
    const extensions = {
      javascript: 'js',
      python: 'py',
      c: 'c',
      cpp: 'cpp',
      java: 'java',
      html: 'html'
    };
    
    const extension = extensions[selectedLanguage.id] || 'txt';
    const blob = new Blob([code], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `code.${extension}`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const insertTab = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Tab') {
      e.preventDefault();
      const textarea = e.currentTarget;
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      const newValue = code.substring(0, start) + '  ' + code.substring(end);
      setCode(newValue);
      
      setTimeout(() => {
        textarea.selectionStart = textarea.selectionEnd = start + 2;
      }, 0);
    }
  };

  const themeClasses = isDarkTheme 
    ? 'bg-gray-900 text-white' 
    : 'bg-gray-100 text-gray-900';

  const editorTheme = isDarkTheme 
    ? 'bg-gray-800 text-green-400 border-gray-700' 
    : 'bg-white text-gray-900 border-gray-300';

  const outputTheme = isDarkTheme 
    ? 'bg-gray-800 text-gray-100 border-gray-700' 
    : 'bg-gray-50 text-gray-900 border-gray-300';

  return (
    <div className={`min-h-screen ${themeClasses} transition-colors duration-300`}>
      {/* Header */}
      <header className={`border-b ${isDarkTheme ? 'border-gray-800' : 'border-gray-200'} px-6 py-4`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Code className="h-8 w-8 text-blue-500" />
              <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-500 to-purple-600 bg-clip-text text-transparent">
                CodeRunner
              </h1>
            </div>
            
            {/* Language Selector */}
            <div className="flex items-center space-x-2">
              <select
                value={selectedLanguage.id}
                onChange={(e) => {
                  const lang = LANGUAGES.find(l => l.id === e.target.value);
                  if (lang) handleLanguageChange(lang);
                }}
                className={`px-3 py-2 rounded-lg border ${editorTheme} focus:ring-2 focus:ring-blue-500 focus:border-transparent`}
              >
                {LANGUAGES.map(lang => (
                  <option key={lang.id} value={lang.id}>
                    {lang.icon} {lang.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            {/* Action Buttons */}
            <button
              onClick={executeCode}
              disabled={isRunning}
              className="flex items-center space-x-2 px-4 py-2 bg-green-600 hover:bg-green-700 disabled:bg-green-800 text-white rounded-lg transition-colors duration-200 disabled:cursor-not-allowed"
            >
              {isRunning ? <Loader className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}
              <span>{isRunning ? 'Running...' : 'Run'}</span>
            </button>

            <button
              onClick={copyCode}
              className={`p-2 rounded-lg border ${isDarkTheme ? 'border-gray-700 hover:bg-gray-800' : 'border-gray-300 hover:bg-gray-200'} transition-colors duration-200`}
              title="Copy Code"
            >
              <Copy className="h-4 w-4" />
            </button>

            <button
              onClick={downloadCode}
              className={`p-2 rounded-lg border ${isDarkTheme ? 'border-gray-700 hover:bg-gray-800' : 'border-gray-300 hover:bg-gray-200'} transition-colors duration-200`}
              title="Download Code"
            >
              <Download className="h-4 w-4" />
            </button>

            <button
              onClick={resetToTemplate}
              className={`p-2 rounded-lg border ${isDarkTheme ? 'border-gray-700 hover:bg-gray-800' : 'border-gray-300 hover:bg-gray-200'} transition-colors duration-200`}
              title="Reset to Template"
            >
              <RotateCcw className="h-4 w-4" />
            </button>

            <button
              onClick={() => setIsDarkTheme(!isDarkTheme)}
              className={`p-2 rounded-lg border ${isDarkTheme ? 'border-gray-700 hover:bg-gray-800' : 'border-gray-300 hover:bg-gray-200'} transition-colors duration-200`}
              title="Toggle Theme"
            >
              {isDarkTheme ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex flex-1 h-[calc(100vh-80px)]">
        {/* Code Editor */}
        <div className="flex-1 flex flex-col">
          <div className={`px-4 py-2 border-b ${isDarkTheme ? 'border-gray-800' : 'border-gray-200'} flex items-center justify-between`}>
            <h2 className="font-semibold flex items-center space-x-2">
              <span>{selectedLanguage.icon}</span>
              <span>{selectedLanguage.name} Editor</span>
            </h2>
            <div className="flex items-center space-x-2">
              <button
                onClick={clearCode}
                className="text-sm px-3 py-1 rounded bg-red-600 hover:bg-red-700 text-white transition-colors duration-200"
              >
                Clear
              </button>
            </div>
          </div>
          
          <div className="flex-1 p-4">
            <textarea
              ref={textareaRef}
              value={code}
              onChange={(e) => setCode(e.target.value)}
              onKeyDown={insertTab}
              className={`w-full h-full ${editorTheme} rounded-lg border p-4 font-mono text-sm resize-none focus:ring-2 focus:ring-blue-500 focus:border-transparent`}
              placeholder={`Write your ${selectedLanguage.name} code here...`}
              spellCheck={false}
              style={{
                lineHeight: '1.5',
                tabSize: 2
              }}
            />
          </div>

          {/* Input Section for languages that support stdin */}
          {selectedLanguage.id !== 'html' && (
            <div className={`border-t ${isDarkTheme ? 'border-gray-800' : 'border-gray-200'} p-4`}>
              <label className="block text-sm font-medium mb-2">
                Input (stdin):
              </label>
              <textarea
                value={stdin}
                onChange={(e) => setStdin(e.target.value)}
                className={`w-full h-20 ${editorTheme} rounded-lg border p-3 text-sm resize-none focus:ring-2 focus:ring-blue-500 focus:border-transparent`}
                placeholder="Enter input for your program here..."
              />
            </div>
          )}
        </div>

        {/* Output Panel */}
        <div className={`w-1/2 border-l ${isDarkTheme ? 'border-gray-800' : 'border-gray-200'}`}>
          <div className={`px-4 py-2 border-b ${isDarkTheme ? 'border-gray-800' : 'border-gray-200'} flex items-center justify-between`}>
            <h2 className="font-semibold flex items-center space-x-2">
              <Terminal className="h-4 w-4" />
              <span>Output</span>
            </h2>
            <button
              onClick={() => setIsOutputVisible(!isOutputVisible)}
              className="text-sm px-3 py-1 rounded bg-blue-600 hover:bg-blue-700 text-white transition-colors duration-200"
            >
              {isOutputVisible ? 'Hide' : 'Show'}
            </button>
          </div>
          
          {isOutputVisible && (
            <div className="h-full p-4">
              {selectedLanguage.id === 'html' && code.includes('<!DOCTYPE html') ? (
                <div className="h-full">
                  <div className="mb-4">
                    <h3 className="text-sm font-semibold mb-2">Live Preview:</h3>
                    <iframe
                      srcDoc={code}
                      className="w-full border rounded-lg"
                      style={{ height: '60%' }}
                      title="HTML Preview"
                    />
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold mb-2">Console Output:</h3>
                    <pre className={`${outputTheme} rounded-lg border p-4 text-sm font-mono overflow-auto`} style={{ height: '30%' }}>
                      {output || 'Run your HTML code to see the preview above'}
                    </pre>
                  </div>
                </div>
              ) : (
                <pre className={`w-full h-[calc(100%-20px)] ${outputTheme} rounded-lg border p-4 text-sm font-mono overflow-auto whitespace-pre-wrap`}>
                  {output || 'Run your code to see the output here...'}
                </pre>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;