import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Image, Alert, Linking, Platform } from 'react-native';
import { useTheme } from '@/contexts/ThemeContext';
import { useAuth } from '@/contexts/AuthContext';
import { CartItem } from '@/types';
import { fetchCartItems, removeFromCart, clearCart } from '@/services/cartService';
import { Trash2, ShoppingBag, TriangleAlert as AlertTriangle } from 'lucide-react-native';

export default function CartScreen() {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [loading, setLoading] = useState(true);
  const { theme } = useTheme();
  const { user } = useAuth();
  
  const styles = getStyles(theme);

  useEffect(() => {
    loadCartItems();
  }, []);

  const loadCartItems = async () => {
    try {
      setLoading(true);
      if (!user?.id) return;
      
      const items = await fetchCartItems(user.id);
      setCartItems(items);
    } catch (error) {
      console.error('Error loading cart items:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleRemoveItem = async (itemId: string) => {
    try {
      if (!user?.id) return;
      await removeFromCart(user.id, itemId);
      setCartItems(cartItems.filter(item => item.id !== itemId));
    } catch (error) {
      console.error('Error removing item from cart:', error);
    }
  };

  const calculateTotal = () => {
    return cartItems.reduce((total, item) => total + item.price, 0);
  };

  const handleCheckout = async () => {
    if (cartItems.length === 0) {
      Alert.alert('Carrinho vazio', 'Adicione itens ao seu carrinho para continuar.');
      return;
    }

    try {
      // Format the WhatsApp message with all cart items
      const total = calculateTotal();
      const message = `Olá! Estou interessado em comprar os seguintes scripts:\n\n${cartItems.map(item => `- ${item.title} (AOA ${item.price.toLocaleString()})`).join('\n')}\n\nTotal: AOA ${total.toLocaleString()}\n\nPor favor, confirme meu pedido e me envie instruções para pagamento.`;
      const encodedMessage = encodeURIComponent(message);
      const whatsappNumber = '+244123456789'; // Replace with the actual WhatsApp number
      
      // Open WhatsApp with pre-filled message
      const whatsappUrl = `whatsapp://send?phone=${whatsappNumber}&text=${encodedMessage}`;
      const canOpen = await Linking.canOpenURL(whatsappUrl);
      
      if (canOpen) {
        await Linking.openURL(whatsappUrl);
        // Clear cart after successful checkout
        if (user?.id) {
          await clearCart(user.id);
          setCartItems([]);
        }
      } else {
        Alert.alert(
          'WhatsApp não encontrado',
          'Por favor, instale o WhatsApp para continuar com o checkout.',
          [
            { 
              text: 'OK', 
              style: 'cancel' 
            }
          ]
        );
      }
    } catch (error) {
      console.error('Error during checkout:', error);
      Alert.alert('Erro', 'Ocorreu um erro ao processar seu pedido. Por favor, tente novamente.');
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Meu Carrinho</Text>
      </View>

      {cartItems.length === 0 ? (
        <View style={styles.emptyContainer}>
          <ShoppingBag size={60} color={theme === 'dark' ? '#555' : '#ddd'} />
          <Text style={styles.emptyText}>Seu carrinho está vazio</Text>
          <Text style={styles.emptySubText}>Explore nossa coleção de scripts e adicione alguns ao seu carrinho</Text>
        </View>
      ) : (
        <>
          <FlatList
            data={cartItems}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <View style={styles.cartItem}>
                <Image 
                  source={{ uri: item.imageUrl || 'https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg' }} 
                  style={styles.itemImage}
                />
                <View style={styles.itemInfo}>
                  <Text style={styles.itemTitle}>{item.title}</Text>
                  <Text style={styles.itemCategory}>{item.category}</Text>
                  <Text style={styles.itemPrice}>AOA {item.price.toLocaleString()}</Text>
                </View>
                <TouchableOpacity 
                  style={styles.removeButton}
                  onPress={() => handleRemoveItem(item.id)}
                >
                  <Trash2 size={20} color="#e74c3c" />
                </TouchableOpacity>
              </View>
            )}
            contentContainerStyle={styles.listContainer}
          />

          <View style={styles.summaryContainer}>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>Total</Text>
              <Text style={styles.summaryValue}>AOA {calculateTotal().toLocaleString()}</Text>
            </View>

            <View style={styles.warningContainer}>
              <AlertTriangle size={16} color="#f59e0b" style={{ marginRight: 8 }} />
              <Text style={styles.warningText}>O pagamento será confirmado pelo WhatsApp</Text>
            </View>

            <TouchableOpacity 
              style={styles.checkoutButton}
              onPress={handleCheckout}
            >
              <Text style={styles.checkoutButtonText}>Finalizar Compra via WhatsApp</Text>
            </TouchableOpacity>
          </View>
        </>
      )}
    </View>
  );
}

const getStyles = (theme: 'light' | 'dark') => StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme === 'dark' ? '#121212' : '#f7f7f7',
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 16,
    backgroundColor: theme === 'dark' ? '#1a1a1a' : '#fff',
  },
  headerTitle: {
    fontFamily: 'Poppins-Bold',
    fontSize: 24,
    color: theme === 'dark' ? '#fff' : '#333',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  emptyText: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 18,
    color: theme === 'dark' ? '#e0e0e0' : '#555',
    marginTop: 16,
  },
  emptySubText: {
    fontFamily: 'WorkSans-Regular',
    fontSize: 14,
    color: theme === 'dark' ? '#a0a0a0' : '#777',
    textAlign: 'center',
    marginTop: 8,
    maxWidth: '80%',
  },
  listContainer: {
    padding: 16,
  },
  cartItem: {
    flexDirection: 'row',
    backgroundColor: theme === 'dark' ? '#1a1a1a' : '#fff',
    borderRadius: 12,
    marginBottom: 16,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  itemImage: {
    width: 90,
    height: 90,
    resizeMode: 'cover',
  },
  itemInfo: {
    flex: 1,
    padding: 12,
    justifyContent: 'space-between',
  },
  itemTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 16,
    color: theme === 'dark' ? '#fff' : '#333',
  },
  itemCategory: {
    fontFamily: 'WorkSans-Regular',
    fontSize: 12,
    color: theme === 'dark' ? '#a0a0a0' : '#777',
    marginVertical: 4,
  },
  itemPrice: {
    fontFamily: 'Poppins-Medium',
    fontSize: 16,
    color: '#1E3A8A',
  },
  removeButton: {
    padding: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  summaryContainer: {
    backgroundColor: theme === 'dark' ? '#1a1a1a' : '#fff',
    padding: 16,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -3 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 5,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  summaryLabel: {
    fontFamily: 'WorkSans-Regular',
    fontSize: 16,
    color: theme === 'dark' ? '#e0e0e0' : '#555',
  },
  summaryValue: {
    fontFamily: 'Poppins-Bold',
    fontSize: 20,
    color: theme === 'dark' ? '#fff' : '#333',
  },
  warningContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme === 'dark' ? '#392f00' : '#fff9e6',
    padding: 12,
    borderRadius: 8,
    marginBottom: 16,
  },
  warningText: {
    fontFamily: 'WorkSans-Regular',
    fontSize: 12,
    color: theme === 'dark' ? '#f0b429' : '#b45309',
    flex: 1,
  },
  checkoutButton: {
    backgroundColor: '#1E3A8A',
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkoutButtonText: {
    fontFamily: 'WorkSans-SemiBold',
    color: 'white',
    fontSize: 16,
  },
});