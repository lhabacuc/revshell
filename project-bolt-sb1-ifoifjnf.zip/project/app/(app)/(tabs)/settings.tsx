import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Switch, ScrollView, Alert, ActivityIndicator } from 'react-native';
import { useRouter } from 'expo-router';
import { useTheme } from '@/contexts/ThemeContext';
import { useAuth } from '@/contexts/AuthContext';
import { updateUserProfile } from '@/services/userService';
import { User, Moon, Sun, LogOut, ChevronRight } from 'lucide-react-native';

export default function SettingsScreen() {
  const { user, signOut } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  
  const styles = getStyles(theme);

  const handleSignOut = async () => {
    Alert.alert(
      'Sair da conta',
      'Tem certeza que deseja sair?',
      [
        {
          text: 'Cancelar',
          style: 'cancel',
        },
        {
          text: 'Sair',
          style: 'destructive',
          onPress: async () => {
            try {
              await signOut();
              router.replace('/(auth)');
            } catch (error) {
              console.error('Error signing out:', error);
            }
          },
        },
      ]
    );
  };

  const handleDeleteAccount = () => {
    Alert.alert(
      'Excluir conta',
      'Esta ação não pode ser desfeita. Todos os seus dados serão perdidos permanentemente.',
      [
        {
          text: 'Cancelar',
          style: 'cancel',
        },
        {
          text: 'Excluir',
          style: 'destructive',
          onPress: () => {
            // TODO: Implement account deletion
            Alert.alert('Funcionalidade em desenvolvimento', 'Esta funcionalidade estará disponível em breve.');
          },
        },
      ]
    );
  };

  const handleToggleTheme = () => {
    toggleTheme();
  };

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleDateString('pt-AO', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Configurações</Text>
      </View>

      <View style={styles.profileSection}>
        <View style={styles.profileIcon}>
          <User size={32} color={theme === 'dark' ? '#fff' : '#333'} />
        </View>
        <View style={styles.profileInfo}>
          <Text style={styles.profileName}>{user?.displayName || 'Usuário'}</Text>
          <Text style={styles.profileEmail}>{user?.email}</Text>
          {user?.createdAt && (
            <Text style={styles.memberSince}>
              Membro desde {formatDate(user.createdAt)}
            </Text>
          )}
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Preferências</Text>
        
        <View style={styles.settingItem}>
          <View style={styles.settingItemLeft}>
            {theme === 'dark' ? <Moon size={20} color="#a0a0a0" /> : <Sun size={20} color="#555" />}
            <Text style={styles.settingText}>Modo Escuro</Text>
          </View>
          <Switch
            value={theme === 'dark'}
            onValueChange={handleToggleTheme}
            trackColor={{ false: '#767577', true: '#1E3A8A' }}
            thumbColor={theme === 'dark' ? '#f5f5f5' : '#f4f3f4'}
          />
        </View>

        <TouchableOpacity style={styles.settingItem}>
          <View style={styles.settingItemLeft}>
            <Text style={styles.settingText}>Notificações</Text>
          </View>
          <ChevronRight size={20} color={theme === 'dark' ? '#a0a0a0' : '#555'} />
        </TouchableOpacity>

        <TouchableOpacity style={styles.settingItem}>
          <View style={styles.settingItemLeft}>
            <Text style={styles.settingText}>Idioma</Text>
          </View>
          <View style={styles.settingItemRight}>
            <Text style={styles.settingValueText}>Português</Text>
            <ChevronRight size={20} color={theme === 'dark' ? '#a0a0a0' : '#555'} />
          </View>
        </TouchableOpacity>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Conta</Text>
        
        <TouchableOpacity style={styles.settingItem}>
          <View style={styles.settingItemLeft}>
            <Text style={styles.settingText}>Dados Pessoais</Text>
          </View>
          <ChevronRight size={20} color={theme === 'dark' ? '#a0a0a0' : '#555'} />
        </TouchableOpacity>

        <TouchableOpacity style={styles.settingItem}>
          <View style={styles.settingItemLeft}>
            <Text style={styles.settingText}>Segurança</Text>
          </View>
          <ChevronRight size={20} color={theme === 'dark' ? '#a0a0a0' : '#555'} />
        </TouchableOpacity>

        <TouchableOpacity style={styles.settingItem} onPress={handleSignOut}>
          <View style={styles.settingItemLeft}>
            <LogOut size={20} color="#e74c3c" />
            <Text style={[styles.settingText, styles.logoutText]}>Sair da Conta</Text>
          </View>
        </TouchableOpacity>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Sobre</Text>
        
        <TouchableOpacity style={styles.settingItem}>
          <View style={styles.settingItemLeft}>
            <Text style={styles.settingText}>Termos de Serviço</Text>
          </View>
          <ChevronRight size={20} color={theme === 'dark' ? '#a0a0a0' : '#555'} />
        </TouchableOpacity>

        <TouchableOpacity style={styles.settingItem}>
          <View style={styles.settingItemLeft}>
            <Text style={styles.settingText}>Política de Privacidade</Text>
          </View>
          <ChevronRight size={20} color={theme === 'dark' ? '#a0a0a0' : '#555'} />
        </TouchableOpacity>

        <TouchableOpacity style={styles.settingItem}>
          <View style={styles.settingItemLeft}>
            <Text style={styles.settingText}>Versão do App</Text>
          </View>
          <Text style={styles.versionText}>1.0.0</Text>
        </TouchableOpacity>
      </View>

      <TouchableOpacity 
        style={styles.deleteAccountButton}
        onPress={handleDeleteAccount}
      >
        <Text style={styles.deleteAccountText}>Excluir minha conta</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const getStyles = (theme: 'light' | 'dark') => StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme === 'dark' ? '#121212' : '#f7f7f7',
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 16,
    backgroundColor: theme === 'dark' ? '#1a1a1a' : '#fff',
  },
  headerTitle: {
    fontFamily: 'Poppins-Bold',
    fontSize: 24,
    color: theme === 'dark' ? '#fff' : '#333',
  },
  profileSection: {
    backgroundColor: theme === 'dark' ? '#1a1a1a' : '#fff',
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  profileIcon: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: theme === 'dark' ? '#333' : '#f0f0f0',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  profileInfo: {
    flex: 1,
  },
  profileName: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 18,
    color: theme === 'dark' ? '#fff' : '#333',
    marginBottom: 4,
  },
  profileEmail: {
    fontFamily: 'WorkSans-Regular',
    fontSize: 14,
    color: theme === 'dark' ? '#b0b0b0' : '#666',
    marginBottom: 4,
  },
  memberSince: {
    fontFamily: 'WorkSans-Regular',
    fontSize: 12,
    color: theme === 'dark' ? '#a0a0a0' : '#888',
  },
  section: {
    backgroundColor: theme === 'dark' ? '#1a1a1a' : '#fff',
    borderRadius: 12,
    marginHorizontal: 16,
    marginBottom: 16,
    overflow: 'hidden',
  },
  sectionTitle: {
    fontFamily: 'WorkSans-Medium',
    fontSize: 16,
    color: theme === 'dark' ? '#e0e0e0' : '#555',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: theme === 'dark' ? '#333' : '#eee',
  },
  settingItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 16,
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderBottomColor: theme === 'dark' ? '#333' : '#eee',
  },
  settingItemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  settingItemRight: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  settingText: {
    fontFamily: 'WorkSans-Regular',
    fontSize: 16,
    color: theme === 'dark' ? '#e0e0e0' : '#333',
    marginLeft: 12,
  },
  settingValueText: {
    fontFamily: 'WorkSans-Regular',
    fontSize: 14,
    color: theme === 'dark' ? '#a0a0a0' : '#888',
    marginRight: 8,
  },
  logoutText: {
    color: '#e74c3c',
  },
  versionText: {
    fontFamily: 'WorkSans-Regular',
    fontSize: 14,
    color: theme === 'dark' ? '#a0a0a0' : '#888',
  },
  deleteAccountButton: {
    backgroundColor: 'transparent',
    padding: 16,
    alignItems: 'center',
    marginTop: 8,
    marginBottom: 32,
  },
  deleteAccountText: {
    fontFamily: 'WorkSans-Medium',
    fontSize: 14,
    color: '#e74c3c',
  },
});