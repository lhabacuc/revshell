import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image, ActivityIndicator, RefreshControl } from 'react-native';
import { useRouter } from 'expo-router';
import { useTheme } from '@/contexts/ThemeContext';
import { fetchScripts } from '@/services/scriptService';
import { Script } from '@/types';
import { Search, Filter } from 'lucide-react-native';

export default function HomeScreen() {
  const [scripts, setScripts] = useState<Script[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();
  const { theme } = useTheme();
  
  const styles = getStyles(theme);

  const loadScripts = async () => {
    try {
      setError(null);
      const data = await fetchScripts();
      setScripts(data);
    } catch (err) {
      console.error('Error fetching scripts:', err);
      setError('Erro ao carregar scripts. Por favor, tente novamente.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadScripts();
  }, []);

  const onRefresh = () => {
    setRefreshing(true);
    loadScripts();
  };

  const handleScriptPress = (id: string) => {
    router.push(`/script/${id}`);
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#1E3A8A" />
        <Text style={styles.loadingText}>Carregando scripts...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Script Angola</Text>
        <View style={styles.searchContainer}>
          <TouchableOpacity style={styles.searchButton}>
            <Search size={20} color={theme === 'dark' ? '#fff' : '#333'} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.filterButton}>
            <Filter size={20} color={theme === 'dark' ? '#fff' : '#333'} />
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.featuredContainer}>
        <Image 
          source={{ uri: 'https://images.pexels.com/photos/2004161/pexels-photo-2004161.jpeg' }} 
          style={styles.featuredImage}
        />
        <View style={styles.featuredOverlay}>
          <Text style={styles.featuredTitle}>Scripts Premium</Text>
          <Text style={styles.featuredSubtitle}>Soluções de código para profissionais angolanos</Text>
        </View>
      </View>

      <View style={styles.categoryContainer}>
        <TouchableOpacity style={styles.categoryItem}>
          <Text style={styles.categoryText}>Todos</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.categoryItem}>
          <Text style={styles.categoryText}>Web</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.categoryItem}>
          <Text style={styles.categoryText}>Mobile</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.categoryItem}>
          <Text style={styles.categoryText}>Desktop</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.categoryItem}>
          <Text style={styles.categoryText}>APIs</Text>
        </TouchableOpacity>
      </View>

      {error ? (
        <View style={styles.errorContainer}>
          <Text style={styles.errorText}>{error}</Text>
          <TouchableOpacity style={styles.retryButton} onPress={loadScripts}>
            <Text style={styles.retryButtonText}>Tentar Novamente</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <ScrollView 
          style={styles.scriptsContainer}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
          }
        >
          {scripts.length === 0 ? (
            <Text style={styles.noScriptsText}>Nenhum script disponível no momento.</Text>
          ) : (
            scripts.map((script) => (
              <TouchableOpacity
                key={script.id}
                style={styles.scriptCard}
                onPress={() => handleScriptPress(script.id)}
              >
                <Image 
                  source={{ uri: script.imageUrl || 'https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg' }} 
                  style={styles.scriptImage}
                />
                <View style={styles.scriptInfo}>
                  <Text style={styles.scriptTitle}>{script.title}</Text>
                  <Text style={styles.scriptDescription} numberOfLines={2}>
                    {script.description}
                  </Text>
                  <View style={styles.scriptFooter}>
                    <Text style={styles.scriptPrice}>AOA {script.price.toLocaleString()}</Text>
                    <Text style={styles.scriptCategory}>{script.category}</Text>
                  </View>
                </View>
              </TouchableOpacity>
            ))
          )}
        </ScrollView>
      )}
    </View>
  );
}

const getStyles = (theme: 'light' | 'dark') => StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme === 'dark' ? '#121212' : '#f7f7f7',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: theme === 'dark' ? '#121212' : '#f7f7f7',
  },
  loadingText: {
    fontFamily: 'WorkSans-Medium',
    marginTop: 12,
    color: theme === 'dark' ? '#e0e0e0' : '#555',
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: theme === 'dark' ? '#1a1a1a' : '#fff',
  },
  headerTitle: {
    fontFamily: 'Poppins-Bold',
    fontSize: 24,
    color: theme === 'dark' ? '#fff' : '#333',
  },
  searchContainer: {
    flexDirection: 'row',
  },
  searchButton: {
    marginRight: 12,
    backgroundColor: theme === 'dark' ? '#333' : '#f0f0f0',
    padding: 8,
    borderRadius: 8,
  },
  filterButton: {
    backgroundColor: theme === 'dark' ? '#333' : '#f0f0f0',
    padding: 8,
    borderRadius: 8,
  },
  featuredContainer: {
    height: 180,
    marginBottom: 16,
    position: 'relative',
  },
  featuredImage: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  featuredOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
    padding: 16,
  },
  featuredTitle: {
    fontFamily: 'Poppins-Bold',
    fontSize: 22,
    color: '#fff',
  },
  featuredSubtitle: {
    fontFamily: 'WorkSans-Regular',
    fontSize: 14,
    color: '#f0f0f0',
    marginTop: 4,
  },
  categoryContainer: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    marginBottom: 16,
    overflow: 'scroll',
  },
  categoryItem: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: theme === 'dark' ? '#333' : '#fff',
    borderRadius: 20,
    marginRight: 10,
    borderWidth: 1,
    borderColor: theme === 'dark' ? '#444' : '#eee',
  },
  categoryText: {
    fontFamily: 'WorkSans-Medium',
    color: theme === 'dark' ? '#e0e0e0' : '#555',
  },
  scriptsContainer: {
    paddingHorizontal: 16,
  },
  scriptCard: {
    backgroundColor: theme === 'dark' ? '#1a1a1a' : '#fff',
    borderRadius: 12,
    marginBottom: 16,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  scriptImage: {
    height: 160,
    width: '100%',
    resizeMode: 'cover',
  },
  scriptInfo: {
    padding: 16,
  },
  scriptTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 18,
    color: theme === 'dark' ? '#fff' : '#333',
    marginBottom: 8,
  },
  scriptDescription: {
    fontFamily: 'WorkSans-Regular',
    fontSize: 14,
    color: theme === 'dark' ? '#b0b0b0' : '#666',
    marginBottom: 12,
    lineHeight: 20,
  },
  scriptFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 8,
  },
  scriptPrice: {
    fontFamily: 'Poppins-Bold',
    fontSize: 16,
    color: '#1E3A8A',
  },
  scriptCategory: {
    fontFamily: 'WorkSans-Medium',
    fontSize: 12,
    color: theme === 'dark' ? '#a0a0a0' : '#888',
    backgroundColor: theme === 'dark' ? '#333' : '#f0f0f0',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  errorContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  errorText: {
    fontFamily: 'WorkSans-Regular',
    fontSize: 16,
    color: '#e74c3c',
    textAlign: 'center',
    marginBottom: 16,
  },
  retryButton: {
    backgroundColor: '#1E3A8A',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 8,
  },
  retryButtonText: {
    fontFamily: 'WorkSans-Medium',
    color: 'white',
    fontSize: 14,
  },
  noScriptsText: {
    fontFamily: 'WorkSans-Regular',
    textAlign: 'center',
    marginTop: 40,
    fontSize: 16,
    color: theme === 'dark' ? '#e0e0e0' : '#555',
  },
});