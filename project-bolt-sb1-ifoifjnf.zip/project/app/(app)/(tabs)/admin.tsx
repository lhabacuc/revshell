import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, Alert, ActivityIndicator } from 'react-native';
import { useRouter } from 'expo-router';
import { useTheme } from '@/contexts/ThemeContext';
import { useAuth } from '@/contexts/AuthContext';
import { Script } from '@/types';
import { fetchScripts, deleteScript } from '@/services/scriptService';
import { CirclePlus as PlusCircle, CreditCard as Edit, Trash2, Key, BookOpen } from 'lucide-react-native';

export default function AdminScreen() {
  const [scripts, setScripts] = useState<Script[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { theme } = useTheme();
  const { user } = useAuth();
  const router = useRouter();
  
  const styles = getStyles(theme);

  // Check if user is admin, if not redirect
  useEffect(() => {
    if (user?.role !== 'admin') {
      router.replace('/(app)/(tabs)');
    }
  }, [user, router]);

  useEffect(() => {
    loadScripts();
  }, []);

  const loadScripts = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await fetchScripts();
      setScripts(data);
    } catch (err) {
      console.error('Error fetching scripts:', err);
      setError('Erro ao carregar scripts. Por favor, tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  const handleAddScript = () => {
    router.push('/admin/add-script');
  };

  const handleEditScript = (scriptId: string) => {
    router.push(`/admin/add-script?id=${scriptId}`);
  };

  const handleDeleteScript = (scriptId: string) => {
    Alert.alert(
      'Excluir Script',
      'Tem certeza que deseja excluir este script? Esta ação não pode ser desfeita.',
      [
        {
          text: 'Cancelar',
          style: 'cancel',
        },
        {
          text: 'Excluir',
          style: 'destructive',
          onPress: async () => {
            try {
              await deleteScript(scriptId);
              setScripts(scripts.filter(script => script.id !== scriptId));
            } catch (error) {
              console.error('Error deleting script:', error);
              Alert.alert('Erro', 'Ocorreu um erro ao excluir o script.');
            }
          },
        },
      ]
    );
  };

  const handleManageKeys = () => {
    router.push('/admin/keys');
  };

  const handleManageRules = () => {
    router.push('/admin/rules');
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#1E3A8A" />
        <Text style={styles.loadingText}>Carregando scripts...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Painel Admin</Text>
      </View>

      <View style={styles.actionsContainer}>
        <TouchableOpacity 
          style={styles.addButton}
          onPress={handleAddScript}
        >
          <PlusCircle size={20} color="white" style={{ marginRight: 8 }} />
          <Text style={styles.addButtonText}>Adicionar Script</Text>
        </TouchableOpacity>

        <View style={styles.adminButtons}>
          <TouchableOpacity 
            style={styles.adminButton}
            onPress={handleManageKeys}
          >
            <Key size={24} color={theme === 'dark' ? '#e0e0e0' : '#333'} />
            <Text style={styles.adminButtonText}>Gerenciar Chaves</Text>
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.adminButton}
            onPress={handleManageRules}
          >
            <BookOpen size={24} color={theme === 'dark' ? '#e0e0e0' : '#333'} />
            <Text style={styles.adminButtonText}>Regras</Text>
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.scriptsHeader}>
        <Text style={styles.scriptsTitle}>Scripts Publicados</Text>
        <Text style={styles.scriptsCount}>{scripts.length} scripts</Text>
      </View>

      {error ? (
        <View style={styles.errorContainer}>
          <Text style={styles.errorText}>{error}</Text>
          <TouchableOpacity style={styles.retryButton} onPress={loadScripts}>
            <Text style={styles.retryButtonText}>Tentar Novamente</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <FlatList
          data={scripts}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <View style={styles.scriptItem}>
              <View style={styles.scriptInfo}>
                <Text style={styles.scriptTitle}>{item.title}</Text>
                <Text style={styles.scriptCategory}>{item.category}</Text>
                <Text style={styles.scriptPrice}>AOA {item.price.toLocaleString()}</Text>
              </View>
              <View style={styles.scriptActions}>
                <TouchableOpacity 
                  style={styles.editButton}
                  onPress={() => handleEditScript(item.id)}
                >
                  <Edit size={20} color={theme === 'dark' ? '#e0e0e0' : '#333'} />
                </TouchableOpacity>
                <TouchableOpacity 
                  style={styles.deleteButton}
                  onPress={() => handleDeleteScript(item.id)}
                >
                  <Trash2 size={20} color="#e74c3c" />
                </TouchableOpacity>
              </View>
            </View>
          )}
          ListEmptyComponent={
            <Text style={styles.emptyListText}>
              Nenhum script publicado. Adicione seu primeiro script!
            </Text>
          }
          contentContainerStyle={styles.scriptsList}
        />
      )}
    </View>
  );
}

const getStyles = (theme: 'light' | 'dark') => StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme === 'dark' ? '#121212' : '#f7f7f7',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: theme === 'dark' ? '#121212' : '#f7f7f7',
  },
  loadingText: {
    fontFamily: 'WorkSans-Medium',
    marginTop: 12,
    color: theme === 'dark' ? '#e0e0e0' : '#555',
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 16,
    backgroundColor: theme === 'dark' ? '#1a1a1a' : '#fff',
  },
  headerTitle: {
    fontFamily: 'Poppins-Bold',
    fontSize: 24,
    color: theme === 'dark' ? '#fff' : '#333',
  },
  actionsContainer: {
    padding: 16,
  },
  addButton: {
    backgroundColor: '#1E3A8A',
    flexDirection: 'row',
    paddingVertical: 14,
    paddingHorizontal: 20,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  addButtonText: {
    fontFamily: 'WorkSans-SemiBold',
    color: 'white',
    fontSize: 16,
  },
  adminButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  adminButton: {
    backgroundColor: theme === 'dark' ? '#1a1a1a' : '#fff',
    width: '48%',
    paddingVertical: 16,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  adminButtonText: {
    fontFamily: 'WorkSans-Medium',
    color: theme === 'dark' ? '#e0e0e0' : '#333',
    fontSize: 14,
    marginTop: 8,
  },
  scriptsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    marginTop: 8,
    marginBottom: 8,
  },
  scriptsTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 16,
    color: theme === 'dark' ? '#e0e0e0' : '#333',
  },
  scriptsCount: {
    fontFamily: 'WorkSans-Regular',
    fontSize: 14,
    color: theme === 'dark' ? '#a0a0a0' : '#777',
  },
  scriptsList: {
    padding: 16,
    paddingBottom: 32,
  },
  scriptItem: {
    backgroundColor: theme === 'dark' ? '#1a1a1a' : '#fff',
    borderRadius: 8,
    padding: 16,
    marginBottom: 12,
    flexDirection: 'row',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  scriptInfo: {
    flex: 1,
  },
  scriptTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 16,
    color: theme === 'dark' ? '#fff' : '#333',
    marginBottom: 4,
  },
  scriptCategory: {
    fontFamily: 'WorkSans-Regular',
    fontSize: 14,
    color: theme === 'dark' ? '#a0a0a0' : '#777',
    marginBottom: 4,
  },
  scriptPrice: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: '#1E3A8A',
  },
  scriptActions: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  editButton: {
    padding: 8,
    marginRight: 8,
  },
  deleteButton: {
    padding: 8,
  },
  errorContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  errorText: {
    fontFamily: 'WorkSans-Regular',
    fontSize: 16,
    color: '#e74c3c',
    textAlign: 'center',
    marginBottom: 16,
  },
  retryButton: {
    backgroundColor: '#1E3A8A',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 8,
  },
  retryButtonText: {
    fontFamily: 'WorkSans-Medium',
    color: 'white',
    fontSize: 14,
  },
  emptyListText: {
    textAlign: 'center',
    fontFamily: 'WorkSans-Regular',
    fontSize: 16,
    color: theme === 'dark' ? '#a0a0a0' : '#777',
    marginTop: 32,
  },
});