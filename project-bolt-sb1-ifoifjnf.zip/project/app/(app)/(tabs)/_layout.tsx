import { Tabs } from 'expo-router';
import { Chrome as Home, ShoppingCart, Settings, PanelTop } from 'lucide-react-native';
import { useAuth } from '@/contexts/AuthContext';
import { useTheme } from '@/contexts/ThemeContext';

export default function TabLayout() {
  const { user } = useAuth();
  const { theme } = useTheme();

  const backgroundColor = theme === 'dark' ? '#121212' : '#fff';
  const activeColor = '#1E3A8A';
  const inactiveColor = theme === 'dark' ? '#777' : '#999';

  const isAdmin = user?.role === 'admin';

  return (
    <Tabs
      screenOptions={{
        tabBarStyle: {
          backgroundColor,
          borderTopColor: theme === 'dark' ? '#333' : '#eee',
          height: 60,
          paddingBottom: 8,
          paddingTop: 8,
        },
        tabBarActiveTintColor: activeColor,
        tabBarInactiveTintColor: inactiveColor,
        tabBarLabelStyle: {
          fontFamily: 'WorkSans-Medium',
          fontSize: 12,
        },
        headerShown: false,
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: 'Início',
          tabBarIcon: ({ color, size }) => <Home size={size} color={color} />,
        }}
      />
      <Tabs.Screen
        name="cart"
        options={{
          title: 'Carrinho',
          tabBarIcon: ({ color, size }) => <ShoppingCart size={size} color={color} />,
        }}
      />
      <Tabs.Screen
        name="settings"
        options={{
          title: 'Configurações',
          tabBarIcon: ({ color, size }) => <Settings size={size} color={color} />,
        }}
      />
      {isAdmin && (
        <Tabs.Screen
          name="admin"
          options={{
            title: 'Admin',
            tabBarIcon: ({ color, size }) => <PanelTop size={size} color={color} />,
          }}
        />
      )}
    </Tabs>
  );
}