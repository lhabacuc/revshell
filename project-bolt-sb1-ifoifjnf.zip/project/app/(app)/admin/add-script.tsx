import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TextInput,
  TouchableOpacity, 
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform
} from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { useTheme } from '@/contexts/ThemeContext';
import { useAuth } from '@/contexts/AuthContext';
import { ArrowLeft, Plus, Minus } from 'lucide-react-native';
import { Script } from '@/types';
import { addScript, updateScript, getScriptById } from '@/services/scriptService';

export default function AddScriptScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [category, setCategory] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [requirements, setRequirements] = useState('');
  const [features, setFeatures] = useState<string[]>(['']);
  const [loading, setLoading] = useState(false);
  const [initialLoading, setInitialLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const router = useRouter();
  const { theme } = useTheme();
  const { user } = useAuth();
  
  const styles = getStyles(theme);
  const isEditing = !!id;

  // Check if user is admin, if not redirect
  useEffect(() => {
    if (user?.role !== 'admin') {
      router.replace('/(app)/(tabs)');
    }
  }, [user, router]);

  // Load script data if editing
  useEffect(() => {
    const loadScript = async () => {
      if (!id) return;
      
      try {
        setInitialLoading(true);
        const scriptData = await getScriptById(id);
        
        setTitle(scriptData.title);
        setDescription(scriptData.description);
        setPrice(scriptData.price.toString());
        setCategory(scriptData.category);
        setImageUrl(scriptData.imageUrl || '');
        setRequirements(scriptData.requirements || '');
        setFeatures(scriptData.features || ['']);
      } catch (err) {
        console.error('Error loading script:', err);
        setError('Erro ao carregar o script. Por favor, tente novamente.');
      } finally {
        setInitialLoading(false);
      }
    };

    if (isEditing) {
      loadScript();
    }
  }, [id, isEditing]);

  const handleAddFeature = () => {
    setFeatures([...features, '']);
  };

  const handleRemoveFeature = (index: number) => {
    if (features.length > 1) {
      const updatedFeatures = [...features];
      updatedFeatures.splice(index, 1);
      setFeatures(updatedFeatures);
    }
  };

  const handleFeatureChange = (text: string, index: number) => {
    const updatedFeatures = [...features];
    updatedFeatures[index] = text;
    setFeatures(updatedFeatures);
  };

  const handleSave = async () => {
    // Validate form
    if (!title || !description || !price || !category) {
      setError('Por favor, preencha todos os campos obrigatórios');
      return;
    }

    const priceNumber = parseFloat(price);
    if (isNaN(priceNumber) || priceNumber <= 0) {
      setError('Por favor, insira um preço válido');
      return;
    }

    // Filter out empty features
    const filteredFeatures = features.filter(feature => feature.trim() !== '');

    const scriptData: Partial<Script> = {
      title,
      description,
      price: priceNumber,
      category,
      imageUrl: imageUrl || 'https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg',
      requirements,
      features: filteredFeatures,
    };

    try {
      setLoading(true);
      setError(null);
      
      if (isEditing) {
        await updateScript(id, scriptData);
        Alert.alert('Sucesso', 'Script atualizado com sucesso!');
      } else {
        await addScript(scriptData);
        Alert.alert('Sucesso', 'Script adicionado com sucesso!');
      }
      
      router.back();
    } catch (err) {
      console.error('Error saving script:', err);
      setError('Erro ao salvar o script. Por favor, tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  if (initialLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#1E3A8A" />
        <Text style={styles.loadingText}>Carregando dados do script...</Text>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView 
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={{ flex: 1 }}
    >
      <View style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity 
            style={styles.backButton}
            onPress={() => router.back()}
          >
            <ArrowLeft size={24} color={theme === 'dark' ? '#fff' : '#333'} />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>
            {isEditing ? 'Editar Script' : 'Adicionar Script'}
          </Text>
          <View style={{ width: 24 }} />
        </View>

        <ScrollView style={styles.formContainer} contentContainerStyle={styles.formContent}>
          {error && <Text style={styles.errorText}>{error}</Text>}
          
          <View style={styles.inputContainer}>
            <Text style={styles.label}>Título*</Text>
            <TextInput
              style={styles.input}
              placeholder="Título do script"
              placeholderTextColor={theme === 'dark' ? '#a0a0a0' : '#888'}
              value={title}
              onChangeText={setTitle}
            />
          </View>

          <View style={styles.inputContainer}>
            <Text style={styles.label}>Descrição*</Text>
            <TextInput
              style={[styles.input, styles.textArea]}
              placeholder="Descrição detalhada do script"
              placeholderTextColor={theme === 'dark' ? '#a0a0a0' : '#888'}
              value={description}
              onChangeText={setDescription}
              multiline
              textAlignVertical="top"
              numberOfLines={5}
            />
          </View>

          <View style={styles.inputContainer}>
            <Text style={styles.label}>Preço (AOA)*</Text>
            <TextInput
              style={styles.input}
              placeholder="Preço do script"
              placeholderTextColor={theme === 'dark' ? '#a0a0a0' : '#888'}
              value={price}
              onChangeText={setPrice}
              keyboardType="numeric"
            />
          </View>

          <View style={styles.inputContainer}>
            <Text style={styles.label}>Categoria*</Text>
            <TextInput
              style={styles.input}
              placeholder="Categoria do script"
              placeholderTextColor={theme === 'dark' ? '#a0a0a0' : '#888'}
              value={category}
              onChangeText={setCategory}
            />
          </View>

          <View style={styles.inputContainer}>
            <Text style={styles.label}>URL da Imagem</Text>
            <TextInput
              style={styles.input}
              placeholder="URL da imagem de capa (opcional)"
              placeholderTextColor={theme === 'dark' ? '#a0a0a0' : '#888'}
              value={imageUrl}
              onChangeText={setImageUrl}
            />
          </View>

          <View style={styles.inputContainer}>
            <Text style={styles.label}>Requisitos</Text>
            <TextInput
              style={[styles.input, styles.textArea]}
              placeholder="Requisitos técnicos para usar o script (opcional)"
              placeholderTextColor={theme === 'dark' ? '#a0a0a0' : '#888'}
              value={requirements}
              onChangeText={setRequirements}
              multiline
              textAlignVertical="top"
              numberOfLines={4}
            />
          </View>

          <View style={styles.inputContainer}>
            <View style={styles.featuresHeader}>
              <Text style={styles.label}>Recursos</Text>
              <TouchableOpacity 
                style={styles.addFeatureButton}
                onPress={handleAddFeature}
              >
                <Plus size={18} color={theme === 'dark' ? '#fff' : '#333'} />
              </TouchableOpacity>
            </View>
            
            {features.map((feature, index) => (
              <View key={index} style={styles.featureRow}>
                <TextInput
                  style={[styles.input, styles.featureInput]}
                  placeholder={`Recurso ${index + 1}`}
                  placeholderTextColor={theme === 'dark' ? '#a0a0a0' : '#888'}
                  value={feature}
                  onChangeText={(text) => handleFeatureChange(text, index)}
                />
                {features.length > 1 && (
                  <TouchableOpacity 
                    style={styles.removeFeatureButton}
                    onPress={() => handleRemoveFeature(index)}
                  >
                    <Minus size={18} color="#e74c3c" />
                  </TouchableOpacity>
                )}
              </View>
            ))}
          </View>

          <TouchableOpacity 
            style={styles.saveButton}
            onPress={handleSave}
            disabled={loading}
          >
            {loading ? (
              <ActivityIndicator color="white" />
            ) : (
              <Text style={styles.saveButtonText}>
                {isEditing ? 'Atualizar Script' : 'Adicionar Script'}
              </Text>
            )}
          </TouchableOpacity>
        </ScrollView>
      </View>
    </KeyboardAvoidingView>
  );
}

const getStyles = (theme: 'light' | 'dark') => StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme === 'dark' ? '#121212' : '#f7f7f7',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: theme === 'dark' ? '#121212' : '#f7f7f7',
  },
  loadingText: {
    fontFamily: 'WorkSans-Medium',
    marginTop: 12,
    color: theme === 'dark' ? '#e0e0e0' : '#555',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingTop: 60,
    paddingBottom: 16,
    backgroundColor: theme === 'dark' ? '#1a1a1a' : '#fff',
  },
  backButton: {
    padding: 8,
  },
  headerTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 20,
    color: theme === 'dark' ? '#fff' : '#333',
  },
  formContainer: {
    flex: 1,
  },
  formContent: {
    padding: 16,
    paddingBottom: 40,
  },
  errorText: {
    fontFamily: 'WorkSans-Regular',
    color: '#e74c3c',
    marginBottom: 16,
    textAlign: 'center',
  },
  inputContainer: {
    marginBottom: 20,
  },
  label: {
    fontFamily: 'WorkSans-Medium',
    fontSize: 16,
    color: theme === 'dark' ? '#e0e0e0' : '#555',
    marginBottom: 8,
  },
  input: {
    fontFamily: 'WorkSans-Regular',
    borderWidth: 1,
    borderColor: theme === 'dark' ? '#333' : '#ddd',
    borderRadius: 8,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
    backgroundColor: theme === 'dark' ? '#262626' : '#fff',
    color: theme === 'dark' ? '#fff' : '#333',
  },
  textArea: {
    minHeight: 100,
    textAlignVertical: 'top',
    paddingTop: 12,
  },
  featuresHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  addFeatureButton: {
    backgroundColor: theme === 'dark' ? '#333' : '#f0f0f0',
    borderRadius: 20,
    width: 30,
    height: 30,
    justifyContent: 'center',
    alignItems: 'center',
  },
  featureRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  featureInput: {
    flex: 1,
    marginRight: 10,
  },
  removeFeatureButton: {
    backgroundColor: theme === 'dark' ? '#3c1a1a' : '#ffebeb',
    borderRadius: 20,
    width: 30,
    height: 30,
    justifyContent: 'center',
    alignItems: 'center',
  },
  saveButton: {
    backgroundColor: '#1E3A8A',
    paddingVertical: 16,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 16,
  },
  saveButtonText: {
    fontFamily: 'WorkSans-SemiBold',
    color: 'white',
    fontSize: 16,
  },
});