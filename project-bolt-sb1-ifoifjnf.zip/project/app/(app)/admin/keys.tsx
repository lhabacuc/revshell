import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity, 
  FlatList, 
  TextInput,
  Alert,
  ActivityIndicator,
  Clipboard,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useTheme } from '@/contexts/ThemeContext';
import { useAuth } from '@/contexts/AuthContext';
import { ArrowLeft, ClipboardCopy, Plus, RefreshCw, Trash2 } from 'lucide-react-native';
import { generateAccessKey, getAccessKeys, deleteAccessKey } from '@/services/keyService';
import { AccessKey } from '@/types';

export default function KeysManagementScreen() {
  const [keys, setKeys] = useState<AccessKey[]>([]);
  const [scriptId, setScriptId] = useState('');
  const [userId, setUserId] = useState('');
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const router = useRouter();
  const { theme } = useTheme();
  const { user } = useAuth();
  
  const styles = getStyles(theme);

  // Check if user is admin, if not redirect
  useEffect(() => {
    if (user?.role !== 'admin') {
      router.replace('/(app)/(tabs)');
    }
  }, [user, router]);

  useEffect(() => {
    loadKeys();
  }, []);

  const loadKeys = async () => {
    try {
      setLoading(true);
      setError(null);
      const keysData = await getAccessKeys();
      setKeys(keysData);
    } catch (err) {
      console.error('Error loading keys:', err);
      setError('Erro ao carregar chaves. Por favor, tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateKey = async () => {
    if (!scriptId || !userId) {
      Alert.alert('Dados incompletos', 'Por favor, informe o ID do script e do usuário.');
      return;
    }

    try {
      setGenerating(true);
      setError(null);
      const newKey = await generateAccessKey(scriptId, userId);
      setKeys([newKey, ...keys]);
      
      // Reset inputs
      setScriptId('');
      setUserId('');
      
      Alert.alert('Sucesso', 'Chave de acesso gerada com sucesso!');
    } catch (err) {
      console.error('Error generating key:', err);
      setError('Erro ao gerar chave. Por favor, tente novamente.');
    } finally {
      setGenerating(false);
    }
  };

  const handleDeleteKey = (keyId: string) => {
    Alert.alert(
      'Excluir Chave',
      'Tem certeza que deseja excluir esta chave? O usuário perderá o acesso ao script.',
      [
        {
          text: 'Cancelar',
          style: 'cancel',
        },
        {
          text: 'Excluir',
          style: 'destructive',
          onPress: async () => {
            try {
              await deleteAccessKey(keyId);
              setKeys(keys.filter(key => key.id !== keyId));
            } catch (error) {
              console.error('Error deleting key:', error);
              Alert.alert('Erro', 'Ocorreu um erro ao excluir a chave.');
            }
          },
        },
      ]
    );
  };

  const copyToClipboard = (key: string) => {
    Clipboard.setString(key);
    Alert.alert('Copiado', 'Chave copiada para a área de transferência.');
  };

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleDateString('pt-AO', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity 
          style={styles.backButton}
          onPress={() => router.back()}
        >
          <ArrowLeft size={24} color={theme === 'dark' ? '#fff' : '#333'} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Gerenciar Chaves</Text>
        <TouchableOpacity 
          style={styles.refreshButton}
          onPress={loadKeys}
        >
          <RefreshCw size={20} color={theme === 'dark' ? '#fff' : '#333'} />
        </TouchableOpacity>
      </View>

      <View style={styles.generateSection}>
        <Text style={styles.sectionTitle}>Gerar Nova Chave</Text>
        
        <View style={styles.inputContainer}>
          <Text style={styles.label}>ID do Script</Text>
          <TextInput
            style={styles.input}
            placeholder="ID do script"
            placeholderTextColor={theme === 'dark' ? '#a0a0a0' : '#888'}
            value={scriptId}
            onChangeText={setScriptId}
          />
        </View>

        <View style={styles.inputContainer}>
          <Text style={styles.label}>ID do Usuário</Text>
          <TextInput
            style={styles.input}
            placeholder="ID do usuário"
            placeholderTextColor={theme === 'dark' ? '#a0a0a0' : '#888'}
            value={userId}
            onChangeText={setUserId}
          />
        </View>

        <TouchableOpacity 
          style={styles.generateButton}
          onPress={handleGenerateKey}
          disabled={generating}
        >
          {generating ? (
            <ActivityIndicator color="white" />
          ) : (
            <>
              <Plus size={20} color="white" style={{ marginRight: 8 }} />
              <Text style={styles.generateButtonText}>Gerar Chave de Acesso</Text>
            </>
          )}
        </TouchableOpacity>
      </View>

      <View style={styles.keysListHeader}>
        <Text style={styles.sectionTitle}>Chaves Ativas</Text>
        <Text style={styles.keysCount}>{keys.length} chaves</Text>
      </View>

      {error && (
        <Text style={styles.errorText}>{error}</Text>
      )}

      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#1E3A8A" />
          <Text style={styles.loadingText}>Carregando chaves...</Text>
        </View>
      ) : (
        <FlatList
          data={keys}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <View style={styles.keyItem}>
              <View style={styles.keyInfo}>
                <Text style={styles.keyValue}>{item.key}</Text>
                <Text style={styles.keyMeta}>
                  Script: {item.scriptId.substring(0, 8)}...
                </Text>
                <Text style={styles.keyMeta}>
                  Usuário: {item.userId.substring(0, 8)}...
                </Text>
                <Text style={styles.keyDate}>
                  Gerada em: {formatDate(item.createdAt)}
                </Text>
              </View>
              <View style={styles.keyActions}>
                <TouchableOpacity 
                  style={styles.copyButton}
                  onPress={() => copyToClipboard(item.key)}
                >
                  <ClipboardCopy size={20} color={theme === 'dark' ? '#e0e0e0' : '#333'} />
                </TouchableOpacity>
                <TouchableOpacity 
                  style={styles.deleteButton}
                  onPress={() => handleDeleteKey(item.id)}
                >
                  <Trash2 size={20} color="#e74c3c" />
                </TouchableOpacity>
              </View>
            </View>
          )}
          ListEmptyComponent={
            <Text style={styles.emptyListText}>
              Nenhuma chave gerada ainda. Crie sua primeira chave de acesso!
            </Text>
          }
          contentContainerStyle={styles.keysList}
        />
      )}
    </View>
  );
}

const getStyles = (theme: 'light' | 'dark') => StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme === 'dark' ? '#121212' : '#f7f7f7',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingTop: 60,
    paddingBottom: 16,
    backgroundColor: theme === 'dark' ? '#1a1a1a' : '#fff',
  },
  backButton: {
    padding: 8,
  },
  headerTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 20,
    color: theme === 'dark' ? '#fff' : '#333',
  },
  refreshButton: {
    padding: 8,
  },
  generateSection: {
    backgroundColor: theme === 'dark' ? '#1a1a1a' : '#fff',
    padding: 16,
    marginBottom: 16,
  },
  sectionTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 18,
    color: theme === 'dark' ? '#fff' : '#333',
    marginBottom: 16,
  },
  inputContainer: {
    marginBottom: 12,
  },
  label: {
    fontFamily: 'WorkSans-Medium',
    fontSize: 14,
    color: theme === 'dark' ? '#e0e0e0' : '#555',
    marginBottom: 8,
  },
  input: {
    fontFamily: 'WorkSans-Regular',
    borderWidth: 1,
    borderColor: theme === 'dark' ? '#333' : '#ddd',
    borderRadius: 8,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
    backgroundColor: theme === 'dark' ? '#262626' : '#fff',
    color: theme === 'dark' ? '#fff' : '#333',
  },
  generateButton: {
    backgroundColor: '#1E3A8A',
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 16,
    flexDirection: 'row',
  },
  generateButtonText: {
    fontFamily: 'WorkSans-SemiBold',
    color: 'white',
    fontSize: 16,
  },
  keysListHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    marginBottom: 8,
  },
  keysCount: {
    fontFamily: 'WorkSans-Regular',
    fontSize: 14,
    color: theme === 'dark' ? '#a0a0a0' : '#777',
  },
  errorText: {
    fontFamily: 'WorkSans-Regular',
    color: '#e74c3c',
    marginHorizontal: 16,
    marginBottom: 16,
    textAlign: 'center',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    fontFamily: 'WorkSans-Medium',
    marginTop: 12,
    color: theme === 'dark' ? '#e0e0e0' : '#555',
  },
  keysList: {
    padding: 16,
    paddingBottom: 32,
  },
  keyItem: {
    backgroundColor: theme === 'dark' ? '#1a1a1a' : '#fff',
    borderRadius: 8,
    padding: 16,
    marginBottom: 12,
    flexDirection: 'row',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  keyInfo: {
    flex: 1,
  },
  keyValue: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 16,
    color: theme === 'dark' ? '#fff' : '#333',
    marginBottom: 8,
  },
  keyMeta: {
    fontFamily: 'WorkSans-Regular',
    fontSize: 14,
    color: theme === 'dark' ? '#a0a0a0' : '#777',
    marginBottom: 4,
  },
  keyDate: {
    fontFamily: 'WorkSans-Regular',
    fontSize: 12,
    color: theme === 'dark' ? '#a0a0a0' : '#888',
    marginTop: 4,
  },
  keyActions: {
    justifyContent: 'space-between',
    paddingLeft: 8,
  },
  copyButton: {
    padding: 8,
    marginBottom: 8,
  },
  deleteButton: {
    padding: 8,
  },
  emptyListText: {
    textAlign: 'center',
    fontFamily: 'WorkSans-Regular',
    fontSize: 16,
    color: theme === 'dark' ? '#a0a0a0' : '#777',
    marginTop: 32,
  },
});