import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity, 
  TextInput,
  ScrollView,
  Alert,
  ActivityIndicator
} from 'react-native';
import { useRouter } from 'expo-router';
import { useTheme } from '@/contexts/ThemeContext';
import { useAuth } from '@/contexts/AuthContext';
import { ArrowLeft, Save } from 'lucide-react-native';
import { getRules, updateRules } from '@/services/adminService';

export default function AdminRulesScreen() {
  const [rules, setRules] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const router = useRouter();
  const { theme } = useTheme();
  const { user } = useAuth();
  
  const styles = getStyles(theme);

  // Check if user is admin, if not redirect
  useEffect(() => {
    if (user?.role !== 'admin') {
      router.replace('/(app)/(tabs)');
    }
  }, [user, router]);

  useEffect(() => {
    loadRules();
  }, []);

  const loadRules = async () => {
    try {
      setLoading(true);
      setError(null);
      const rulesData = await getRules();
      setRules(rulesData.content);
    } catch (err) {
      console.error('Error loading rules:', err);
      setError('Erro ao carregar regras. Por favor, tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  const handleSaveRules = async () => {
    if (!rules.trim()) {
      Alert.alert('Erro', 'As regras não podem estar vazias.');
      return;
    }

    try {
      setSaving(true);
      setError(null);
      await updateRules(rules);
      Alert.alert('Sucesso', 'Regras atualizadas com sucesso!');
    } catch (err) {
      console.error('Error saving rules:', err);
      setError('Erro ao salvar regras. Por favor, tente novamente.');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#1E3A8A" />
        <Text style={styles.loadingText}>Carregando regras...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity 
          style={styles.backButton}
          onPress={() => router.back()}
        >
          <ArrowLeft size={24} color={theme === 'dark' ? '#fff' : '#333'} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Regras de Administração</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView style={styles.content}>
        <Text style={styles.sectionTitle}>Diretrizes para Administradores</Text>
        
        {error && <Text style={styles.errorText}>{error}</Text>}
        
        <Text style={styles.description}>
          Edite as regras e diretrizes para os administradores da plataforma. 
          Estas regras são importantes para manter a consistência e qualidade dos scripts publicados.
        </Text>

        <View style={styles.inputContainer}>
          <TextInput
            style={styles.rulesInput}
            value={rules}
            onChangeText={setRules}
            multiline
            textAlignVertical="top"
            placeholder="Digite as regras para administradores..."
            placeholderTextColor={theme === 'dark' ? '#a0a0a0' : '#888'}
          />
        </View>

        <TouchableOpacity 
          style={styles.saveButton}
          onPress={handleSaveRules}
          disabled={saving}
        >
          {saving ? (
            <ActivityIndicator color="white" />
          ) : (
            <>
              <Save size={20} color="white" style={{ marginRight: 8 }} />
              <Text style={styles.saveButtonText}>Salvar Regras</Text>
            </>
          )}
        </TouchableOpacity>

        <View style={styles.tipsContainer}>
          <Text style={styles.tipsTitle}>Dicas para Regras Eficientes:</Text>
          <Text style={styles.tipItem}>• Defina padrões claros para a qualidade dos scripts</Text>
          <Text style={styles.tipItem}>• Estabeleça diretrizes para revisão e aprovação</Text>
          <Text style={styles.tipItem}>• Inclua políticas de preços e categorização</Text>
          <Text style={styles.tipItem}>• Defina o processo para responder a reclamações</Text>
          <Text style={styles.tipItem}>• Estabeleça regras para a geração de chaves de acesso</Text>
        </View>
      </ScrollView>
    </View>
  );
}

const getStyles = (theme: 'light' | 'dark') => StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme === 'dark' ? '#121212' : '#f7f7f7',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: theme === 'dark' ? '#121212' : '#f7f7f7',
  },
  loadingText: {
    fontFamily: 'WorkSans-Medium',
    marginTop: 12,
    color: theme === 'dark' ? '#e0e0e0' : '#555',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingTop: 60,
    paddingBottom: 16,
    backgroundColor: theme === 'dark' ? '#1a1a1a' : '#fff',
  },
  backButton: {
    padding: 8,
  },
  headerTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 20,
    color: theme === 'dark' ? '#fff' : '#333',
  },
  content: {
    flex: 1,
    padding: 16,
  },
  sectionTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 18,
    color: theme === 'dark' ? '#fff' : '#333',
    marginBottom: 16,
  },
  errorText: {
    fontFamily: 'WorkSans-Regular',
    color: '#e74c3c',
    marginBottom: 16,
    textAlign: 'center',
  },
  description: {
    fontFamily: 'WorkSans-Regular',
    fontSize: 14,
    color: theme === 'dark' ? '#e0e0e0' : '#555',
    marginBottom: 20,
    lineHeight: 20,
  },
  inputContainer: {
    marginBottom: 20,
  },
  rulesInput: {
    fontFamily: 'WorkSans-Regular',
    borderWidth: 1,
    borderColor: theme === 'dark' ? '#333' : '#ddd',
    borderRadius: 8,
    backgroundColor: theme === 'dark' ? '#262626' : '#fff',
    color: theme === 'dark' ? '#fff' : '#333',
    padding: 16,
    minHeight: 200,
    fontSize: 16,
    textAlignVertical: 'top',
  },
  saveButton: {
    backgroundColor: '#1E3A8A',
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
    flexDirection: 'row',
  },
  saveButtonText: {
    fontFamily: 'WorkSans-SemiBold',
    color: 'white',
    fontSize: 16,
  },
  tipsContainer: {
    backgroundColor: theme === 'dark' ? '#1a1a1a' : '#fff',
    borderRadius: 8,
    padding: 16,
    marginBottom: 20,
  },
  tipsTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 16,
    color: theme === 'dark' ? '#fff' : '#333',
    marginBottom: 12,
  },
  tipItem: {
    fontFamily: 'WorkSans-Regular',
    fontSize: 14,
    color: theme === 'dark' ? '#e0e0e0' : '#555',
    marginBottom: 8,
    lineHeight: 20,
  },
});