import { Redirect, Stack } from 'expo-router';
import { useAuth } from '@/contexts/AuthContext';

export default function AppLayout() {
  const { user, isLoading } = useAuth();
  
  // If no user is signed in, redirect to the auth screen
  if (!isLoading && !user) {
    return <Redirect href="/(auth)" />;
  }

  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="(tabs)" />
      <Stack.Screen name="script/[id]" options={{ presentation: 'modal' }} />
      <Stack.Screen name="admin/add-script" options={{ presentation: 'modal' }} />
      <Stack.Screen name="admin/keys" />
      <Stack.Screen name="admin/rules" />
    </Stack>
  );
}