import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, Image, TouchableOpacity, ActivityIndicator, Alert } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useTheme } from '@/contexts/ThemeContext';
import { useAuth } from '@/contexts/AuthContext';
import { ShoppingCart, ArrowLeft, Download, Share2 } from 'lucide-react-native';
import { getScriptById } from '@/services/scriptService';
import { addToCart } from '@/services/cartService';
import { downloadScript } from '@/services/downloadService';
import { Script } from '@/types';

export default function ScriptDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const [script, setScript] = useState<Script | null>(null);
  const [loading, setLoading] = useState(true);
  const [addingToCart, setAddingToCart] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();
  const { theme } = useTheme();
  const { user } = useAuth();
  
  const styles = getStyles(theme);

  useEffect(() => {
    const loadScript = async () => {
      try {
        if (!id) return;
        
        setLoading(true);
        setError(null);
        const scriptData = await getScriptById(id);
        setScript(scriptData);
      } catch (err) {
        console.error('Error loading script:', err);
        setError('Erro ao carregar o script. Por favor, tente novamente.');
      } finally {
        setLoading(false);
      }
    };

    loadScript();
  }, [id]);

  const handleAddToCart = async () => {
    if (!script || !user?.id) return;
    
    try {
      setAddingToCart(true);
      await addToCart(user.id, script);
      Alert.alert('Sucesso', 'Script adicionado ao carrinho com sucesso!');
    } catch (error) {
      console.error('Error adding to cart:', error);
      Alert.alert('Erro', 'Ocorreu um erro ao adicionar ao carrinho. Por favor, tente novamente.');
    } finally {
      setAddingToCart(false);
    }
  };

  const handleDownload = async () => {
    if (!script || !user?.id) return;
    
    try {
      setDownloading(true);
      const accessKey = await downloadScript(user.id, script.id);
      if (accessKey) {
        Alert.alert(
          'Download Disponível',
          `Utilize esta chave para acessar o script: ${accessKey}`,
          [
            { text: 'Copiar Chave', onPress: () => { /* Copy to clipboard */ } },
            { text: 'OK' }
          ]
        );
      }
    } catch (error) {
      console.error('Error downloading script:', error);
      Alert.alert('Erro', 'Ocorreu um erro ao tentar baixar o script. Por favor, verifique se você tem acesso.');
    } finally {
      setDownloading(false);
    }
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#1E3A8A" />
        <Text style={styles.loadingText}>Carregando detalhes do script...</Text>
      </View>
    );
  }

  if (error || !script) {
    return (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>{error || 'Script não encontrado'}</Text>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <Text style={styles.backButtonText}>Voltar</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity 
          style={styles.backButton}
          onPress={() => router.back()}
        >
          <ArrowLeft size={24} color={theme === 'dark' ? '#fff' : '#333'} />
        </TouchableOpacity>
        <Text style={styles.headerTitle} numberOfLines={1}>
          {script.title}
        </Text>
        <TouchableOpacity style={styles.shareButton}>
          <Share2 size={24} color={theme === 'dark' ? '#fff' : '#333'} />
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.scrollView}>
        <Image 
          source={{ uri: script.imageUrl || 'https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg' }} 
          style={styles.scriptImage}
        />

        <View style={styles.contentContainer}>
          <View style={styles.titleSection}>
            <Text style={styles.title}>{script.title}</Text>
            <View style={styles.categoryPill}>
              <Text style={styles.categoryText}>{script.category}</Text>
            </View>
          </View>

          <View style={styles.priceSection}>
            <Text style={styles.priceLabel}>Preço</Text>
            <Text style={styles.price}>AOA {script.price.toLocaleString()}</Text>
          </View>

          <View style={styles.divider} />

          <View style={styles.descriptionSection}>
            <Text style={styles.sectionTitle}>Descrição</Text>
            <Text style={styles.description}>{script.description}</Text>
          </View>

          <View style={styles.featuresSection}>
            <Text style={styles.sectionTitle}>Recursos</Text>
            <View style={styles.featuresList}>
              {script.features?.map((feature, index) => (
                <View key={index} style={styles.featureItem}>
                  <Text style={styles.featureText}>{feature}</Text>
                </View>
              ))}
            </View>
          </View>

          {script.requirements && (
            <View style={styles.requirementsSection}>
              <Text style={styles.sectionTitle}>Requisitos</Text>
              <Text style={styles.requirementsText}>{script.requirements}</Text>
            </View>
          )}
        </View>
      </ScrollView>

      <View style={styles.footer}>
        {user?.purchases?.includes(script.id) ? (
          <TouchableOpacity 
            style={styles.downloadButton}
            onPress={handleDownload}
            disabled={downloading}
          >
            {downloading ? (
              <ActivityIndicator color="white" size="small" />
            ) : (
              <>
                <Download size={20} color="white" style={{ marginRight: 8 }} />
                <Text style={styles.downloadButtonText}>Download</Text>
              </>
            )}
          </TouchableOpacity>
        ) : (
          <TouchableOpacity 
            style={styles.addToCartButton}
            onPress={handleAddToCart}
            disabled={addingToCart}
          >
            {addingToCart ? (
              <ActivityIndicator color="white" size="small" />
            ) : (
              <>
                <ShoppingCart size={20} color="white" style={{ marginRight: 8 }} />
                <Text style={styles.addToCartButtonText}>Adicionar ao Carrinho</Text>
              </>
            )}
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
}

const getStyles = (theme: 'light' | 'dark') => StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme === 'dark' ? '#121212' : '#f7f7f7',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: theme === 'dark' ? '#121212' : '#f7f7f7',
  },
  loadingText: {
    fontFamily: 'WorkSans-Medium',
    marginTop: 12,
    color: theme === 'dark' ? '#e0e0e0' : '#555',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: theme === 'dark' ? '#121212' : '#f7f7f7',
  },
  errorText: {
    fontFamily: 'WorkSans-Regular',
    fontSize: 16,
    color: '#e74c3c',
    textAlign: 'center',
    marginBottom: 16,
  },
  backButtonText: {
    fontFamily: 'WorkSans-Medium',
    color: '#1E3A8A',
    fontSize: 16,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingTop: 60,
    paddingBottom: 16,
    backgroundColor: theme === 'dark' ? '#1a1a1a' : '#fff',
  },
  backButton: {
    padding: 8,
  },
  headerTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 18,
    color: theme === 'dark' ? '#fff' : '#333',
    flex: 1,
    textAlign: 'center',
  },
  shareButton: {
    padding: 8,
  },
  scrollView: {
    flex: 1,
  },
  scriptImage: {
    width: '100%',
    height: 250,
    resizeMode: 'cover',
  },
  contentContainer: {
    backgroundColor: theme === 'dark' ? '#1a1a1a' : '#fff',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: 20,
    marginTop: -24,
  },
  titleSection: {
    marginBottom: 16,
  },
  title: {
    fontFamily: 'Poppins-Bold',
    fontSize: 24,
    color: theme === 'dark' ? '#fff' : '#333',
    marginBottom: 8,
  },
  categoryPill: {
    backgroundColor: theme === 'dark' ? '#333' : '#f0f0f0',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    alignSelf: 'flex-start',
  },
  categoryText: {
    fontFamily: 'WorkSans-Medium',
    fontSize: 14,
    color: theme === 'dark' ? '#e0e0e0' : '#555',
  },
  priceSection: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    marginBottom: 20,
  },
  priceLabel: {
    fontFamily: 'WorkSans-Regular',
    fontSize: 16,
    color: theme === 'dark' ? '#b0b0b0' : '#777',
    marginRight: 8,
  },
  price: {
    fontFamily: 'Poppins-Bold',
    fontSize: 24,
    color: '#1E3A8A',
  },
  divider: {
    height: 1,
    backgroundColor: theme === 'dark' ? '#333' : '#eee',
    marginBottom: 20,
  },
  descriptionSection: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 18,
    color: theme === 'dark' ? '#fff' : '#333',
    marginBottom: 12,
  },
  description: {
    fontFamily: 'WorkSans-Regular',
    fontSize: 16,
    color: theme === 'dark' ? '#e0e0e0' : '#555',
    lineHeight: 24,
  },
  featuresSection: {
    marginBottom: 20,
  },
  featuresList: {
    marginTop: 8,
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  featureText: {
    fontFamily: 'WorkSans-Regular',
    fontSize: 15,
    color: theme === 'dark' ? '#e0e0e0' : '#555',
    lineHeight: 22,
  },
  requirementsSection: {
    marginBottom: 40,
  },
  requirementsText: {
    fontFamily: 'WorkSans-Regular',
    fontSize: 15,
    color: theme === 'dark' ? '#e0e0e0' : '#555',
    lineHeight: 22,
  },
  footer: {
    backgroundColor: theme === 'dark' ? '#1a1a1a' : '#fff',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderTopWidth: 1,
    borderTopColor: theme === 'dark' ? '#333' : '#eee',
  },
  addToCartButton: {
    backgroundColor: '#1E3A8A',
    paddingVertical: 16,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  addToCartButtonText: {
    fontFamily: 'WorkSans-SemiBold',
    color: 'white',
    fontSize: 16,
  },
  downloadButton: {
    backgroundColor: '#218838',
    paddingVertical: 16,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  downloadButtonText: {
    fontFamily: 'WorkSans-SemiBold',
    color: 'white',
    fontSize: 16,
  },
});