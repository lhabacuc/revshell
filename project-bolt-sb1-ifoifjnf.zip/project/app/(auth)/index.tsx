import { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ActivityIndicator } from 'react-native';
import { Link, useRouter } from 'expo-router';
import { useAuth } from '@/contexts/AuthContext';
import { useTheme } from '@/contexts/ThemeContext';
import { LogIn } from 'lucide-react-native';

export default function LoginScreen() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { signIn } = useAuth();
  const router = useRouter();
  const { theme } = useTheme();
  
  const styles = getStyles(theme);

  const handleLogin = async () => {
    if (!email || !password) {
      setError('Por favor, preencha todos os campos');
      return;
    }

    setLoading(true);
    setError(null);
    
    try {
      await signIn(email, password);
      router.replace('/(app)/(tabs)');
    } catch (err) {
      setError('Email ou senha inválidos. Por favor, tente novamente.');
      console.error('Login error:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.headerContainer}>
        <Text style={styles.logoText}>Script Angola</Text>
        <Text style={styles.tagline}>Sua plataforma de scripts premium</Text>
      </View>

      <View style={styles.formContainer}>
        <Text style={styles.title}>Login</Text>
        
        {error && <Text style={styles.errorText}>{error}</Text>}
        
        <View style={styles.inputContainer}>
          <Text style={styles.label}>Email</Text>
          <TextInput
            style={styles.input}
            placeholder="Seu email"
            placeholderTextColor={theme === 'dark' ? '#a0a0a0' : '#888'}
            keyboardType="email-address"
            autoCapitalize="none"
            value={email}
            onChangeText={setEmail}
          />
        </View>

        <View style={styles.inputContainer}>
          <Text style={styles.label}>Senha</Text>
          <TextInput
            style={styles.input}
            placeholder="Sua senha"
            placeholderTextColor={theme === 'dark' ? '#a0a0a0' : '#888'}
            secureTextEntry
            value={password}
            onChangeText={setPassword}
          />
        </View>

        <TouchableOpacity 
          style={styles.loginButton}
          onPress={handleLogin}
          disabled={loading}
        >
          {loading ? (
            <ActivityIndicator color="white" />
          ) : (
            <>
              <LogIn size={20} color="white" style={{ marginRight: 8 }} />
              <Text style={styles.loginButtonText}>Entrar</Text>
            </>
          )}
        </TouchableOpacity>

        <View style={styles.registerContainer}>
          <Text style={styles.registerText}>Não tem uma conta? </Text>
          <Link href="/register" asChild>
            <TouchableOpacity>
              <Text style={styles.registerLink}>Registrar</Text>
            </TouchableOpacity>
          </Link>
        </View>
      </View>
    </View>
  );
}

const getStyles = (theme: 'light' | 'dark') => StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme === 'dark' ? '#121212' : '#fff',
  },
  headerContainer: {
    height: '40%',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: theme === 'dark' ? '#1a1a1a' : '#1E3A8A',
  },
  logoText: {
    fontFamily: 'Poppins-Bold',
    fontSize: 32,
    color: '#fff',
    textAlign: 'center',
  },
  tagline: {
    fontFamily: 'Poppins-Regular',
    fontSize: 16,
    color: '#f0f0f0',
    marginTop: 8,
  },
  formContainer: {
    flex: 1,
    paddingHorizontal: 24,
    paddingTop: 32,
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    backgroundColor: theme === 'dark' ? '#1a1a1a' : '#fff',
    marginTop: -30,
  },
  title: {
    fontFamily: 'Poppins-Bold',
    fontSize: 24,
    color: theme === 'dark' ? '#fff' : '#333',
    marginBottom: 24,
  },
  errorText: {
    fontFamily: 'WorkSans-Regular',
    color: '#e74c3c',
    marginBottom: 16,
    textAlign: 'center',
  },
  inputContainer: {
    marginBottom: 16,
  },
  label: {
    fontFamily: 'WorkSans-Medium',
    fontSize: 14,
    color: theme === 'dark' ? '#e0e0e0' : '#555',
    marginBottom: 8,
  },
  input: {
    fontFamily: 'WorkSans-Regular',
    borderWidth: 1,
    borderColor: theme === 'dark' ? '#333' : '#ddd',
    borderRadius: 8,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
    backgroundColor: theme === 'dark' ? '#262626' : '#fff',
    color: theme === 'dark' ? '#fff' : '#333',
  },
  loginButton: {
    backgroundColor: '#1E3A8A',
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 24,
    flexDirection: 'row',
  },
  loginButtonText: {
    fontFamily: 'WorkSans-SemiBold',
    color: 'white',
    fontSize: 16,
  },
  registerContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 24,
  },
  registerText: {
    fontFamily: 'WorkSans-Regular',
    color: theme === 'dark' ? '#e0e0e0' : '#555',
  },
  registerLink: {
    fontFamily: 'WorkSans-SemiBold',
    color: '#1E3A8A',
  },
});