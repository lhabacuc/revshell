import { db } from './firebase';
import { 
  collection, 
  addDoc, 
  getDocs, 
  query, 
  orderBy, 
  deleteDoc, 
  doc 
} from 'firebase/firestore';
import { AccessKey } from '@/types';

// Mock data for development
const MOCK_KEYS: AccessKey[] = [
  {
    id: 'key1',
    key: 'SCRIPT-1234-5678-ABCD',
    scriptId: 'script1',
    userId: 'user1',
    createdAt: Date.now() - 5 * 24 * 60 * 60 * 1000, // 5 days ago
  },
  {
    id: 'key2',
    key: 'SCRIPT-8765-4321-WXYZ',
    scriptId: 'script2',
    userId: 'admin1',
    createdAt: Date.now() - 10 * 24 * 60 * 60 * 1000, // 10 days ago
  }
];

// Generate a random access key
const generateRandomKey = (): string => {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let key = 'SCRIPT-';
  
  // Generate first group
  for (let i = 0; i < 4; i++) {
    key += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  
  key += '-';
  
  // Generate second group
  for (let i = 0; i < 4; i++) {
    key += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  
  key += '-';
  
  // Generate third group
  for (let i = 0; i < 4; i++) {
    key += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  
  return key;
};

// Get all access keys
export const getAccessKeys = async (): Promise<AccessKey[]> => {
  try {
    // For development, return mock data
    return MOCK_KEYS;

    // Production code
    /*
    const keysRef = collection(db, 'accessKeys');
    const q = query(keysRef, orderBy('createdAt', 'desc'));
    const querySnapshot = await getDocs(q);
    
    return querySnapshot.docs.map(doc => {
      const data = doc.data();
      return {
        id: doc.id,
        ...data,
        createdAt: data.createdAt?.toMillis() || Date.now(),
      } as AccessKey;
    });
    */
  } catch (error) {
    console.error('Error fetching access keys:', error);
    throw error;
  }
};

// Generate a new access key
export const generateAccessKey = async (scriptId: string, userId: string): Promise<AccessKey> => {
  try {
    const key = generateRandomKey();
    
    // For development, return mock success
    const newKey: AccessKey = {
      id: `key${MOCK_KEYS.length + 1}`,
      key,
      scriptId,
      userId,
      createdAt: Date.now(),
    };
    
    return newKey;

    // Production code
    /*
    const keyData = {
      key,
      scriptId,
      userId,
      createdAt: serverTimestamp(),
    };
    
    const docRef = await addDoc(collection(db, 'accessKeys'), keyData);
    
    return {
      id: docRef.id,
      ...keyData,
      createdAt: Date.now(),
    } as AccessKey;
    */
  } catch (error) {
    console.error('Error generating access key:', error);
    throw error;
  }
};

// Delete an access key
export const deleteAccessKey = async (keyId: string): Promise<void> => {
  try {
    // For development, mock success
    console.log('Access key deleted:', keyId);
    
    // Production code
    /*
    const keyRef = doc(db, 'accessKeys', keyId);
    await deleteDoc(keyRef);
    */
  } catch (error) {
    console.error('Error deleting access key:', error);
    throw error;
  }
};