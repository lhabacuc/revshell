import { db } from './firebase';
import { 
  collection, 
  addDoc, 
  updateDoc, 
  doc, 
  deleteDoc, 
  getDocs,
  getDoc, 
  query, 
  orderBy, 
  serverTimestamp,
  Timestamp
} from 'firebase/firestore';
import { Script } from '@/types';

// Mock data for development
const MOCK_SCRIPTS: Script[] = [
  {
    id: 'script1',
    title: 'Sistema de Gestão de Restaurante',
    description: 'Um sistema completo para gerenciar pedidos, estoque e funcionários de restaurantes. Inclui painéis administrativos e relatórios detalhados.',
    price: 75000,
    category: 'Web',
    imageUrl: 'https://images.pexels.com/photos/262978/pexels-photo-262978.jpeg',
    requirements: 'PHP 7.4+, MySQL 5.7+, Apache/Nginx',
    features: [
      'Gestão de pedidos em tempo real',
      'Controle de estoque com alertas',
      'Sistema de pagamento integrado',
      'Relatórios de vendas e lucros',
      'Gestão de funcionários e turnos'
    ],
    createdAt: Date.now(),
    authorId: 'admin1',
  },
  {
    id: 'script2',
    title: 'Aplicativo Mobile de Entrega',
    description: 'Aplicativo nativo para Android e iOS para serviços de entrega. Inclui rastreamento em tempo real e integração com pagamentos.',
    price: 120000,
    category: 'Mobile',
    imageUrl: 'https://images.pexels.com/photos/1337753/pexels-photo-1337753.jpeg',
    requirements: 'React Native, Firebase, Google Maps API',
    features: [
      'Rastreamento GPS em tempo real',
      'Integração com múltiplos métodos de pagamento',
      'Sistema de avaliação de entregadores',
      'Notificações push',
      'Histórico de pedidos'
    ],
    createdAt: Date.now(),
    authorId: 'admin1',
  },
  {
    id: 'script3',
    title: 'Sistema de Gestão Escolar',
    description: 'Sistema completo para gestão de escolas, com módulos para alunos, professores, notas, frequência e financeiro.',
    price: 95000,
    category: 'Web',
    imageUrl: 'https://images.pexels.com/photos/256417/pexels-photo-256417.jpeg',
    requirements: 'Laravel 8+, MySQL, PHP 7.4+',
    features: [
      'Gestão de matrículas e turmas',
      'Lançamento de notas e frequência',
      'Portal para pais e alunos',
      'Controle financeiro de mensalidades',
      'Relatórios acadêmicos'
    ],
    createdAt: Date.now(),
    authorId: 'admin1',
  }
];

// Fetch all scripts
export const fetchScripts = async (): Promise<Script[]> => {
  try {
    // For development, return mock data
    return MOCK_SCRIPTS;

    // Production code
    /*
    const scriptsRef = collection(db, 'scripts');
    const q = query(scriptsRef, orderBy('createdAt', 'desc'));
    const querySnapshot = await getDocs(q);
    
    return querySnapshot.docs.map(doc => {
      const data = doc.data();
      return {
        id: doc.id,
        ...data,
        createdAt: data.createdAt?.toMillis() || Date.now(),
      } as Script;
    });
    */
  } catch (error) {
    console.error('Error fetching scripts:', error);
    throw error;
  }
};

// Get script by ID
export const getScriptById = async (id: string): Promise<Script> => {
  try {
    // For development, return mock data
    const mockScript = MOCK_SCRIPTS.find(script => script.id === id);
    if (mockScript) {
      return mockScript;
    }
    throw new Error('Script not found');

    // Production code
    /*
    const scriptDoc = await getDoc(doc(db, 'scripts', id));
    
    if (!scriptDoc.exists()) {
      throw new Error('Script not found');
    }
    
    const data = scriptDoc.data();
    return {
      id: scriptDoc.id,
      ...data,
      createdAt: data.createdAt?.toMillis() || Date.now(),
    } as Script;
    */
  } catch (error) {
    console.error('Error getting script:', error);
    throw error;
  }
};

// Add a new script
export const addScript = async (scriptData: Partial<Script>): Promise<Script> => {
  try {
    // For development, return mock success
    return {
      ...scriptData,
      id: `script${MOCK_SCRIPTS.length + 1}`,
      createdAt: Date.now(),
      authorId: 'current-user-id',
    } as Script;

    // Production code
    /*
    const newScript = {
      ...scriptData,
      createdAt: serverTimestamp(),
      authorId: 'current-user-id', // Get from auth context
    };
    
    const docRef = await addDoc(collection(db, 'scripts'), newScript);
    
    return {
      id: docRef.id,
      ...newScript,
      createdAt: Date.now(),
    } as Script;
    */
  } catch (error) {
    console.error('Error adding script:', error);
    throw error;
  }
};

// Update script
export const updateScript = async (id: string, scriptData: Partial<Script>): Promise<void> => {
  try {
    // For development, mock success
    console.log('Script updated:', id, scriptData);
    
    // Production code
    /*
    const scriptRef = doc(db, 'scripts', id);
    await updateDoc(scriptRef, scriptData);
    */
  } catch (error) {
    console.error('Error updating script:', error);
    throw error;
  }
};

// Delete script
export const deleteScript = async (id: string): Promise<void> => {
  try {
    // For development, mock success
    console.log('Script deleted:', id);
    
    // Production code
    /*
    const scriptRef = doc(db, 'scripts', id);
    await deleteDoc(scriptRef);
    */
  } catch (error) {
    console.error('Error deleting script:', error);
    throw error;
  }
};