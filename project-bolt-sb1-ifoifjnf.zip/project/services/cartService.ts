import { db } from './firebase';
import { 
  collection, 
  addDoc, 
  getDocs, 
  query, 
  where, 
  deleteDoc, 
  doc, 
  writeBatch 
} from 'firebase/firestore';
import { CartItem, Script } from '@/types';

// Mock cart data for development
const MOCK_CART_ITEMS: Record<string, CartItem[]> = {
  'user1': [
    {
      id: 'cart1',
      title: 'Sistema de Gestão de Restaurante',
      price: 75000,
      category: 'Web',
      imageUrl: 'https://images.pexels.com/photos/262978/pexels-photo-262978.jpeg',
      scriptId: 'script1',
    }
  ],
  'admin1': []
};

// Fetch cart items for a user
export const fetchCartItems = async (userId: string): Promise<CartItem[]> => {
  try {
    // For development, return mock data
    return MOCK_CART_ITEMS[userId] || [];

    // Production code
    /*
    const cartRef = collection(db, 'users', userId, 'cart');
    const querySnapshot = await getDocs(cartRef);
    
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    } as CartItem));
    */
  } catch (error) {
    console.error('Error fetching cart items:', error);
    throw error;
  }
};

// Add item to cart
export const addToCart = async (userId: string, script: Script): Promise<void> => {
  try {
    // For development, mock success
    console.log('Added to cart:', userId, script);
    
    // Production code
    /*
    const cartItem: Omit<CartItem, 'id'> = {
      title: script.title,
      price: script.price,
      category: script.category,
      imageUrl: script.imageUrl,
      scriptId: script.id,
    };
    
    await addDoc(collection(db, 'users', userId, 'cart'), cartItem);
    */
  } catch (error) {
    console.error('Error adding item to cart:', error);
    throw error;
  }
};

// Remove item from cart
export const removeFromCart = async (userId: string, itemId: string): Promise<void> => {
  try {
    // For development, mock success
    console.log('Removed from cart:', userId, itemId);
    
    // Production code
    /*
    const itemRef = doc(db, 'users', userId, 'cart', itemId);
    await deleteDoc(itemRef);
    */
  } catch (error) {
    console.error('Error removing item from cart:', error);
    throw error;
  }
};

// Clear entire cart
export const clearCart = async (userId: string): Promise<void> => {
  try {
    // For development, mock success
    console.log('Cart cleared:', userId);
    
    // Production code
    /*
    const cartRef = collection(db, 'users', userId, 'cart');
    const querySnapshot = await getDocs(cartRef);
    
    const batch = writeBatch(db);
    querySnapshot.docs.forEach((doc) => {
      batch.delete(doc.ref);
    });
    
    await batch.commit();
    */
  } catch (error) {
    console.error('Error clearing cart:', error);
    throw error;
  }
};