import { db } from './firebase';
import { collection, getDocs, query, doc, updateDoc, getDoc } from 'firebase/firestore';
import { AdminRules } from '@/types';

// Mock data for development
const MOCK_RULES: AdminRules = {
  id: 'rules1',
  content: `# Regras para Administradores da Plataforma

1. Qualidade dos Scripts
   - Todos os scripts devem ser testados antes da publicação
   - Incluir documentação completa e instruções de uso
   - Especificar claramente os requisitos técnicos

2. Precificação
   - Estabelecer preços de acordo com a complexidade do script
   - Evitar variações de preço muito grandes entre scripts similares
   - Considerar o valor de mercado para soluções semelhantes

3. Aprovação de Conteúdo
   - Verificar se o script não contém códigos maliciosos
   - Garantir que não há violação de direitos autorais
   - Validar a compatibilidade com as versões declaradas

4. Atendimento ao Cliente
   - Responder às dúvidas dos clientes em até 24 horas
   - Fornecer suporte técnico básico para problemas de instalação
   - Tratar reclamações de forma educada e profissional

5. Geração de Chaves de Acesso
   - Criar chaves apenas para usuários que compraram o script
   - Manter um registro claro de todas as chaves geradas
   - Renovar chaves quando solicitado pelo cliente`,
  updatedAt: Date.now() - 15 * 24 * 60 * 60 * 1000, // 15 days ago
};

// Get admin rules
export const getRules = async (): Promise<AdminRules> => {
  try {
    // For development, return mock data
    return MOCK_RULES;

    // Production code
    /*
    const rulesDoc = await getDoc(doc(db, 'admin', 'rules'));
    
    if (!rulesDoc.exists()) {
      throw new Error('Rules not found');
    }
    
    const data = rulesDoc.data();
    return {
      id: rulesDoc.id,
      ...data,
      updatedAt: data.updatedAt?.toMillis() || Date.now(),
    } as AdminRules;
    */
  } catch (error) {
    console.error('Error getting admin rules:', error);
    throw error;
  }
};

// Update admin rules
export const updateRules = async (content: string): Promise<void> => {
  try {
    // For development, mock success
    console.log('Admin rules updated:', content);
    
    // Production code
    /*
    const rulesRef = doc(db, 'admin', 'rules');
    await updateDoc(rulesRef, { 
      content,
      updatedAt: serverTimestamp() 
    });
    */
  } catch (error) {
    console.error('Error updating admin rules:', error);
    throw error;
  }
};