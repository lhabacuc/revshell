import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

// Your Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBcw6juK7XNpZLbvD5IfQJUIbPE5IpzwlQ",
  authDomain: "scriptshop-57569.firebaseapp.com",
  projectId: "scriptshop-57569",
  storageBucket: "scriptshop-57569.appspot.com",
  messagingSenderId: "601780890077",
  appId: "1:601780890077:web:cdbb65d209949053a56e34",
  measurementId: "G-5CKZJXZS4P"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firebase services
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);

export default app;