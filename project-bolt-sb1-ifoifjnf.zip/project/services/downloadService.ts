import { db } from './firebase';
import { collection, query, where, getDocs, doc, getDoc, addDoc, serverTimestamp } from 'firebase/firestore';
import { getUserProfile, updateUserProfile } from './userService';
import { generateAccessKey } from './keyService';
import { User } from '@/types';

// Download a script
export const downloadScript = async (userId: string, scriptId: string): Promise<string | null> => {
  try {
    // Check if user has purchased the script
    const user = await getUserProfile(userId);
    
    if (!user.purchases.includes(scriptId)) {
      throw new Error('User has not purchased this script');
    }
    
    // Generate access key for the script
    const accessKey = await generateAccessKey(scriptId, userId);
    
    return accessKey.key;
  } catch (error) {
    console.error('Error downloading script:', error);
    throw error;
  }
};