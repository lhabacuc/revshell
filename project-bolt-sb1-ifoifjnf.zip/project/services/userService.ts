import { db } from './firebase';
import { doc, getDoc, setDoc, updateDoc } from 'firebase/firestore';
import { User } from '@/types';

// Mock users for development
const MOCK_USERS: Record<string, User> = {
  'user1': {
    id: 'user1',
    email: 'user@example.com',
    displayName: 'Usuário Teste',
    phoneNumber: '+244912345678',
    role: 'user',
    createdAt: Date.now() - 30 * 24 * 60 * 60 * 1000, // 30 days ago
    purchases: ['script1'],
  },
  'admin1': {
    id: 'admin1',
    email: 'admin@example.com',
    displayName: 'Admin Teste',
    phoneNumber: '+244987654321',
    role: 'admin',
    createdAt: Date.now() - 60 * 24 * 60 * 60 * 1000, // 60 days ago
    purchases: ['script1', 'script2', 'script3'],
  }
};

// Get user profile
export const getUserProfile = async (userId: string): Promise<User> => {
  try {
    // For development, return mock data
    if (userId === 'user@example.com' || userId === 'user') {
      return MOCK_USERS['user1'];
    } else if (userId === 'admin@example.com' || userId === 'admin') {
      return MOCK_USERS['admin1'];
    }
    
    // Create a simple mock user for development
    return {
      id: userId,
      email: 'user@example.com',
      displayName: 'Usuário',
      phoneNumber: '+244000000000',
      role: userId.includes('admin') ? 'admin' : 'user',
      createdAt: Date.now(),
      purchases: [],
    };

    // Production code
    /*
    const userDoc = await getDoc(doc(db, 'users', userId));
    
    if (!userDoc.exists()) {
      throw new Error('User not found');
    }
    
    return userDoc.data() as User;
    */
  } catch (error) {
    console.error('Error getting user profile:', error);
    throw error;
  }
};

// Create user profile
export const createUserProfile = async (userId: string, userData: User): Promise<void> => {
  try {
    // For development, mock success
    console.log('User profile created:', userId, userData);
    
    // Production code
    /*
    await setDoc(doc(db, 'users', userId), userData);
    */
  } catch (error) {
    console.error('Error creating user profile:', error);
    throw error;
  }
};

// Update user profile
export const updateUserProfile = async (userId: string, userData: Partial<User>): Promise<void> => {
  try {
    // For development, mock success
    console.log('User profile updated:', userId, userData);
    
    // Production code
    /*
    const userRef = doc(db, 'users', userId);
    await updateDoc(userRef, userData);
    */
  } catch (error) {
    console.error('Error updating user profile:', error);
    throw error;
  }
};