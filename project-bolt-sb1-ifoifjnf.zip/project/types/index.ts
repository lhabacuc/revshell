export interface User {
  id: string;
  email: string;
  displayName: string;
  phoneNumber: string;
  role: 'user' | 'admin';
  createdAt: number;
  purchases: string[]; // Array of script IDs purchased by the user
}

export interface Script {
  id: string;
  title: string;
  description: string;
  price: number;
  category: string;
  imageUrl?: string;
  requirements?: string;
  features?: string[];
  createdAt: number;
  authorId: string;
}

export interface CartItem {
  id: string;
  title: string;
  price: number;
  category: string;
  imageUrl?: string;
  scriptId: string;
}

export interface AccessKey {
  id: string;
  key: string;
  scriptId: string;
  userId: string;
  createdAt: number;
}

export interface AdminRules {
  id: string;
  content: string;
  updatedAt: number;
}