import React, { useState, useEffect } from 'react';
import { Box, TestTube as Cubes, Layers, PlusSquare, Package, Network, Copy, LineChart, Brain, LogOut, Play, Square, Trash2, FileText, Server, Monitor, Database, Plus } from 'lucide-react';

// Types for Docker API responses
interface Container {
  Id: string;
  Names: string[];
  Image: string;
  ImageID: string;
  Command: string;
  Created: number;
  State: string;
  Status: string;
  Ports: {
    IP?: string;
    PrivatePort: number;
    PublicPort?: number;
    Type: string;
  }[];
  Labels: Record<string, string>;
  HostConfig: {
    NetworkMode: string;
  };
  NetworkSettings: {
    Networks: Record<string, {
      IPAddress: string;
      Gateway: string;
      MacAddress: string;
    }>;
  };
  Mounts: {
    Type: string;
    Source: string;
    Destination: string;
    Mode: string;
    RW: boolean;
    Propagation: string;
  }[];
}

interface Image {
  Id: string;
  RepoTags: string[];
  RepoDigests: string[];
  Created: number;
  Size: number;
  VirtualSize: number;
  SharedSize: number;
  Labels: Record<string, string>;
  Containers: number;
}

interface Network {
  Name: string;
  Id: string;
  Created: string;
  Scope: string;
  Driver: string;
  EnableIPv6: boolean;
  IPAM: {
    Driver: string;
    Options: Record<string, string>;
    Config: {
      Subnet: string;
      Gateway: string;
    }[];
  };
  Internal: boolean;
  Attachable: boolean;
  Ingress: boolean;
  ConfigFrom: {
    Network: string;
  };
  ConfigOnly: boolean;
  Containers: Record<string, {
    Name: string;
    EndpointID: string;
    MacAddress: string;
    IPv4Address: string;
    IPv6Address: string;
  }>;
  Options: Record<string, string>;
  Labels: Record<string, string>;
}

interface ContainerStats {
  id: string;
  name: string;
  cpu: string;
  memory: string;
  memoryLimit: string;
  networkRx: string;
  networkTx: string;
}

interface ProjectSettings {
  name: string;
  containerType: string;
  appPortInternal: string;
  appPortExternal: string;
  installCodeServer: boolean;
  codeServerPortInternal: string;
  codeServerPortExternal: string;
  codeServerPassword: string;
  additionalPackages: string[];
  fromTemplate?: boolean;
}

interface IASettings {
  provider: string;
  apiKey: string;
  model: string;
  tokenLimit: string;
}

interface ProjectTemplate {
  id: string;
  name: string;
  icon: string;
  description: string;
  settings: ProjectSettings & {
    complementary?: {
      type: string;
      name: string;
      autoAdd: boolean;
      settings?: Partial<ProjectSettings>;
    }[];
  };
}

interface Package {
  id: string;
  name: string;
  icon: string;
}

function App() {
  // Authentication state
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isFirstLogin, setIsFirstLogin] = useState(true);
  const [showChangePasswordModal, setShowChangePasswordModal] = useState(false);
  const [loginError, setLoginError] = useState('');
  const [passwordChangeError, setPasswordChangeError] = useState('');
  
  // View state
  const [activeView, setActiveView] = useState('dashboard-view');
  
  // Docker data
  const [containers, setContainers] = useState<Container[]>([]);
  const [images, setImages] = useState<Image[]>([]);
  const [networks, setNetworks] = useState<Network[]>([]);
  const [containerStats, setContainerStats] = useState<ContainerStats[]>([]);
  
  // Project creation state
  const [currentProjectSettings, setCurrentProjectSettings] = useState<ProjectSettings>({
    name: '',
    containerType: 'backend',
    appPortInternal: '',
    appPortExternal: '',
    installCodeServer: false,
    codeServerPortInternal: '8080',
    codeServerPortExternal: '8443',
    codeServerPassword: '',
    additionalPackages: []
  });
  
  // Modal states
  const [showLogsModal, setShowLogsModal] = useState(false);
  const [showCreateNetworkModal, setShowCreateNetworkModal] = useState(false);
  const [currentContainerLogs, setCurrentContainerLogs] = useState({ id: '', name: '', logs: '' });
  
  // IA settings
  const [iaSettings, setIaSettings] = useState<IASettings>({
    provider: 'gemini',
    apiKey: '',
    model: 'gemini-pro',
    tokenLimit: '4096'
  });
  const [iaSaveFeedback, setIaSaveFeedback] = useState('');
  
  // Project creation flow state
  const [showProjectDetailsStep, setShowProjectDetailsStep] = useState(true);
  const [showContainerBaseConfigStep, setShowContainerBaseConfigStep] = useState(false);
  const [showCodeServerSetupStep, setShowCodeServerSetupStep] = useState(false);
  const [showAdditionalPackagesStep, setShowAdditionalPackagesStep] = useState(false);
  const [showContainerConfigReviewStep, setShowContainerConfigReviewStep] = useState(false);
  const [showComplementarySuggestions, setShowComplementarySuggestions] = useState(false);
  const [generatedDockerfile, setGeneratedDockerfile] = useState('');
  const [imageName, setImageName] = useState('');
  
  // Error toast state
  const [errorToast, setErrorToast] = useState({ show: false, message: '' });
  
  // Available packages for container creation
  const availablePackages: Package[] = [
    { id: 'git', name: 'Git', icon: 'git-branch' },
    { id: 'vim', name: 'Vim', icon: 'file-code' },
    { id: 'nano', name: 'Nano', icon: 'file' },
    { id: 'curl', name: 'cURL', icon: 'download-cloud' },
    { id: 'wget', name: 'Wget', icon: 'download' },
    { id: 'bash', name: 'Bash Shell', icon: 'terminal' },
    { id: 'zsh', name: 'Zsh Shell', icon: 'terminal' },
    { id: 'python3', name: 'Python 3', icon: 'code' },
    { id: 'pip', name: 'Pip (Python)', icon: 'package' },
    { id: 'nodejs', name: 'Node.js', icon: 'server' },
    { id: 'npm', name: 'NPM (Node)', icon: 'package' },
    { id: 'docker-cli', name: 'Docker CLI', icon: 'box' },
    { id: 'kubectl', name: 'Kubectl', icon: 'command' },
    { id: 'aws-cli', name: 'AWS CLI', icon: 'cloud' },
    { id: 'gcloud-sdk', name: 'gcloud SDK', icon: 'cloud' },
    { id: 'build-essential', name: 'Build Essential', icon: 'tool' },
    { id: 'build-base', name: 'Build Base (Alpine)', icon: 'tool' },
    { id: 'openssh-client', name: 'OpenSSH Client', icon: 'key' },
    { id: 'tree', name: 'Tree', icon: 'git-branch' },
    { id: 'htop', name: 'Htop', icon: 'activity' },
    { id: 'jq', name: 'jq (JSON processor)', icon: 'code' },
    { id: 'unzip', name: 'Unzip', icon: 'archive' },
    { id: 'tar', name: 'Tar', icon: 'archive' },
    { id: 'net-tools', name: 'Net Tools (netstat)', icon: 'wifi' },
    { id: 'iproute2', name: 'iproute2 (ip cmd)', icon: 'map' },
    { id: 'openjdk-11-jre', name: 'OpenJDK 11 JRE', icon: 'coffee' },
    { id: 'maven', name: 'Maven (Java)', icon: 'settings' },
    { id: 'gradle', name: 'Gradle (Java)', icon: 'settings' },
    { id: 'ruby', name: 'Ruby', icon: 'gem' },
    { id: 'go', name: 'Go Language', icon: 'code' },
    { id: 'mysql-client', name: 'MySQL Client', icon: 'database' },
    { id: 'postgresql-client', name: 'PostgreSQL Client', icon: 'database' }
  ];
  
  // Project templates
  const projectTemplates: ProjectTemplate[] = [
    {
      id: 'node-redis',
      name: 'Node.js + Redis',
      icon: 'server',
      description: 'Backend Node.js com Express, conectado a um container Redis para cache.',
      settings: {
        projectName: 'node-redis-app',
        containerType: 'backend',
        appPortInternal: '3000',
        appPortExternal: '3000',
        installCodeServer: true,
        codeServerPortInternal: '8080',
        codeServerPortExternal: '8443',
        additionalPackages: ['git', 'nodejs', 'npm', 'curl'],
        complementary: [{ type: 'database', name: 'Redis', autoAdd: true }]
      }
    },
    {
      id: 'react-nginx',
      name: 'React + Nginx',
      icon: 'monitor',
      description: 'Frontend React buildado e servido por Nginx, otimizado para produção.',
      settings: {
        projectName: 'react-nginx-app',
        containerType: 'frontend',
        appPortInternal: '80',
        appPortExternal: '80',
        installCodeServer: false,
        codeServerPortInternal: '',
        codeServerPortExternal: '',
        codeServerPassword: '',
        additionalPackages: ['git']
      }
    },
    {
      id: 'python-flask',
      name: 'Python Flask API',
      icon: 'code',
      description: 'API backend leve com Python Flask, pronta para microserviços.',
      settings: {
        projectName: 'python-flask-api',
        containerType: 'backend',
        appPortInternal: '5000',
        appPortExternal: '5000',
        installCodeServer: true,
        codeServerPortInternal: '8081',
        codeServerPortExternal: '8444',
        additionalPackages: ['git', 'python3', 'pip', 'wget'],
        codeServerPassword: ''
      }
    },
    {
      id: 'lemp-stack',
      name: 'Stack LEMP',
      icon: 'server',
      description: 'Linux, Nginx, MySQL (MariaDB) e PHP para aplicações web tradicionais.',
      settings: {
        projectName: 'lemp-app',
        containerType: 'frontend',
        appPortInternal: '80',
        appPortExternal: '8088',
        installCodeServer: false,
        codeServerPortInternal: '',
        codeServerPortExternal: '',
        codeServerPassword: '',
        additionalPackages: ['nginx', 'php', 'php-fpm', 'mariadb-client'],
        complementary: [{ type: 'database', name: 'MariaDB', autoAdd: true }]
      }
    }
  ];
  
  // Network drag and drop state
  const [draggedItem, setDraggedItem] = useState<string | null>(null);
  
  // Fetch Docker data on component mount
  useEffect(() => {
    if (isLoggedIn) {
      fetchContainers();
      fetchImages();
      fetchNetworks();
      
      // Set up polling for container stats
      const statsInterval = setInterval(() => {
        fetchContainerStats();
      }, 5000);
      
      return () => clearInterval(statsInterval);
    }
  }, [isLoggedIn]);
  
  // API functions for Docker operations
  const fetchContainers = async () => {
    try {
      // In a real implementation, this would call the Docker API
      // For now, we'll use mock data
      const mockContainers: Container[] = [
        {
          Id: 'container1',
          Names: ['/meu-backend-1'],
          Image: 'meu-backend-app:latest',
          ImageID: 'sha256:a1b2c3d4e5',
          Command: 'node server.js',
          Created: Date.now() / 1000 - 3600,
          State: 'running',
          Status: 'Up 1 hour',
          Ports: [
            { PrivatePort: 3000, PublicPort: 8080, Type: 'tcp' },
            { PrivatePort: 8080, PublicPort: 8443, Type: 'tcp' }
          ],
          Labels: {},
          HostConfig: { NetworkMode: 'bridge' },
          NetworkSettings: {
            Networks: {
              bridge: {
                IPAddress: '172.17.0.2',
                Gateway: '172.17.0.1',
                MacAddress: '02:42:ac:11:00:02'
              }
            }
          },
          Mounts: []
        },
        {
          Id: 'container2',
          Names: ['/meu-frontend-1'],
          Image: 'meu-frontend-app:v1.2',
          ImageID: 'sha256:f6g7h8i9j0',
          Command: 'nginx -g daemon off;',
          Created: Date.now() / 1000 - 7200,
          State: 'running',
          Status: 'Up 2 hours',
          Ports: [
            { PrivatePort: 80, PublicPort: 80, Type: 'tcp' }
          ],
          Labels: {},
          HostConfig: { NetworkMode: 'bridge' },
          NetworkSettings: {
            Networks: {
              bridge: {
                IPAddress: '172.17.0.3',
                Gateway: '172.17.0.1',
                MacAddress: '02:42:ac:11:00:03'
              }
            }
          },
          Mounts: []
        },
        {
          Id: 'container3',
          Names: ['/meu-db-pg'],
          Image: 'postgres:15-alpine',
          ImageID: 'sha256:b2c3d4e5f6',
          Command: 'postgres',
          Created: Date.now() / 1000 - 10800,
          State: 'exited',
          Status: 'Exited (0) 1 hour ago',
          Ports: [
            { PrivatePort: 5432, PublicPort: 5432, Type: 'tcp' }
          ],
          Labels: {},
          HostConfig: { NetworkMode: 'bridge' },
          NetworkSettings: {
            Networks: {
              bridge: {
                IPAddress: '172.17.0.4',
                Gateway: '172.17.0.1',
                MacAddress: '02:42:ac:11:00:04'
              }
            }
          },
          Mounts: []
        }
      ];
      
      setContainers(mockContainers);
    } catch (error) {
      console.error('Error fetching containers:', error);
      displayErrorToast('Erro ao buscar containers');
    }
  };
  
  const fetchImages = async () => {
    try {
      // In a real implementation, this would call the Docker API
      // For now, we'll use mock data
      const mockImages: Image[] = [
        {
          Id: 'sha256:a1b2c3d4e5',
          RepoTags: ['meu-backend-app:latest'],
          RepoDigests: [],
          Created: Date.now() / 1000 - 86400,
          Size: 150000000,
          VirtualSize: 150000000,
          SharedSize: 0,
          Labels: {},
          Containers: 1
        },
        {
          Id: 'sha256:f6g7h8i9j0',
          RepoTags: ['meu-frontend-app:v1.2'],
          RepoDigests: [],
          Created: Date.now() / 1000 - 172800,
          Size: 85000000,
          VirtualSize: 85000000,
          SharedSize: 0,
          Labels: {},
          Containers: 1
        },
        {
          Id: 'sha256:b2c3d4e5f6',
          RepoTags: ['postgres:15-alpine'],
          RepoDigests: [],
          Created: Date.now() / 1000 - 259200,
          Size: 75000000,
          VirtualSize: 75000000,
          SharedSize: 0,
          Labels: {},
          Containers: 1
        }
      ];
      
      setImages(mockImages);
    } catch (error) {
      console.error('Error fetching images:', error);
      displayErrorToast('Erro ao buscar imagens');
    }
  };
  
  const fetchNetworks = async () => {
    try {
      // In a real implementation, this would call the Docker API
      // For now, we'll use mock data
      const mockNetworks: Network[] = [
        {
          Name: 'bridge',
          Id: 'network1',
          Created: new Date().toISOString(),
          Scope: 'local',
          Driver: 'bridge',
          EnableIPv6: false,
          IPAM: {
            Driver: 'default',
            Options: {},
            Config: [
              {
                Subnet: '172.17.0.0/16',
                Gateway: '172.17.0.1'
              }
            ]
          },
          Internal: false,
          Attachable: false,
          Ingress: false,
          ConfigFrom: { Network: '' },
          ConfigOnly: false,
          Containers: {
            container1: {
              Name: 'meu-backend-1',
              EndpointID: 'endpoint1',
              MacAddress: '02:42:ac:11:00:02',
              IPv4Address: '172.17.0.2/16',
              IPv6Address: ''
            },
            container2: {
              Name: 'meu-frontend-1',
              EndpointID: 'endpoint2',
              MacAddress: '02:42:ac:11:00:03',
              IPv4Address: '172.17.0.3/16',
              IPv6Address: ''
            }
          },
          Options: {},
          Labels: {}
        },
        {
          Name: 'host',
          Id: 'network2',
          Created: new Date().toISOString(),
          Scope: 'local',
          Driver: 'host',
          EnableIPv6: false,
          IPAM: {
            Driver: 'default',
            Options: {},
            Config: []
          },
          Internal: false,
          Attachable: false,
          Ingress: false,
          ConfigFrom: { Network: '' },
          ConfigOnly: false,
          Containers: {},
          Options: {},
          Labels: {}
        },
        {
          Name: 'app_network_1',
          Id: 'network3',
          Created: new Date().toISOString(),
          Scope: 'local',
          Driver: 'bridge',
          EnableIPv6: false,
          IPAM: {
            Driver: 'default',
            Options: {},
            Config: [
              {
                Subnet: '172.18.0.0/16',
                Gateway: '172.18.0.1'
              }
            ]
          },
          Internal: false,
          Attachable: false,
          Ingress: false,
          ConfigFrom: { Network: '' },
          ConfigOnly: false,
          Containers: {},
          Options: {},
          Labels: {}
        }
      ];
      
      setNetworks(mockNetworks);
    } catch (error) {
      console.error('Error fetching networks:', error);
      displayErrorToast('Erro ao buscar redes');
    }
  };
  
  const fetchContainerStats = async () => {
    try {
      // In a real implementation, this would call the Docker API
      // For now, we'll use mock data
      const mockStats: ContainerStats[] = [
        {
          id: 'container1',
          name: 'meu-backend-1',
          cpu: '25%',
          memory: '612MB',
          memoryLimit: '1.2GB',
          networkRx: '1.2MB',
          networkTx: '300KB'
        },
        {
          id: 'container2',
          name: 'meu-frontend-1',
          cpu: '10%',
          memory: '128MB',
          memoryLimit: '512MB',
          networkRx: '5.6MB',
          networkTx: '1.2MB'
        },
        {
          id: 'container3',
          name: 'meu-db-pg',
          cpu: 'N/A',
          memory: 'N/A',
          memoryLimit: 'N/A',
          networkRx: 'N/A',
          networkTx: 'N/A'
        }
      ];
      
      setContainerStats(mockStats);
    } catch (error) {
      console.error('Error fetching container stats:', error);
      // Don't show error toast for stats to avoid spamming the user
    }
  };
  
  const fetchContainerLogs = async (containerId: string) => {
    try {
      // In a real implementation, this would call the Docker API
      // For now, we'll use mock data
      const container = containers.find(c => c.Id === containerId);
      if (!container) {
        throw new Error('Container not found');
      }
      
      let mockLogs = '';
      if (container.Names[0].includes('backend')) {
        mockLogs = `Log...\nCode-server na porta 8080 (interna).\nServer started on port 3000\nConnected to database\nAPI endpoints registered\nHealthcheck passed`;
      } else if (container.Names[0].includes('frontend')) {
        mockLogs = `Log...\nNginx started\nServing static files from /usr/share/nginx/html\nAccess log: 172.17.0.1 - - [${new Date().toISOString()}] "GET / HTTP/1.1" 200 1839 "-" "Mozilla/5.0"`;
      } else if (container.Names[0].includes('db')) {
        mockLogs = `Log...\nPostgreSQL database system is ready to accept connections\nDatabase system was shut down at ${new Date().toISOString()}`;
      }
      
      setCurrentContainerLogs({
        id: containerId,
        name: container.Names[0].replace('/', ''),
        logs: mockLogs
      });
      
      setShowLogsModal(true);
    } catch (error) {
      console.error('Error fetching container logs:', error);
      displayErrorToast('Erro ao buscar logs do container');
    }
  };
  
  const startContainer = async (containerId: string) => {
    try {
      // In a real implementation, this would call the Docker API
      // For now, we'll update the mock data
      setContainers(prevContainers => 
        prevContainers.map(container => 
          container.Id === containerId
            ? { ...container, State: 'running', Status: 'Up 1 second' }
            : container
        )
      );
      
      displayErrorToast('Container iniciado com sucesso', false);
    } catch (error) {
      console.error('Error starting container:', error);
      displayErrorToast('Erro ao iniciar container');
    }
  };
  
  const stopContainer = async (containerId: string) => {
    try {
      // In a real implementation, this would call the Docker API
      // For now, we'll update the mock data
      setContainers(prevContainers => 
        prevContainers.map(container => 
          container.Id === containerId
            ? { ...container, State: 'exited', Status: 'Exited (0) 1 second ago' }
            : container
        )
      );
      
      displayErrorToast('Container parado com sucesso', false);
    } catch (error) {
      console.error('Error stopping container:', error);
      displayErrorToast('Erro ao parar container');
    }
  };
  
  const removeContainer = async (containerId: string) => {
    try {
      // In a real implementation, this would call the Docker API
      // For now, we'll update the mock data
      setContainers(prevContainers => 
        prevContainers.filter(container => container.Id !== containerId)
      );
      
      displayErrorToast('Container removido com sucesso', false);
    } catch (error) {
      console.error('Error removing container:', error);
      displayErrorToast('Erro ao remover container');
    }
  };
  
  const removeImage = async (imageId: string) => {
    try {
      // In a real implementation, this would call the Docker API
      // For now, we'll update the mock data
      setImages(prevImages => 
        prevImages.filter(image => image.Id !== imageId)
      );
      
      displayErrorToast('Imagem removida com sucesso', false);
    } catch (error) {
      console.error('Error removing image:', error);
      displayErrorToast('Erro ao remover imagem');
    }
  };
  
  const createNetwork = async (name: string, driver: string, subnet?: string) => {
    try {
      // In a real implementation, this would call the Docker API
      // For now, we'll update the mock data
      const newNetwork: Network = {
        Name: name,
        Id: `network${networks.length + 1}`,
        Created: new Date().toISOString(),
        Scope: 'local',
        Driver: driver,
        EnableIPv6: false,
        IPAM: {
          Driver: 'default',
          Options: {},
          Config: subnet
            ? [
                {
                  Subnet: subnet,
                  Gateway: subnet.replace(/\/\d+$/, '.1')
                }
              ]
            : []
        },
        Internal: false,
        Attachable: false,
        Ingress: false,
        ConfigFrom: { Network: '' },
        ConfigOnly: false,
        Containers: {},
        Options: {},
        Labels: {}
      };
      
      setNetworks(prevNetworks => [...prevNetworks, newNetwork]);
      
      displayErrorToast('Rede criada com sucesso', false);
    } catch (error) {
      console.error('Error creating network:', error);
      displayErrorToast('Erro ao criar rede');
    }
  };
  
  const connectContainerToNetwork = async (containerId: string, networkId: string) => {
    try {
      // In a real implementation, this would call the Docker API
      // For now, we'll update the mock data
      const container = containers.find(c => c.Id === containerId);
      const network = networks.find(n => n.Id === networkId);
      
      if (!container || !network) {
        throw new Error('Container or network not found');
      }
      
      setNetworks(prevNetworks => 
        prevNetworks.map(n => {
          if (n.Id === networkId) {
            return {
              ...n,
              Containers: {
                ...n.Containers,
                [containerId]: {
                  Name: container.Names[0].replace('/', ''),
                  EndpointID: `endpoint${Object.keys(n.Containers).length + 1}`,
                  MacAddress: `02:42:ac:${networkId.slice(-2)}:00:${containerId.slice(-2)}`,
                  IPv4Address: `172.${networkId.slice(-2)}.0.${containerId.slice(-1)}/16`,
                  IPv6Address: ''
                }
              }
            };
          }
          return n;
        })
      );
      
      displayErrorToast('Container conectado à rede com sucesso', false);
    } catch (error) {
      console.error('Error connecting container to network:', error);
      displayErrorToast('Erro ao conectar container à rede');
    }
  };
  
  const createContainer = async () => {
    try {
      // In a real implementation, this would call the Docker API to build the image and create the container
      // For now, we'll update the mock data
      const { name, containerType, appPortInternal, appPortExternal, installCodeServer, codeServerPortInternal, codeServerPortExternal, additionalPackages } = currentProjectSettings;
      
      // Create image
      const newImageId = `sha256:${Math.random().toString(16).slice(2, 12)}`;
      const newImage: Image = {
        Id: newImageId,
        RepoTags: [imageName],
        RepoDigests: [],
        Created: Date.now() / 1000,
        Size: Math.floor(Math.random() * 100 + (installCodeServer ? 80 : 30) + (additionalPackages.length * 5)) * 1000000,
        VirtualSize: Math.floor(Math.random() * 100 + (installCodeServer ? 80 : 30) + (additionalPackages.length * 5)) * 1000000,
        SharedSize: 0,
        Labels: {},
        Containers: 1
      };
      
      setImages(prevImages => [...prevImages, newImage]);
      
      // Create container
      const newContainerId = `container${containers.length + 1}`;
      const newContainerName = `/${name}-${containerType}-${containers.length + 1}`;
      
      const ports: { PrivatePort: number; PublicPort?: number; Type: string }[] = [];
      
      if (appPortInternal) {
        ports.push({
          PrivatePort: parseInt(appPortInternal),
          PublicPort: appPortExternal ? parseInt(appPortExternal) : undefined,
          Type: 'tcp'
        });
      }
      
      if (installCodeServer && codeServerPortInternal) {
        ports.push({
          PrivatePort: parseInt(codeServerPortInternal),
          PublicPort: codeServerPortExternal ? parseInt(codeServerPortExternal) : undefined,
          Type: 'tcp'
        });
      }
      
      const newContainer: Container = {
        Id: newContainerId,
        Names: [newContainerName],
        Image: imageName,
        ImageID: newImageId,
        Command: containerType === 'backend' ? 'node server.js' : containerType === 'frontend' ? 'nginx -g daemon off;' : 'postgres',
        Created: Date.now() / 1000,
        State: 'running',
        Status: 'Up 1 second',
        Ports: ports,
        Labels: {},
        HostConfig: { NetworkMode: 'bridge' },
        NetworkSettings: {
          Networks: {
            bridge: {
              IPAddress: `172.17.0.${containers.length + 2}`,
              Gateway: '172.17.0.1',
              MacAddress: `02:42:ac:11:00:0${containers.length + 2}`
            }
          }
        },
        Mounts: []
      };
      
      setContainers(prevContainers => [...prevContainers, newContainer]);
      
      // Create container stats
      const newStats: ContainerStats = {
        id: newContainerId,
        name: newContainerName.replace('/', ''),
        cpu: '2%',
        memory: '64MB',
        memoryLimit: '256MB',
        networkRx: '0',
        networkTx: '0'
      };
      
      setContainerStats(prevStats => [...prevStats, newStats]);
      
      displayErrorToast('Container e imagem criados com sucesso', false);
      
      // Show complementary suggestions
      if (containerType === 'backend' || containerType === 'frontend') {
        setShowComplementarySuggestions(true);
      } else {
        resetCreateProjectFlow();
        setActiveView('containers-view');
      }
    } catch (error) {
      console.error('Error creating container:', error);
      displayErrorToast('Erro ao criar container');
    }
  };
  
  // Helper functions
  const displayErrorToast = (message: string, isError = true) => {
    setErrorToast({ show: true, message });
    setTimeout(() => {
      setErrorToast({ show: false, message: '' });
    }, 5000);
  };
  
  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };
  
  const getPortsString = (ports: { PrivatePort: number; PublicPort?: number; Type: string }[]) => {
    return ports.map(port => 
      port.PublicPort 
        ? `${port.PublicPort}:${port.PrivatePort}` 
        : `?:${port.PrivatePort}`
    ).join(', ') || 'N/A';
  };
  
  // Login and authentication functions
  const handleLogin = (event: React.FormEvent) => {
    event.preventDefault();
    const usernameInput = document.getElementById('username') as HTMLInputElement;
    const passwordInput = document.getElementById('password') as HTMLInputElement;
    
    const username = usernameInput.value;
    const password = passwordInput.value;
    
    if (username === 'root' && password === 'root1234') {
      setLoginError('');
      if (isFirstLogin) {
        setShowChangePasswordModal(true);
      } else {
        setIsLoggedIn(true);
        setActiveView('dashboard-view');
      }
    } else {
      setLoginError('Credenciais inválidas.');
    }
  };
  
  const handleChangePassword = (event: React.FormEvent) => {
    event.preventDefault();
    const newPasswordInput = document.getElementById('new-password') as HTMLInputElement;
    const confirmPasswordInput = document.getElementById('confirm-password') as HTMLInputElement;
    
    const newPassword = newPasswordInput.value;
    const confirmPassword = confirmPasswordInput.value;
    
    if (newPassword.length < 8) {
      setPasswordChangeError('A nova senha deve ter pelo menos 8 caracteres.');
      return;
    }
    
    if (newPassword === 'root1234') {
      setPasswordChangeError('A nova senha não pode ser igual à senha padrão.');
      return;
    }
    
    if (!/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/.test(newPassword)) {
      setPasswordChangeError('A senha deve conter letras maiúsculas, minúsculas e números.');
      return;
    }
    
    if (newPassword === confirmPassword) {
      setPasswordChangeError('');
      setIsFirstLogin(false);
      setShowChangePasswordModal(false);
      setIsLoggedIn(true);
      setActiveView('dashboard-view');
      console.log("Nova senha (simulada):", newPassword);
    } else {
      setPasswordChangeError('As senhas não conferem.');
    }
  };
  
  const handleLogout = () => {
    setIsLoggedIn(false);
    setActiveView('dashboard-view');
  };
  
  // Project creation functions
  const resetCreateProjectFlow = () => {
    setCurrentProjectSettings({
      name: '',
      containerType: 'backend',
      appPortInternal: '',
      appPortExternal: '',
      installCodeServer: false,
      codeServerPortInternal: '8080',
      codeServerPortExternal: '8443',
      codeServerPassword: '',
      additionalPackages: [],
      fromTemplate: false
    });
    
    setShowProjectDetailsStep(true);
    setShowContainerBaseConfigStep(false);
    setShowCodeServerSetupStep(false);
    setShowAdditionalPackagesStep(false);
    setShowContainerConfigReviewStep(false);
    setShowComplementarySuggestions(false);
    
    setGeneratedDockerfile('');
    setImageName('');
  };
  
  const handleProjectDetailsNext = () => {
    setCurrentProjectSettings(prev => ({
      ...prev,
      name: (document.getElementById('project-name') as HTMLInputElement).value || "meu-projeto",
      containerType: (document.getElementById('container-type') as HTMLSelectElement).value
    }));
    
    setShowProjectDetailsStep(false);
    setShowContainerBaseConfigStep(true);
  };
  
  const handleContainerBaseConfigNext = () => {
    const appPortInternal = (document.getElementById('app-port-internal') as HTMLInputElement).value;
    const appPortExternal = (document.getElementById('app-port-external') as HTMLInputElement).value;
    
    if (!appPortInternal && currentProjectSettings.containerType !== 'database' && currentProjectSettings.containerType !== 'other') {
      displayErrorToast('Por favor, defina a porta interna da aplicação.');
      return;
    }
    
    if (!appPortExternal && currentProjectSettings.containerType !== 'database' && currentProjectSettings.containerType !== 'other') {
      displayErrorToast('Por favor, defina a porta externa (host) da aplicação.');
      return;
    }
    
    setCurrentProjectSettings(prev => ({
      ...prev,
      appPortInternal,
      appPortExternal
    }));
    
    setShowContainerBaseConfigStep(false);
    setShowCodeServerSetupStep(true);
  };
  
  const handleCodeServerSetupNext = () => {
    const installCodeServer = (document.querySelector('input[name="install-code-server"]:checked') as HTMLInputElement)?.value === 'yes';
    
    let codeServerPortInternal = '';
    let codeServerPortExternal = '';
    let codeServerPassword = '';
    
    if (installCodeServer) {
      codeServerPortInternal = (document.getElementById('code-server-port-internal') as HTMLInputElement).value || '8080';
      codeServerPortExternal = (document.getElementById('code-server-port-external') as HTMLInputElement).value || '8443';
      codeServerPassword = (document.getElementById('code-server-password') as HTMLInputElement).value;
      
      if (!codeServerPortInternal || !codeServerPortExternal) {
        displayErrorToast('Por favor, defina as portas interna e externa para o Code-Server.');
        return;
      }
    }
    
    setCurrentProjectSettings(prev => ({
      ...prev,
      installCodeServer,
      codeServerPortInternal,
      codeServerPortExternal,
      codeServerPassword
    }));
    
    setShowCodeServerSetupStep(false);
    setShowAdditionalPackagesStep(true);
  };
  
  const handleAdditionalPackagesNext = () => {
    const additionalPackages: string[] = [];
    const packageCheckboxes = document.querySelectorAll('#packages-checkbox-grid input[type="checkbox"]:checked') as NodeListOf<HTMLInputElement>;
    packageCheckboxes.forEach(cb => additionalPackages.push(cb.value));
    
    setCurrentProjectSettings(prev => ({
      ...prev,
      additionalPackages
    }));
    
    generateDockerfile();
    
    setShowAdditionalPackagesStep(false);
    setShowContainerConfigReviewStep(true);
  };
  
  const generateDockerfile = () => {
    const { containerType, appPortInternal, installCodeServer, codeServerPortInternal, codeServerPassword, additionalPackages } = currentProjectSettings;
    let dockerfileContent = "";
    let baseImage = "", mainCmd = "";
    let finalAppPortInternal = appPortInternal;
    
    switch (containerType) {
      case 'backend':
        baseImage = "node:18-alpine";
        finalAppPortInternal = appPortInternal || '3000';
        mainCmd = `CMD [ "node", "server.js" ]`;
        dockerfileContent = `FROM ${baseImage} AS builder\nWORKDIR /usr/src/app\nCOPY package*.json ./\nRUN npm install --only=production\nCOPY . .\n\nFROM ${baseImage}\nWORKDIR /usr/src/app\nCOPY --from=builder /usr/src/app .\nEXPOSE ${finalAppPortInternal}\n`;
        break;
      case 'frontend':
        baseImage = "nginx:stable-alpine";
        finalAppPortInternal = appPortInternal || '80';
        mainCmd = `CMD ["nginx", "-g", "daemon off;"]`;
        dockerfileContent = `FROM node:18-alpine AS builder\nWORKDIR /app\nCOPY package*.json ./\nRUN npm install\nCOPY . .\nRUN npm run build\n\nFROM ${baseImage}\nCOPY --from=builder /app/dist /usr/share/nginx/html\nEXPOSE ${finalAppPortInternal}\n`;
        break;
      case 'database':
        baseImage = "postgres:15-alpine";
        finalAppPortInternal = appPortInternal || '5432';
        dockerfileContent = `FROM ${baseImage}\nEXPOSE ${finalAppPortInternal}\n`;
        mainCmd = `# CMD da imagem base postgres`;
        break;
      default:
        baseImage = "alpine:latest";
        finalAppPortInternal = appPortInternal || '8000';
        mainCmd = `CMD ["echo", "Container iniciado na porta ${finalAppPortInternal}"]`;
        dockerfileContent = `FROM ${baseImage}\nWORKDIR /app\nCOPY . .\nEXPOSE ${finalAppPortInternal}\n`;
        break;
    }
    
    if (additionalPackages && additionalPackages.length > 0) {
      let apkPackages = additionalPackages.map(pkg => {
        if (pkg === 'build-essential') return 'build-base';
        if (pkg === 'pip') return 'py3-pip';
        if (pkg === 'nodejs') return 'nodejs npm';
        return pkg;
      }).join(' ');
      dockerfileContent += `\n# Pacotes Adicionais\nRUN apk add --no-cache ${apkPackages}\n`;
    }
    
    if (installCodeServer && (containerType === 'backend' || containerType === 'other')) {
      let csDeps = ['curl', 'bash', 'sudo', 'git', 'openssh-client'];
      let missingCsDeps = csDeps.filter(dep => !(additionalPackages && additionalPackages.includes(dep)));
      if (missingCsDeps.length > 0) {
        dockerfileContent += `\n# Dependências do Code-Server\nRUN apk add --no-cache ${missingCsDeps.join(' ')}\n`;
      }
      
      dockerfileContent += `\n# Code-Server Setup\nENV USER=coder HOME=/home/coder\nRUN adduser -S -G root -s /bin/bash -h $HOME coder && echo "coder ALL=(ALL) NOPASSWD:ALL" >> /etc/sudoers && mkdir -p $HOME/.local/share/code-server && chown -R coder:root $HOME\nUSER coder\nWORKDIR $HOME\nARG CS_VERSION=4.91.1\nRUN curl -fsSL https://github.com/coder/code-server/releases/download/v$CS_VERSION/code-server-$CS_VERSION-linux-amd64.tar.gz | tar -xz -C $HOME/.local/share && ln -s $HOME/.local/share/code-server-$CS_VERSION-linux-amd64/bin/code-server $HOME/.local/bin/\nENV PATH=$HOME/.local/bin:$PATH\nEXPOSE ${codeServerPortInternal}\n`;
      let csAuth = codeServerPassword ? 'password' : 'none';
      let csPasswordEnv = codeServerPassword ? `ENV PASSWORD=${codeServerPassword}\n` : '';
      dockerfileContent += csPasswordEnv;
      const appCmdOriginal = mainCmd.startsWith('CMD') ? mainCmd.substring(4).trim() : mainCmd.trim();
      if (containerType === 'backend' && appCmdOriginal && !appCmdOriginal.startsWith('#')) {
        mainCmd = `CMD code-server --auth ${csAuth} --port ${codeServerPortInternal} --host 0.0.0.0 $HOME & exec ${appCmdOriginal}`;
      } else {
        mainCmd = `CMD code-server --auth ${csAuth} --port ${codeServerPortInternal} --host 0.0.0.0 $HOME`;
        if (containerType === 'other' && appCmdOriginal && !appCmdOriginal.startsWith('#')) {
          mainCmd += ` & ${appCmdOriginal}`;
        }
      }
    }
    
    if (mainCmd && !dockerfileContent.includes(mainCmd.substring(0, 20))) {
      dockerfileContent += `\n${mainCmd}\n`;
    }
    
    setGeneratedDockerfile(dockerfileContent.trim());
    setImageName(`${currentProjectSettings.name}-${currentProjectSettings.containerType}:latest`);
  };
  
  const handleCreateContainer = () => {
    // Get the final Dockerfile content from the textarea
    const finalDockerfile = (document.getElementById('generated-dockerfile') as HTMLTextAreaElement).value;
    const finalImageName = (document.getElementById('image-name') as HTMLInputElement).value;
    
    setImageName(finalImageName);
    
    // In a real implementation, this would send the Dockerfile to the Docker API to build the image
    console.log("Dockerfile final a ser usado:", finalDockerfile);
    
    createContainer();
    
    setShowContainerConfigReviewStep(false);
  };
  
  const handleStartSuggestedContainer = (type: string) => {
    const projectName = currentProjectSettings.name;
    const fromTemplate = currentProjectSettings.fromTemplate;
    
    resetCreateProjectFlow();
    
    setCurrentProjectSettings(prev => ({
      ...prev,
      name: projectName,
      containerType: type,
      fromTemplate
    }));
    
    // Set suggested ports based on container type
    let suggestedInternalAppPort = '';
    let suggestedExternalAppPort = '';
    
    const existingExternalPorts = containers.flatMap(c => 
      c.Ports.filter(p => p.PublicPort).map(p => p.PublicPort!.toString())
    );
    
    const getUniquePort = (basePort: string) => {
      let port = parseInt(basePort);
      while (existingExternalPorts.includes(port.toString())) {
        port++;
      }
      return port.toString();
    };
    
    if (type === 'backend') {
      suggestedInternalAppPort = '3000';
      suggestedExternalAppPort = getUniquePort('3001');
    } else if (type === 'frontend') {
      suggestedInternalAppPort = '80';
      suggestedExternalAppPort = getUniquePort('8081');
    } else if (type === 'database') {
      suggestedInternalAppPort = '5432';
      suggestedExternalAppPort = getUniquePort('5433');
    }
    
    setCurrentProjectSettings(prev => ({
      ...prev,
      appPortInternal: suggestedInternalAppPort,
      appPortExternal: suggestedExternalAppPort
    }));
    
    setShowComplementarySuggestions(false);
    setShowContainerBaseConfigStep(true);
  };
  
  const handleUseTemplate = (templateId: string) => {
    const template = projectTemplates.find(t => t.id === templateId);
    if (!template) {
      displayErrorToast('Template não encontrado!');
      return;
    }
    
    resetCreateProjectFlow();
    
    setCurrentProjectSettings({
      name: template.settings.projectName || `projeto-${template.id}`,
      containerType: template.settings.containerType,
      appPortInternal: template.settings.appPortInternal,
      appPortExternal: template.settings.appPortExternal,
      installCodeServer: template.settings.installCodeServer || false,
      codeServerPortInternal: template.settings.codeServerPortInternal || '8080',
      codeServerPortExternal: template.settings.codeServerPortExternal || '8443',
      codeServerPassword: template.settings.codeServerPassword || '',
      additionalPackages: [...(template.settings.additionalPackages || [])],
      fromTemplate: true
    });
    
    displayErrorToast(`Template "${template.name}" carregado. Siga os próximos passos.`, false);
    setActiveView('create-project-view');
    setShowProjectDetailsStep(false);
    setShowContainerBaseConfigStep(true);
  };
  
  // IA settings functions
  const handleSaveIaSettings = () => {
    const provider = (document.getElementById('ia-provider') as HTMLSelectElement).value;
    const apiKey = (document.getElementById('ia-api-key') as HTMLInputElement).value;
    const model = (document.getElementById('ia-model') as HTMLInputElement).value;
    const tokenLimit = (document.getElementById('ia-token-limit') as HTMLInputElement).value;
    
    setIaSettings({
      provider,
      apiKey,
      model,
      tokenLimit
    });
    
    console.log("Configurações de IA salvas:", { provider, apiKey: '***', model, tokenLimit });
    setIaSaveFeedback('Configurações de IA salvas com sucesso!');
    
    setTimeout(() => {
      setIaSaveFeedback('');
    }, 3000);
  };
  
  // Network drag and drop functions
  const handleDragStart = (e: React.DragEvent, containerId: string) => {
    setDraggedItem(containerId);
    e.dataTransfer.setData('text/plain', containerId);
  };
  
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.currentTarget.classList.add('bg-gray-600');
  };
  
  const handleDragLeave = (e: React.DragEvent) => {
    e.currentTarget.classList.remove('bg-gray-600');
  };
  
  const handleDrop = (e: React.DragEvent, networkId: string) => {
    e.preventDefault();
    e.currentTarget.classList.remove('bg-gray-600');
    
    if (draggedItem) {
      const container = containers.find(c => c.Id === draggedItem);
      if (container) {
        connectContainerToNetwork(draggedItem, networkId);
      }
    }
  };
  
  // Create network modal functions
  const handleCreateNetwork = (e: React.FormEvent) => {
    e.preventDefault();
    
    const name = (document.getElementById('new-network-name') as HTMLInputElement).value;
    const type = (document.getElementById('new-network-type') as HTMLSelectElement).value;
    const subnet = (document.getElementById('new-network-subnet') as HTMLInputElement).value;
    
    createNetwork(name, type, subnet);
    setShowCreateNetworkModal(false);
  };
  
  // Render functions
  const renderContainersList = () => {
    return (
      <div className="card">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="border-b border-gray-700">
              <tr>
                <th className="p-3 text-sm font-semibold text-gray-400">Nome</th>
                <th className="p-3 text-sm font-semibold text-gray-400">Imagem</th>
                <th className="p-3 text-sm font-semibold text-gray-400">Status</th>
                <th className="p-3 text-sm font-semibold text-gray-400">Portas (Host:Container)</th>
                <th className="p-3 text-sm font-semibold text-gray-400">Ações</th>
              </tr>
            </thead>
            <tbody>
              {containers.map(container => (
                <tr key={container.Id}>
                  <td className="p-3 text-gray-200">{container.Names[0].replace('/', '')}</td>
                  <td className="p-3 text-gray-300">{container.Image}</td>
                  <td className="p-3">
                    <span className={`status-dot status-${container.State === 'running' ? 'running' : 'stopped'}`}></span>
                    {container.State === 'running' ? 'Em Execução' : 'Parado'}
                  </td>
                  <td className="p-3 text-gray-300">{getPortsString(container.Ports)}</td>
                  <td className="p-3 space-x-2">
                    <button 
                      className="text-blue-400 hover:text-blue-300" 
                      title="Iniciar"
                      onClick={() => startContainer(container.Id)}
                      disabled={container.State === 'running'}
                    >
                      <Play size={16} />
                    </button>
                    <button 
                      className="text-yellow-400 hover:text-yellow-300" 
                      title="Parar"
                      onClick={() => stopContainer(container.Id)}
                      disabled={container.State !== 'running'}
                    >
                      <Square size={16} />
                    </button>
                    <button 
                      className="text-red-400 hover:text-red-300" 
                      title="Excluir"
                      onClick={() => removeContainer(container.Id)}
                    >
                      <Trash2 size={16} />
                    </button>
                    <button 
                      className="text-gray-400 hover:text-gray-300" 
                      title="Logs"
                      onClick={() => fetchContainerLogs(container.Id)}
                    >
                      <FileText size={16} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  };
  
  const renderImagesList = () => {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {images.map(image => (
          <div key={image.Id} className="card">
            <h2 className="text-lg font-semibold text-blue-400 mb-2">{image.RepoTags[0] || '<none>:<none>'}</h2>
            <p className="text-sm text-gray-400 mb-1">ID: {image.Id.substring(7, 19)}...</p>
            <p className="text-sm text-gray-400 mb-3">Tam: {formatBytes(image.Size)}</p>
            <div className="mb-3 h-20 overflow-y-auto">
              <h4 className="text-sm font-medium text-gray-300 mb-1">Desc (IA):</h4>
              <p className="text-xs text-gray-400 bg-gray-700 p-2 rounded">
                {image.RepoTags[0]?.includes('backend') 
                  ? 'Node.js app com code-server e git.' 
                  : image.RepoTags[0]?.includes('frontend') 
                    ? 'Nginx frontend.' 
                    : image.RepoTags[0]?.includes('postgres') 
                      ? 'PostgreSQL database.' 
                      : 'Imagem Docker customizada.'}
              </p>
            </div>
            <button 
              className="btn btn-secondary btn-sm w-full"
              onClick={() => removeImage(image.Id)}
            >
              <Trash2 size={16} className="mr-2" />
              Excluir
            </button>
          </div>
        ))}
      </div>
    );
  };
  
  const renderMonitoringDashboard = () => {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {containerStats.map(stats => {
          const container = containers.find(c => c.Id === stats.id);
          if (!container) return null;
          
          return (
            <div key={stats.id} className="card">
              <div className="flex justify-between items-center mb-2">
                <h2 className={`text-lg font-semibold ${container.State === 'running' ? 'text-blue-400' : 'text-yellow-400'}`}>
                  {stats.name}
                </h2>
                <span className={`status-dot status-${container.State === 'running' ? 'running' : 'stopped'}`}></span>
              </div>
              <p className="text-sm text-gray-500 mb-3">Img: {container.Image}</p>
              <div className="space-y-2">
                <p className="text-sm">CPU: <span className="font-semibold">{stats.cpu}</span></p>
                <p className="text-sm">Mem: <span className="font-semibold">{stats.memory}/{stats.memoryLimit}</span></p>
                <p className="text-sm">Rede: <span className="font-semibold">{stats.networkRx}/{stats.networkTx}</span></p>
              </div>
              <button 
                className="btn btn-secondary btn-sm w-full mt-4"
                onClick={() => fetchContainerLogs(stats.id)}
              >
                <FileText size={16} className="mr-2" />
                Logs
              </button>
            </div>
          );
        })}
      </div>
    );
  };
  
  const renderNetworksView = () => {
    return (
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="card">
          <h2 className="text-xl font-semibold mb-4 text-gray-100">Containers Disponíveis</h2>
          <div id="draggable-containers">
            {containers.map(container => (
              <div 
                key={container.Id}
                className="network-container-item bg-gray-700"
                draggable="true"
                id={container.Id}
                onDragStart={(e) => handleDragStart(e, container.Id)}
              >
                {container.Image.includes('backend') ? (
                  <Server size={16} className="mr-2" />
                ) : container.Image.includes('frontend') ? (
                  <Monitor size={16} className="mr-2" />
                ) : container.Image.includes('postgres') ? (
                  <Database size={16} className="mr-2" />
                ) : (
                  <Box size={16} className="mr-2" />
                )}
                {container.Names[0].replace('/', '')}
              </div>
            ))}
          </div>
        </div>
        <div className="md:col-span-2 card">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold text-gray-100">Área de Redes</h2>
            <button 
              className="btn btn-secondary btn-sm"
              onClick={() => setShowCreateNetworkModal(true)}
            >
              <Plus size={16} className="mr-2" />
              Criar Nova Rede
            </button>
          </div>
          <div id="network-areas-container" className="space-y-4">
            {networks.map(network => (
              <div 
                key={network.Id}
                className={`network-area ${network.Driver === 'host' ? 'host-network bg-gray-700/30' : 'bg-gray-700/50'}`}
                id={network.Id}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={(e) => handleDrop(e, network.Id)}
              >
                <h3 className={`font-semibold ${network.Driver === 'host' ? 'text-green-400' : 'text-blue-400'} mb-2`}>
                  {network.Driver === 'host' ? (
                    <>
                      <Server size={16} className="mr-2 inline" />
                      Rede Host
                    </>
                  ) : (
                    <>
                      Rede: {network.Name} 
                      <span className="text-xs text-gray-500">
                        ({network.Driver.charAt(0).toUpperCase() + network.Driver.slice(1)} - 
                        {network.IPAM.Config.length > 0 ? network.IPAM.Config[0].Subnet : 'N/A'})
                      </span>
                    </>
                  )}
                </h3>
                {Object.keys(network.Containers).length === 0 ? (
                  <p className="text-sm text-gray-500 italic">Arraste containers aqui.</p>
                ) : (
                  <div>
                    {Object.entries(network.Containers).map(([containerId, containerInfo]) => (
                      <div 
                        key={containerId}
                        className="bg-blue-500 text-white text-sm px-2 py-1 rounded-full inline-block m-1"
                      >
                        {containerInfo.Name}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  };
  
  const renderProjectTemplates = () => {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {projectTemplates.map(template => (
          <div 
            key={template.id}
            className="card hover:border-blue-500 border-2 border-transparent transition-all duration-200"
          >
            <div className="flex items-center mb-3">
              {template.icon === 'server' ? (
                <Server size={32} className="text-blue-400 mr-3" />
              ) : template.icon === 'monitor' ? (
                <Monitor size={32} className="text-blue-400 mr-3" />
              ) : template.icon === 'code' ? (
                <Box size={32} className="text-blue-400 mr-3" />
              ) : (
                <Box size={32} className="text-blue-400 mr-3" />
              )}
              <h2 className="text-xl font-semibold text-gray-100">{template.name}</h2>
            </div>
            <p className="text-sm text-gray-400 mb-4 h-16 overflow-y-auto">{template.description}</p>
            <button 
              className="btn btn-primary w-full"
              onClick={() => handleUseTemplate(template.id)}
            >
              Usar este Template
            </button>
          </div>
        ))}
      </div>
    );
  };
  
  // Main render
  if (!isLoggedIn) {
    return (
      <div id="login-screen" className="min-h-screen flex items-center justify-center p-4 bg-gray-900">
        <div className="card w-full max-w-md bg-gray-800 rounded-xl p-6">
          <div className="text-center mb-8">
            <Cubes size={48} className="text-blue-500 mx-auto" />
            <h1 className="text-3xl font-bold mt-2 text-gray-100">DockerDash</h1>
            <p className="text-gray-400">Gerenciamento Visual de Containers</p>
          </div>
          <form id="login-form" onSubmit={handleLogin}>
            <div className="mb-4">
              <label htmlFor="username" className="block mb-2 text-sm font-medium text-gray-300">Usuário</label>
              <input 
                type="text" 
                id="username" 
                defaultValue="root" 
                className="input-field bg-gray-700 border border-gray-600 text-gray-100 p-3 rounded-lg w-full" 
                required 
              />
            </div>
            <div className="mb-6">
              <label htmlFor="password" className="block mb-2 text-sm font-medium text-gray-300">Senha</label>
              <input 
                type="password" 
                id="password" 
                defaultValue="root1234" 
                className="input-field bg-gray-700 border border-gray-600 text-gray-100 p-3 rounded-lg w-full" 
                required 
              />
            </div>
            <button 
              type="submit" 
              className="btn btn-primary w-full bg-blue-600 text-white p-3 rounded-lg font-medium hover:bg-blue-700"
            >
              Entrar
            </button>
          </form>
          {loginError && (
            <p id="login-error" className="text-red-500 text-sm mt-4 text-center">{loginError}</p>
          )}
        </div>
        
        {showChangePasswordModal && (
          <div id="change-password-modal" className="modal fixed top-0 left-0 w-full h-full bg-black/70 flex items-center justify-center z-50">
            <div className="modal-content bg-gray-800 p-8 rounded-xl w-full max-w-md">
              <h2 className="text-2xl font-semibold mb-6 text-center text-gray-100">Alterar Senha</h2>
              <p className="text-gray-400 mb-4 text-sm text-center">
                Bem-vindo! Como este é o seu primeiro acesso, por favor, crie uma nova senha para continuar para o painel.
              </p>
              <form id="change-password-form" onSubmit={handleChangePassword}>
                <div className="mb-4">
                  <label htmlFor="new-password" className="block mb-2 text-sm font-medium text-gray-300">Nova Senha</label>
                  <input 
                    type="password" 
                    id="new-password" 
                    className="input-field bg-gray-700 border border-gray-600 text-gray-100 p-3 rounded-lg w-full" 
                    required 
                  />
                </div>
                <div className="mb-6">
                  <label htmlFor="confirm-password" className="block mb-2 text-sm font-medium text-gray-300">Confirmar Nova Senha</label>
                  <input 
                    type="password" 
                    id="confirm-password" 
                    className="input-field bg-gray-700 border border-gray-600 text-gray-100 p-3 rounded-lg w-full" 
                    required 
                  />
                </div>
                <button 
                  type="submit" 
                  className="btn btn-primary w-full bg-blue-600 text-white p-3 rounded-lg font-medium hover:bg-blue-700"
                >
                  Salvar Nova Senha e Entrar
                </button>
                {passwordChangeError && (
                  <p id="password-change-error" className="text-red-500 text-sm mt-3 text-center">{passwordChangeError}</p>
                )}
              </form>
            </div>
          </div>
        )}
      </div>
    );
  }
  
  return (
    <div id="app-screen" className="h-screen flex bg-gray-900">
      <nav className="w-20 bg-gray-800 p-4 flex flex-col items-center space-y-6 shadow-lg">
        <div className="text-blue-500 mb-2">
          <Cubes size={32} />
        </div>
        <a 
          href="#" 
          className={`sidebar-icon ${activeView === 'dashboard-view' ? 'text-blue-500' : 'text-gray-400'} hover:text-blue-500`} 
          title="Dashboard" 
          onClick={() => setActiveView('dashboard-view')}
        >
          <Box size={32} />
        </a>
        <a 
          href="#" 
          className={`sidebar-icon ${activeView === 'templates-view' ? 'text-blue-500' : 'text-gray-400'} hover:text-blue-500`} 
          title="Templates" 
          onClick={() => setActiveView('templates-view')}
        >
          <Layers size={32} />
        </a>
        <a 
          href="#" 
          className={`sidebar-icon ${activeView === 'create-project-view' ? 'text-blue-500' : 'text-gray-400'} hover:text-blue-500`} 
          title="Criar Projeto/Container" 
          onClick={() => {
            resetCreateProjectFlow();
            setActiveView('create-project-view');
          }}
        >
          <PlusSquare size={32} />
        </a>
        <a 
          href="#" 
          className={`sidebar-icon ${activeView === 'containers-view' ? 'text-blue-500' : 'text-gray-400'} hover:text-blue-500`} 
          title="Containers" 
          onClick={() => setActiveView('containers-view')}
        >
          <Package size={32} />
        </a>
        <a 
          href="#" 
          className={`sidebar-icon ${activeView === 'networks-view' ? 'text-blue-500' : 'text-gray-400'} hover:text-blue-500`} 
          title="Redes" 
          onClick={() => setActiveView('networks-view')}
        >
          <Network size={32} />
        </a>
        <a 
          href="#" 
          className={`sidebar-icon ${activeView === 'images-view' ? 'text-blue-500' : 'text-gray-400'} hover:text-blue-500`} 
          title="Imagens" 
          onClick={() => setActiveView('images-view')}
        >
          <Copy size={32} />
        </a>
        <a 
          href="#" 
          className={`sidebar-icon ${activeView === 'monitoring-view' ? 'text-blue-500' : 'text-gray-400'} hover:text-blue-500`} 
          title="Monitoramento" 
          onClick={() => setActiveView('monitoring-view')}
        >
          <LineChart size={32} />
        </a>
        <a 
          href="#" 
          className={`sidebar-icon ${activeView === 'ia-settings-view' ? 'text-blue-500' : 'text-gray-400'} hover:text-blue-500`} 
          title="Configurações de IA" 
          onClick={() => setActiveView('ia-settings-view')}
        >
          <Brain size={32} />
        </a>
        <div className="mt-auto">
          <a 
            href="#" 
            className="sidebar-icon text-gray-400 hover:text-red-500" 
            title="Sair" 
            onClick={handleLogout}
          >
            <LogOut size={32} />
          </a>
        </div>
      </nav>
      
      <main className="flex-1 p-6 overflow-y-auto bg-gray-900">
        {/* Dashboard View */}
        {activeView === 'dashboard-view' && (
          <div id="dashboard-view" className="view-content">
            <h1 className="text-3xl font-semibold mb-6 text-gray-100">Dashboard</h1>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="card bg-gray-800 rounded-xl p-6">
                <h2 className="text-xl font-semibold mb-2 text-blue-400">Containers Ativos</h2>
                <p className="text-4xl font-bold text-gray-100">
                  {containers.filter(c => c.State === 'running').length} 
                  <span className="text-lg text-gray-400">/ {containers.length} Total</span>
                </p>
              </div>
              <div className="card bg-gray-800 rounded-xl p-6">
                <h2 className="text-xl font-semibold mb-2 text-green-400">Uso de CPU</h2>
                <p className="text-4xl font-bold text-gray-100">35%</p>
              </div>
              <div className="card bg-gray-800 rounded-xl p-6">
                <h2 className="text-xl font-semibold mb-2 text-yellow-400">Uso de Memória</h2>
                <p className="text-4xl font-bold text-gray-100">60%</p>
              </div>
            </div>
            <div className="mt-8 card bg-gray-800 rounded-xl p-6">
              <h2 className="text-xl font-semibold mb-4 text-gray-100">Ações Rápidas</h2>
              <div className="flex space-x-4">
                <button 
                  className="btn btn-primary bg-blue-600 text-white p-3 rounded-lg font-medium hover:bg-blue-700"
                  onClick={() => {
                    resetCreateProjectFlow();
                    setActiveView('create-project-view');
                  }}
                >
                  <PlusSquare size={16} className="mr-2 inline" />
                  Novo Projeto
                </button>
                <button 
                  className="btn btn-secondary bg-gray-600 text-white p-3 rounded-lg font-medium hover:bg-gray-700"
                  onClick={() => setActiveView('monitoring-view')}
                >
                  <LineChart size={16} className="mr-2 inline" />
                  Ver Monitoramento
                </button>
              </div>
            </div>
          </div>
        )}
        
        {/* Templates View */}
        {activeView === 'templates-view' && (
          <div id="templates-view" className="view-content">
            <h1 className="text-3xl font-semibold mb-6 text-gray-100">Templates de Projetos</h1>
            {renderProjectTemplates()}
          </div>
        )}
        
        {/* Create Project View */}
        {activeView === 'create-project-view' && (
          <div id="create-project-view" className="view-content">
            <h1 className="text-3xl font-semibold mb-6 text-gray-100">Criar Novo Projeto/Container</h1>
            
            {showProjectDetailsStep && (
              <div id="project-details-step" className="card max-w-2xl mx-auto bg-gray-800 rounded-xl p-6">
                <div className="mb-6">
                  <label htmlFor="project-name" className="block mb-2 text-sm font-medium text-gray-300">Nome do Projeto</label>
                  <input 
                    type="text" 
                    id="project-name" 
                    className="input-field bg-gray-700 border border-gray-600 text-gray-100 p-3 rounded-lg w-full" 
                    placeholder="Ex: meu-app-incrivel"
                    defaultValue={currentProjectSettings.name}
                  />
                </div>
                <div className="mb-6">
                  <label htmlFor="container-type" className="block mb-2 text-sm font-medium text-gray-300">Tipo de Container Principal</label>
                  <select 
                    id="container-type" 
                    className="input-field bg-gray-700 border border-gray-600 text-gray-100 p-3 rounded-lg w-full"
                    defaultValue={currentProjectSettings.containerType}
                  >
                    <option value="backend">Backend</option>
                    <option value="frontend">Frontend</option>
                    <option value="database">Banco de Dados</option>
                    <option value="other">Outro</option>
                  </select>
                </div>
                <button 
                  className="btn btn-primary w-full bg-blue-600 text-white p-3 rounded-lg font-medium hover:bg-blue-700"
                  onClick={handleProjectDetailsNext}
                >
                  Próximo: Configurações do Container
                </button>
              </div>
            )}
            
            {showContainerBaseConfigStep && (
              <div id="container-base-config-step" className="mt-8 card max-w-2xl mx-auto bg-gray-800 rounded-xl p-6">
                <h2 className="text-xl font-semibold mb-4 text-gray-100">
                  Configurações Base para 
                  <span id="base-config-container-type" className="text-blue-400">
                    {' '}
                    {currentProjectSettings.containerType === 'backend' ? 'Backend' : 
                     currentProjectSettings.containerType === 'frontend' ? 'Frontend' : 
                     currentProjectSettings.containerType === 'database' ? 'Banco de Dados' : 'Outro'}
                  </span>
                </h2>
                <div className="mb-6">
                  <label htmlFor="app-port-internal" className="block mb-2 text-sm font-medium text-gray-300">Porta Interna da Aplicação</label>
                  <input 
                    type="number" 
                    id="app-port-internal" 
                    className="input-field bg-gray-700 border border-gray-600 text-gray-100 p-3 rounded-lg w-full" 
                    placeholder="Ex: 3000 (Node), 80 (Nginx)"
                    defaultValue={currentProjectSettings.appPortInternal}
                  />
                </div>
                <div className="mb-6">
                  <label htmlFor="app-port-external" className="block mb-2 text-sm font-medium text-gray-300">Porta Externa da Aplicação (Host)</label>
                  <input 
                    type="number" 
                    id="app-port-external" 
                    className="input-field bg-gray-700 border border-gray-600 text-gray-100 p-3 rounded-lg w-full" 
                    placeholder="Ex: 8080 (será mapeada para a interna)"
                    defaultValue={currentProjectSettings.appPortExternal}
                  />
                </div>
                <div className="flex justify-between">
                  <button 
                    className="btn btn-secondary bg-gray-600 text-white p-3 rounded-lg font-medium hover:bg-gray-700"
                    onClick={() => {
                      setShowContainerBaseConfigStep(false);
                      setShowProjectDetailsStep(true);
                    }}
                  >
                    Voltar
                  </button>
                  <button 
                    className="btn btn-primary bg-blue-600 text-white p-3 rounded-lg font-medium hover:bg-blue-700"
                    onClick={handleContainerBaseConfigNext}
                  >
                    Próximo: Ambiente de Desenvolvimento
                  </button>
                </div>
              </div>
            )}
            
            {showCodeServerSetupStep && (
              <div id="code-server-setup-step" className="mt-8 card max-w-2xl mx-auto bg-gray-800 rounded-xl p-6">
                <h2 className="text-xl font-semibold mb-4 text-gray-100">Ambiente de Desenvolvimento (Code-Server)</h2>
                <div className="mb-6 space-y-3">
                  <label className="radio-label bg-gray-700/50 flex items-center p-3 border border-gray-600 rounded-lg cursor-pointer">
                    <input 
                      type="radio" 
                      name="install-code-server" 
                      value="yes" 
                      onChange={() => {
                        document.getElementById('code-server-options-section')?.classList.remove('hidden');
                      }}
                      defaultChecked={currentProjectSettings.installCodeServer}
                    />
                    <span className="ml-3">Sim, instalar code-server</span>
                  </label>
                  <label className="radio-label bg-gray-700/50 flex items-center p-3 border border-gray-600 rounded-lg cursor-pointer">
                    <input 
                      type="radio" 
                      name="install-code-server" 
                      value="no" 
                      onChange={() => {
                        document.getElementById('code-server-options-section')?.classList.add('hidden');
                      }}
                      defaultChecked={!currentProjectSettings.installCodeServer}
                    />
                    <span className="ml-3">Não, obrigado</span>
                  </label>
                </div>
                <div id="code-server-options-section" className={currentProjectSettings.installCodeServer ? '' : 'hidden'}>
                  <div className="mb-6">
                    <label htmlFor="code-server-port-internal" className="block mb-2 text-sm font-medium text-gray-300">Porta Interna do Code-Server</label>
                    <input 
                      type="number" 
                      id="code-server-port-internal" 
                      className="input-field bg-gray-700 border border-gray-600 text-gray-100 p-3 rounded-lg w-full" 
                      defaultValue={currentProjectSettings.codeServerPortInternal}
                    />
                  </div>
                  <div className="mb-6">
                    <label htmlFor="code-server-port-external" className="block mb-2 text-sm font-medium text-gray-300">Porta Externa do Code-Server (Host)</label>
                    <input 
                      type="number" 
                      id="code-server-port-external" 
                      className="input-field bg-gray-700 border border-gray-600 text-gray-100 p-3 rounded-lg w-full" 
                      defaultValue={currentProjectSettings.codeServerPortExternal}
                    />
                  </div>
                  <div className="mb-6">
                    <label htmlFor="code-server-password" className="block mb-2 text-sm font-medium text-gray-300">Senha para o Code-Server</label>
                    <input 
                      type="password" 
                      id="code-server-password" 
                      className="input-field bg-gray-700 border border-gray-600 text-gray-100 p-3 rounded-lg w-full" 
                      placeholder="Deixe em branco para nenhuma senha"
                      defaultValue={currentProjectSettings.codeServerPassword}
                    />
                  </div>
                </div>
                <div className="flex justify-between">
                  <button 
                    className="btn btn-secondary bg-gray-600 text-white p-3 rounded-lg font-medium hover:bg-gray-700"
                    onClick={() => {
                      setShowCodeServerSetupStep(false);
                      setShowContainerBaseConfigStep(true);
                    }}
                  >
                    Voltar
                  </button>
                  <button 
                    className="btn btn-primary bg-blue-600 text-white p-3 rounded-lg font-medium hover:bg-blue-700"
                    onClick={handleCodeServerSetupNext}
                  >
                    Próximo: Pacotes Adicionais
                  </button>
                </div>
              </div>
            )}
            
            {showAdditionalPackagesStep && (
              <div id="additional-packages-step" className="mt-8 card max-w-2xl mx-auto bg-gray-800 rounded-xl p-6">
                <h2 className="text-xl font-semibold mb-4 text-gray-100">Pacotes Adicionais (Opcional)</h2>
                <p className="text-gray-400 mb-4 text-sm">Selecione ferramentas e pacotes comuns para incluir na imagem do container (baseado em Alpine Linux).</p>
                <div id="packages-checkbox-grid" className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-6 max-h-72 overflow-y-auto p-2 bg-gray-700/30 rounded-lg">
                  {availablePackages.map(pkg => (
                    <label 
                      key={pkg.id}
                      className="checkbox-label bg-gray-700/80 flex items-center p-3 border border-gray-600 rounded-lg cursor-pointer"
                    >
                      <input 
                        type="checkbox" 
                        id={`pkg-${pkg.id}`} 
                        value={pkg.id} 
                        className="form-checkbox h-5 w-5 text-blue-600"
                        defaultChecked={currentProjectSettings.additionalPackages.includes(pkg.id)}
                      />
                      <span className="ml-3">
                        {pkg.icon === 'git-branch' ? (
                          <Box size={16} className="mr-2 inline text-gray-400" />
                        ) : pkg.icon === 'file-code' ? (
                          <FileText size={16} className="mr-2 inline text-gray-400" />
                        ) : pkg.icon === 'terminal' ? (
                          <Terminal size={16} className="mr-2 inline text-gray-400" />
                        ) : pkg.icon === 'database' ? (
                          <Database size={16} className="mr-2 inline text-gray-400" />
                        ) : (
                          <Box size={16} className="mr-2 inline text-gray-400" />
                        )}
                        {pkg.name}
                      </span>
                    </label>
                  ))}
                </div>
                <div className="flex justify-between">
                  <button 
                    className="btn btn-secondary bg-gray-600 text-white p-3 rounded-lg font-medium hover:bg-gray-700"
                    onClick={() => {
                      setShowAdditionalPackagesStep(false);
                      setShowCodeServerSetupStep(true);
                    }}
                  >
                    Voltar
                  </button>
                  <button 
                    className="btn btn-primary bg-blue-600 text-white p-3 rounded-lg font-medium hover:bg-blue-700"
                    onClick={handleAdditionalPackagesNext}
                  >
                    Próximo: Rever Dockerfile
                  </button>
                </div>
              </div>
            )}
            
            {showContainerConfigReviewStep && (
              <div id="container-config-review-step" className="mt-8 card max-w-2xl mx-auto bg-gray-800 rounded-xl p-6">
                <h2 className="text-xl font-semibold mb-4 text-gray-100">
                  Revisão: 
                  <span id="review-container-type-label" className="text-blue-400">
                    {' '}
                    {currentProjectSettings.containerType === 'backend' ? 'Backend' : 
                     currentProjectSettings.containerType === 'frontend' ? 'Frontend' : 
                     currentProjectSettings.containerType === 'database' ? 'Banco de Dados' : 'Outro'}
                  </span>
                </h2>
                <div id="review-app-port-info" className="mb-2 p-3 bg-gray-700/70 rounded-lg text-sm">
                  <Network size={16} className="mr-2 inline" />
                  Aplicação: Interna <strong className="text-blue-400">
                    {currentProjectSettings.appPortInternal || (currentProjectSettings.containerType === 'database' ? 'N/A (padrão)' : 'N/A')}
                  </strong> para Externa <strong className="text-blue-400">
                    {currentProjectSettings.appPortExternal || (currentProjectSettings.containerType === 'database' ? 'N/A (padrão)' : 'N/A')}
                  </strong>.
                </div>
                {currentProjectSettings.installCodeServer && (
                  <div id="review-code-server-info" className="mb-2 p-3 bg-blue-900/50 rounded-lg text-sm">
                    <Monitor size={16} className="mr-2 inline" />
                    Code-Server: Interna <strong className="text-blue-400">{currentProjectSettings.codeServerPortInternal}</strong> para Externa <strong className="text-blue-400">{currentProjectSettings.codeServerPortExternal}</strong>.
                  </div>
                )}
                {currentProjectSettings.additionalPackages.length > 0 && (
                  <div id="review-packages-info" className="mb-4 p-3 bg-green-900/30 rounded-lg text-sm">
                    <Package size={16} className="mr-2 inline" />
                    Pacotes Adicionais: <strong className="text-green-400">{currentProjectSettings.additionalPackages.join(', ')}</strong>.
                  </div>
                )}
                <div className="mb-4">
                  <label htmlFor="generated-dockerfile" className="block mb-2 text-sm font-medium text-gray-300">Dockerfile Otimizado (Gerado por IA - Editável):</label>
                  <textarea 
                    id="generated-dockerfile" 
                    rows={10}
                    className="font-mono text-sm bg-gray-700 border border-gray-600 text-gray-100 p-3 rounded-lg w-full"
                    value={generatedDockerfile}
                    onChange={(e) => setGeneratedDockerfile(e.target.value)}
                  ></textarea>
                </div>
                <div className="mb-6">
                  <label htmlFor="image-name" className="block mb-2 text-sm font-medium text-gray-300">Nome da Imagem Docker</label>
                  <input 
                    type="text" 
                    id="image-name" 
                    className="input-field bg-gray-700 border border-gray-600 text-gray-100 p-3 rounded-lg w-full" 
                    placeholder="Ex: meu-backend-app:latest"
                    value={imageName}
                    onChange={(e) => setImageName(e.target.value)}
                  />
                </div>
                <div className="flex justify-between">
                  <button 
                    className="btn btn-secondary bg-gray-600 text-white p-3 rounded-lg font-medium hover:bg-gray-700"
                    onClick={() => {
                      setShowContainerConfigReviewStep(false);
                      setShowAdditionalPackagesStep(true);
                    }}
                  >
                    Voltar
                  </button>
                  <button 
                    className="btn btn-primary w-full bg-blue-600 text-white p-3 rounded-lg font-medium hover:bg-blue-700 ml-2"
                    onClick={handleCreateContainer}
                  >
                    Criar Container e Imagem
                  </button>
                </div>
              </div>
            )}
            
            {showComplementarySuggestions && (
              <div id="complementary-suggestions" className="mt-8 card max-w-2xl mx-auto bg-gray-800 rounded-xl p-6">
                <h2 className="text-xl font-semibold mb-4 text-gray-100">Sugestões de Containers Complementares</h2>
                <div id="suggestions-list" className="space-y-3">
                  {currentProjectSettings.containerType === 'backend' && (
                    <>
                      <div className="p-3 bg-gray-700 rounded-lg flex items-center justify-between">
                        <div>
                          <h3 className="font-semibold text-gray-100">
                            <Database size={16} className="mr-2 inline text-blue-400" />
                            Banco de Dados (PostgreSQL)
                          </h3>
                          <p className="text-sm text-gray-400">Para persistência de dados.</p>
                        </div>
                        <button 
                          className="btn btn-secondary btn-sm bg-gray-600 text-white px-3 py-2 rounded-lg font-medium hover:bg-gray-700"
                          onClick={() => handleStartSuggestedContainer('database')}
                        >
                          Adicionar
                        </button>
                      </div>
                      <div className="p-3 bg-gray-700 rounded-lg flex items-center justify-between">
                        <div>
                          <h3 className="font-semibold text-gray-100">
                            <Monitor size={16} className="mr-2 inline text-blue-400" />
                            Frontend (React/Vue)
                          </h3>
                          <p className="text-sm text-gray-400">Interface para o backend.</p>
                        </div>
                        <button 
                          className="btn btn-secondary btn-sm bg-gray-600 text-white px-3 py-2 rounded-lg font-medium hover:bg-gray-700"
                          onClick={() => handleStartSuggestedContainer('frontend')}
                        >
                          Adicionar
                        </button>
                      </div>
                    </>
                  )}
                  {currentProjectSettings.containerType === 'frontend' && (
                    <div className="p-3 bg-gray-700 rounded-lg flex items-center justify-between">
                      <div>
                        <h3 className="font-semibold text-gray-100">
                          <Server size={16} className="mr-2 inline text-blue-400" />
                          Backend (Node.js)
                        </h3>
                        <p className="text-sm text-gray-400">API para o frontend.</p>
                      </div>
                      <button 
                        className="btn btn-secondary btn-sm bg-gray-600 text-white px-3 py-2 rounded-lg font-medium hover:bg-gray-700"
                        onClick={() => handleStartSuggestedContainer('backend')}
                      >
                        Adicionar
                      </button>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        )}
        
        {/* Containers View */}
        {activeView === 'containers-view' && (
          <div id="containers-view" className="view-content">
            <h1 className="text-3xl font-semibold mb-6 text-gray-100">Gerenciar Containers</h1>
            {renderContainersList()}
          </div>
        )}
        
        {/* Networks View */}
        {activeView === 'networks-view' && (
          <div id="networks-view" className="view-content">
            <h1 className="text-3xl font-semibold mb-6 text-gray-100">Gerenciar Redes</h1>
            {renderNetworksView()}
          </div>
        )}
        
        {/* Images View */}
        {activeView === 'images-view' && (
          <div id="images-view" className="view-content">
            <h1 className="text-3xl font-semibold mb-6 text-gray-100">Gerenciar Imagens Docker</h1>
            {renderImagesList()}
          </div>
        )}
        
        {/* Monitoring View */}
        {activeView === 'monitoring-view' && (
          <div id="monitoring-view" className="view-content">
            <h1 className="text-3xl font-semibold mb-6 text-gray-100">Monitoramento em Tempo Real</h1>
            {renderMonitoringDashboard()}
          </div>
        )}
        
        {/* IA Settings View */}
        {activeView === 'ia-settings-view' && (
          <div id="ia-settings-view" className="view-content">
            <h1 className="text-3xl font-semibold mb-6 text-gray-100">Configurações de Inteligência Artificial</h1>
            <div className="card max-w-xl mx-auto bg-gray-800 rounded-xl p-6">
              <div className="mb-6">
                <label htmlFor="ia-provider" className="block mb-2 text-sm font-medium text-gray-300">Provedor de IA</label>
                <select 
                  id="ia-provider" 
                  className="input-field bg-gray-700 border border-gray-600 text-gray-100 p-3 rounded-lg w-full"
                  defaultValue={iaSettings.provider}
                >
                  <option value="gemini">Google Gemini</option>
                  <option value="openai">OpenAI (GPT)</option>
                  <option value="custom">Outro (API Customizada)</option>
                </select>
              </div>
              <div className="mb-6">
                <label htmlFor="ia-api-key" className="block mb-2 text-sm font-medium text-gray-300">Chave da API</label>
                <input 
                  type="password" 
                  id="ia-api-key" 
                  className="input-field bg-gray-700 border border-gray-600 text-gray-100 p-3 rounded-lg w-full" 
                  placeholder="Cole sua chave de API aqui"
                  defaultValue={iaSettings.apiKey}
                />
              </div>
              <div className="mb-6">
                <label htmlFor="ia-model" className="block mb-2 text-sm font-medium text-gray-300">Modelo Específico</label>
                <input 
                  type="text" 
                  id="ia-model" 
                  className="input-field bg-gray-700 border border-gray-600 text-gray-100 p-3 rounded-lg w-full" 
                  placeholder="Ex: gemini-pro, gpt-4-turbo"
                  defaultValue={iaSettings.model}
                />
              </div>
              <div className="mb-6">
                <label htmlFor="ia-token-limit" className="block mb-2 text-sm font-medium text-gray-300">Limite de Tokens</label>
                <input 
                  type="number" 
                  id="ia-token-limit" 
                  className="input-field bg-gray-700 border border-gray-600 text-gray-100 p-3 rounded-lg w-full" 
                  placeholder="Ex: 4096"
                  defaultValue={iaSettings.tokenLimit}
                />
              </div>
              <button 
                className="btn btn-primary w-full bg-blue-600 text-white p-3 rounded-lg font-medium hover:bg-blue-700"
                onClick={handleSaveIaSettings}
              >
                Salvar Configurações de IA
              </button>
              {iaSaveFeedback && (
                <p id="ia-save-feedback" className="text-green-500 text-sm mt-4 text-center">{iaSaveFeedback}</p>
              )}
            </div>
          </div>
        )}
        
        {/* Logs Modal */}
        {showLogsModal && (
          <div id="logs-modal" className="modal fixed top-0 left-0 w-full h-full bg-black/70 flex items-center justify-center z-50">
            <div className="modal-content w-full max-w-3xl bg-gray-800 p-8 rounded-xl">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-semibold text-gray-100">
                  Logs: <span id="logs-container-name" className="text-blue-400">{currentContainerLogs.name}</span>
                </h2>
                <button 
                  onClick={() => setShowLogsModal(false)} 
                  className="text-gray-400 hover:text-gray-200 text-2xl"
                >
                  &times;
                </button>
              </div>
              <pre id="logs-content" className="bg-gray-900 p-4 rounded-lg text-sm text-gray-200 overflow-x-auto h-96">
                {currentContainerLogs.logs}
              </pre>
              <div className="mt-4 text-right">
                <button 
                  className="btn btn-secondary bg-gray-600 text-white p-3 rounded-lg font-medium hover:bg-gray-700"
                  onClick={() => setShowLogsModal(false)}
                >
                  Fechar
                </button>
              </div>
            </div>
          </div>
        )}
        
        {/* Create Network Modal */}
        {showCreateNetworkModal && (
          <div id="create-network-modal" className="modal fixed top-0 left-0 w-full h-full bg-black/70 flex items-center justify-center z-50">
            <div className="modal-content bg-gray-800 p-8 rounded-xl w-full max-w-md">
              <h2 className="text-2xl font-semibold mb-6 text-center text-gray-100">Criar Nova Rede Docker</h2>
              <form id="create-network-form" onSubmit={handleCreateNetwork}>
                <div className="mb-4">
                  <label htmlFor="new-network-name" className="block mb-2 text-sm font-medium text-gray-300">Nome da Rede</label>
                  <input 
                    type="text" 
                    id="new-network-name" 
                    className="input-field bg-gray-700 border border-gray-600 text-gray-100 p-3 rounded-lg w-full" 
                    placeholder="Ex: minha_rede_app" 
                    required 
                  />
                </div>
                <div className="mb-4">
                  <label htmlFor="new-network-type" className="block mb-2 text-sm font-medium text-gray-300">Tipo de Rede</label>
                  <select 
                    id="new-network-type" 
                    className="input-field bg-gray-700 border border-gray-600 text-gray-100 p-3 rounded-lg w-full"
                  >
                    <option value="bridge" selected>Bridge (Padrão)</option>
                    <option value="overlay">Overlay (Para Swarm)</option>
                    <option value="macvlan">MACVLAN (Avançado)</option>
                  </select>
                </div>
                <div className="mb-6">
                  <label htmlFor="new-network-subnet" className="block mb-2 text-sm font-medium text-gray-300">Subnet (Opcional, Ex: 172.20.0.0/16)</label>
                  <input 
                    type="text" 
                    id="new-network-subnet" 
                    className="input-field bg-gray-700 border border-gray-600 text-gray-100 p-3 rounded-lg w-full" 
                    placeholder="Deixe em branco para automático" 
                  />
                </div>
                <div className="flex justify-end space-x-3">
                  <button 
                    type="button" 
                    className="btn btn-secondary bg-gray-600 text-white p-3 rounded-lg font-medium hover:bg-gray-700"
                    onClick={() => setShowCreateNetworkModal(false)}
                  >
                    Cancelar
                  </button>
                  <button 
                    type="submit" 
                    className="btn btn-primary bg-blue-600 text-white p-3 rounded-lg font-medium hover:bg-blue-700"
                  >
                    Criar Rede
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
        
        {/* Error Toast */}
        {errorToast.show && (
          <div id="error-toast-container">
            <div className={`error-toast fixed top-4 left-1/2 transform -translate-x-1/2 ${errorToast.message.includes('sucesso') ? 'bg-green-500' : 'bg-red-500'} text-white p-4 rounded-lg shadow-lg z-50 text-sm`}>
              {errorToast.message}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

export default App;