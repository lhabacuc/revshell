(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_1b87a184._.js",
  "static/chunks/node_modules_7ea87854._.js"
],
    source: "dynamic"
});
