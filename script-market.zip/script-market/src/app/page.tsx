"use client";
import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
    ShoppingCart,
    User,
    Settings,
    LogIn,
    LogOut,
    UploadCloud,
    CheckCircle,
    AlertTriangle,
    Loader2,
    KeyRound,
    ListChecks,
    Moon, //d
    SunMedium,
    Whatsapp,
    File, // Correção: Importar File em vez de FileZip
    Store,
    Home,
    XCircle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
    Card,
    CardContent,
    CardDescription,
    CardFooter,
    CardHeader,
    CardTitle,
} from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
    Sheet,
    SheetContent,
    SheetDescription,
    SheetFooter,
    SheetHeader,
    SheetTitle,
    SheetTrigger,
} from '@/components/ui/sheet';
import {
    AlertDialog,
    AlertDialogAction,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
    AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { cn } from '@/lib/utils';
import { useTheme } from 'next-themes';

// Mock Data (Substituir com dados reais do banco de dados)
interface Script {
    id: string;
    title: string;
    description: string;
    price: number;
    file: string; // Caminho/URL do arquivo .zip
    image: string; // URL da imagem de prévia
    tags: string[];
}

interface User {
    id: string;
    name: string;
    email: string;
    phone: string;
    isAdmin: boolean;
}

const mockScripts: Script[] = [
    {
        id: '1',
        title: 'Script de Automação de Tarefas',
        description: 'Automatize tarefas repetitivas e economize tempo.',
        price: 100,
        file: '/scripts/automacao.zip',
        image: 'https://placehold.co/400x200/7E8EFF/31343C?text=Script+1', // Placeholder image
        tags: ['automação', 'produtividade', 'tarefas'],
    },
    {
        id: '2',
        title: 'Script de Análise de Dados',
        description: 'Analise dados complexos e obtenha insights valiosos.',
        price: 150,
        file: '/scripts/analise_dados.zip',
        image: 'https://placehold.co/400x200/7E8EFF/31343C?text=Script+2', // Placeholder image
        tags: ['dados', 'análise', 'estatística'],
    },
    // Add more mock scripts if needed
];

const mockUser: User = {
    id: 'user123',
    name: 'João da Silva',
    email: 'joao.silva@example.com',
    phone: '+244 912 345 678',
    isAdmin: false,
};

const mockAdminUser: User = {
    id: 'admin456',
    name: 'Maria Souza (Admin)',
    email: 'maria.souza@example.com',
    phone: '+244 923 456 789',
    isAdmin: true,
};

const mockCart: Script[] = [];
const mockPurchases: Script[] = [];
const mockAdminRules = "1.  Não é permitido o upload de scripts que violem direitos autorais.\n2.  Os administradores devem revisar os scripts antes da publicação.\n3.  É proibido divulgar informações confidenciais dos usuários.\n4.  Os preços dos scripts devem ser definidos de forma justa.\n5.  Qualquer violação destas regras pode resultar na suspensão da conta.";
const mockDownloadKey = "CHAVE-DE-DOWNLOAD-EXEMPLO";

const App: React.FC = () => {
    // --- State Hooks ---
    const [user, setUser] = useState<User | null>(null); // Start logged out
    const [scripts, setScripts] = useState<Script[]>(mockScripts);
    const [cart, setCart] = useState<Script[]>(mockCart);
    const [purchases, setPurchases] = useState<Script[]>(mockPurchases);
    const [adminRules, setAdminRules] = useState<string>(mockAdminRules);
    const [downloadKey, setDownloadKey] = useState<string>(mockDownloadKey);
    const [loading, setLoading] = useState(false);
    const [showLoginSheet, setShowLoginSheet] = useState(false);
    const [showCartSheet, setShowCartSheet] = useState(false);
    const [showAccountSheet, setShowAccountSheet] = useState(false);
    const { theme, setTheme } = useTheme(); // Use theme from next-themes

    // --- Effects ---
    // Persist theme preference (optional, requires next-themes setup)
    useEffect(() => {
        // You might have logic here to load theme from localStorage
    }, []);

    // --- Event Handlers ---

    // Add script to the shopping cart
    const addToCart = (script: Script) => {
        if (cart.find((item) => item.id === script.id)) {
            // Optionally show a message that the item is already in the cart
            console.log("Script já está no carrinho.");
            return;
        }
        setCart((prevCart) => [...prevCart, script]);
        // Optionally open the cart sheet after adding
        // setShowCartSheet(true);
    };

    // Remove script from the shopping cart
    const removeFromCart = (scriptId: string) => {
        setCart((prevCart) => prevCart.filter((script) => script.id !== scriptId));
    };

    // Simulate checkout process
    const checkout = () => {
        if (cart.length === 0) return;

        setLoading(true);
        // Simulate API call or backend process
        setTimeout(() => {
            setPurchases((prevPurchases) => [...prevPurchases, ...cart]);
            setCart([]);
            setLoading(false);
            setShowCartSheet(false); // Close cart sheet after checkout
            // Replace alert with a more user-friendly notification/toast
            alert('Compra realizada com sucesso! Verifique suas compras.');
        }, 1500);
    };

    // Simulate user login
    const handleLogin = (isAdmin = false) => {
        // In a real app, you'd validate credentials against a backend
        setUser(isAdmin ? mockAdminUser : mockUser);
        setShowLoginSheet(false); // Close login sheet
    };

    // Handle user logout
    const handleLogout = () => {
        setUser(null);
        setCart([]); // Clear cart on logout
        setPurchases([]); // Clear purchases on logout
        setShowAccountSheet(false); // Close account sheet
    };

    // Toggle between light and dark mode
    const toggleDarkMode = () => {
        const newTheme = theme === 'dark' ? 'light' : 'dark';
        setTheme(newTheme);
    };

    // Add a new script (Admin only)
    const addScript = (newScriptData: Omit<Script, 'id' | 'file' | 'image'> & { fileInput?: File, imageInput?: File }) => {
        // Basic validation
        if (!newScriptData.title || !newScriptData.description || isNaN(newScriptData.price) || newScriptData.price <= 0) {
             alert('Por favor, preencha todos os campos obrigatórios corretamente.');
             return;
        }

        // In a real app:
        // 1. Upload fileInput and imageInput to storage (e.g., S3, Firebase Storage)
        // 2. Get the URLs for the uploaded file and image.
        // 3. Save the complete script data (including URLs) to the database.

        // Mock implementation:
        const newScript: Script = {
            ...newScriptData,
            id: crypto.randomUUID(),
            file: `/scripts/mock_${newScriptData.title.replace(/\s+/g, '_').toLowerCase()}.zip`, // Mock file path
            image: `https://placehold.co/400x200/7E8EFF/31343C?text=${encodeURIComponent(newScriptData.title)}`, // Mock image URL
            tags: newScriptData.tags || [],
        };

        setScripts((prevScripts) => [...prevScripts, newScript]);
        alert('Script adicionado com sucesso!'); // Use a toast/notification
        // Consider clearing the form fields here
    };


    // Update admin rules (Admin only)
    const updateAdminRules = (newRules: string) => {
        // In a real app, save these rules to the backend/database
        setAdminRules(newRules);
        alert('Regras atualizadas com sucesso!'); // Use a toast/notification
    };

    // Generate a new download key (Admin only)
    const generateDownloadKey = () => {
        // In a real app, generate and store this securely on the backend
        const newKey = `CHAVE-${Math.random().toString(36).substring(2, 10).toUpperCase()}`;
        setDownloadKey(newKey);
        alert('Nova chave de download gerada!'); // Use a toast/notification
    };

    // --- Helper Functions ---
    const calculateCartTotal = () => {
        return cart.reduce((total, script) => total + script.price, 0);
    };

    // --- JSX ---
    return (
        // Apply base background and text colors, with dark mode overrides for a blue theme
        <div className={cn(
            "min-h-screen bg-gray-50 text-gray-900", // Light mode defaults
            "dark:bg-blue-950 dark:text-blue-50"      // Dark mode blue theme overrides
        )}>
            {/* Header */}
            <header className={cn(
                "sticky top-0 z-50 w-full border-b backdrop-blur-md",
                "border-gray-200 bg-white/80", // Light mode header
                "dark:border-blue-800 dark:bg-blue-900/80" // Dark mode blue header
            )}>
                <div className="container flex items-center justify-between h-16">
                    {/* Logo/Brand */}
                    <div className="flex items-center gap-2">
                        <Store className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                        <h1 className="text-xl font-bold">Script Market</h1>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-2 sm:gap-4">
                        {/* Dark Mode Toggle */}
                        <Button variant="ghost" size="icon" onClick={toggleDarkMode} aria-label="Alternar modo claro/escuro">
                            {theme === 'dark' ? (
                                <SunMedium className="h-5 w-5 sm:h-6 sm:w-6" />
                            ) : (
                                <Moon className="h-5 w-5 sm:h-6 sm:w-6" />
                            )}
                        </Button>

                        {/* Cart */}
                        {user && ( // Only show cart if logged in
                            <Sheet open={showCartSheet} onOpenChange={setShowCartSheet}>
                                <SheetTrigger asChild>
                                    <Button variant="ghost" size="icon" className="relative" aria-label="Abrir carrinho">
                                        <ShoppingCart className="h-5 w-5 sm:h-6 sm:w-6" />
                                        {cart.length > 0 && (
                                            <span className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full text-xs w-4 h-4 sm:w-5 sm:h-5 flex items-center justify-center">
                                                {cart.length}
                                            </span>
                                        )}
                                    </Button>
                                </SheetTrigger>
                                <SheetContent side="right" className="w-full sm:max-w-sm dark:bg-blue-900">
                                    <SheetHeader>
                                        <SheetTitle>Seu Carrinho</SheetTitle>
                                        <SheetDescription>
                                            Revise os itens antes de finalizar.
                                        </SheetDescription>
                                    </SheetHeader>
                                    <div className="space-y-4 py-4 flex-1 overflow-y-auto">
                                        {cart.length === 0 ? (
                                            <p className="text-muted-foreground dark:text-blue-300">Seu carrinho está vazio.</p>
                                        ) : (
                                            <>
                                                {cart.map((script) => (
                                                    <Card key={script.id} className="flex flex-row items-center justify-between p-3 dark:bg-blue-800">
                                                        <div>
                                                            <CardTitle className="text-sm font-medium">{script.title}</CardTitle>
                                                            <CardDescription className="text-xs dark:text-blue-200">Preço: ${script.price.toFixed(2)}</CardDescription>
                                                        </div>
                                                        <Button
                                                            variant="ghost"
                                                            size="icon"
                                                            onClick={() => removeFromCart(script.id)}
                                                            className="text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300"
                                                            aria-label={`Remover ${script.title} do carrinho`}
                                                        >
                                                            <XCircle className="h-4 w-4" />
                                                        </Button>
                                                    </Card>
                                                ))}
                                                <div className="font-bold text-lg pt-4 border-t dark:border-blue-700">
                                                    Total: ${calculateCartTotal().toFixed(2)}
                                                </div>
                                            </>
                                        )}
                                    </div>
                                    <SheetFooter>
                                        <Button
                                            onClick={checkout}
                                            disabled={cart.length === 0 || loading}
                                            className="w-full bg-blue-600 hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600"
                                        >
                                            {loading ? (
                                                <>
                                                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                                    Finalizando...
                                                </>
                                            ) : (
                                                "Finalizar Compra"
                                            )}
                                        </Button>
                                    </SheetFooter>
                                </SheetContent>
                            </Sheet>
                        )}

                        {/* Account / Login */}
                        {user ? (
                            // Account Sheet Trigger
                            <Sheet open={showAccountSheet} onOpenChange={setShowAccountSheet}>
                                <SheetTrigger asChild>
                                     <Button variant="ghost" size="icon" aria-label="Abrir minha conta">
                                        <User className="h-5 w-5 sm:h-6 sm:w-6" />
                                    </Button>
                                </SheetTrigger>
                                <SheetContent side="right" className="w-full sm:max-w-md dark:bg-blue-900">
                                    <SheetHeader>
                                        <SheetTitle>Minha Conta</SheetTitle>
                                        <SheetDescription>
                                            Bem-vindo, {user.name}!
                                        </SheetDescription>
                                    </SheetHeader>
                                    {/* Account Tabs */}
                                    <Tabs defaultValue="profile" className="w-full mt-4">
                                        <TabsList className="grid w-full grid-cols-2 mb-4 dark:bg-blue-800">
                                            <TabsTrigger value="profile" className="dark:data-[state=active]:bg-blue-700 dark:data-[state=active]:text-blue-50">Perfil</TabsTrigger>
                                            <TabsTrigger value="purchases" className="dark:data-[state=active]:bg-blue-700 dark:data-[state=active]:text-blue-50">Compras</TabsTrigger>
                                        </TabsList>
                                        {/* Profile Tab */}
                                        <TabsContent value="profile">
                                            <Card className="dark:bg-blue-800">
                                                <CardHeader>
                                                    <CardTitle>Informações do Perfil</CardTitle>
                                                </CardHeader>
                                                <CardContent className="space-y-4">
                                                    {/* Form fields - Add onChange handlers and state for updates */}
                                                    <Input label="Nome" id="name" value={user.name} disabled className="dark:bg-blue-700 dark:border-blue-600" />
                                                    <Input label="Email" id="email" type="email" defaultValue={user.email} className="dark:bg-blue-700 dark:border-blue-600" />
                                                    <Input label="Telefone" id="phone" type="tel" defaultValue={user.phone} className="dark:bg-blue-700 dark:border-blue-600" />
                                                </CardContent>
                                                <CardFooter>
                                                    <Button className="bg-blue-600 hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600">Atualizar Perfil</Button>
                                                </CardFooter>
                                            </Card>
                                        </TabsContent>
                                        {/* Purchases Tab */}
                                        <TabsContent value="purchases">
                                            <Card className="dark:bg-blue-800">
                                                <CardHeader>
                                                    <CardTitle>Minhas Compras</CardTitle>
                                                </CardHeader>
                                                <CardContent>
                                                    {purchases.length === 0 ? (
                                                        <p className="text-muted-foreground dark:text-blue-300">Você ainda não fez nenhuma compra.</p>
                                                    ) : (
                                                        <div className="space-y-4">
                                                            {purchases.map((script) => (
                                                                <Card key={script.id} className="dark:bg-blue-700">
                                                                    <CardHeader className="p-4">
                                                                        <CardTitle className="text-base">{script.title}</CardTitle>
                                                                        <CardDescription className="dark:text-blue-200">
                                                                            Preço: ${script.price.toFixed(2)}
                                                                        </CardDescription>
                                                                    </CardHeader>
                                                                    <CardContent className="p-4">
                                                                        <a
                                                                            href={script.file} // In real app, this might trigger a secure download
                                                                            download
                                                                            className="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 underline inline-flex items-center"
                                                                        >
                                                                            <File className="mr-1 h-4 w-4" />
                                                                            Baixar Script
                                                                        </a>
                                                                    </CardContent>
                                                                </Card>
                                                            ))}
                                                        </div>
                                                    )}
                                                </CardContent>
                                            </Card>
                                        </TabsContent>
                                    </Tabs>
                                    {/* Logout Button */}
                                    <SheetFooter className="mt-6">
                                        <Button variant="outline" onClick={handleLogout} className="w-full dark:border-blue-600 dark:text-blue-300 dark:hover:bg-blue-700 dark:hover:text-blue-100">
                                            <LogOut className="mr-2 h-4 w-4" />
                                            Logout
                                        </Button>
                                    </SheetFooter>
                                </SheetContent>
                            </Sheet>
                        ) : (
                            // Login/Register Sheet Trigger
                            <Sheet open={showLoginSheet} onOpenChange={setShowLoginSheet}>
                                <SheetTrigger asChild>
                                    <Button variant="outline" className="dark:border-blue-600 dark:text-blue-300 dark:hover:bg-blue-700 dark:hover:text-blue-100">
                                        <LogIn className="mr-2 h-4 w-4" />
                                        Login / Cadastro
                                    </Button>
                                </SheetTrigger>
                                <SheetContent side="right" className="w-full sm:max-w-md dark:bg-blue-900">
                                    <SheetHeader>
                                        <SheetTitle>Acessar Conta</SheetTitle>
                                        <SheetDescription>
                                            Faça login ou crie uma conta.
                                        </SheetDescription>
                                    </SheetHeader>
                                    {/* Login/Register Tabs */}
                                    <Tabs defaultValue="login" className="w-full mt-4">
                                        <TabsList className="grid w-full grid-cols-2 mb-4 dark:bg-blue-800">
                                            <TabsTrigger value="login" className="dark:data-[state=active]:bg-blue-700 dark:data-[state=active]:text-blue-50">Login</TabsTrigger>
                                            <TabsTrigger value="register" className="dark:data-[state=active]:bg-blue-700 dark:data-[state=active]:text-blue-50">Cadastro</TabsTrigger>
                                        </TabsList>
                                        {/* Login Tab */}
                                        <TabsContent value="login">
                                            <Card className="dark:bg-blue-800">
                                                <CardHeader>
                                                    <CardTitle>Login</CardTitle>
                                                </CardHeader>
                                                <CardContent className="space-y-4">
                                                    {/* Add form handling (state, validation) */}
                                                    <Input label="Email" id="login-email" type="email" placeholder="seuemail@exemplo.com" className="dark:bg-blue-700 dark:border-blue-600" />
                                                    <Input label="Senha" id="login-password" type="password" placeholder="********" className="dark:bg-blue-700 dark:border-blue-600" />
                                                </CardContent>
                                                <CardFooter className="flex flex-col gap-2">
                                                     <Button className="w-full bg-blue-600 hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600" onClick={() => handleLogin(false)}>Entrar</Button>
                                                     <Button variant="link" className="text-xs dark:text-blue-300" onClick={() => handleLogin(true)}>Entrar como Admin (Teste)</Button>
                                                </CardFooter>
                                            </Card>
                                        </TabsContent>
                                        {/* Register Tab */}
                                        <TabsContent value="register">
                                            <Card className="dark:bg-blue-800">
                                                <CardHeader>
                                                    <CardTitle>Cadastro</CardTitle>
                                                </CardHeader>
                                                <CardContent className="space-y-4">
                                                    {/* Add form handling (state, validation) */}
                                                    <Input label="Nome Completo" id="register-name" placeholder="Seu Nome" className="dark:bg-blue-700 dark:border-blue-600" />
                                                    <Input label="Email" id="register-email" type="email" placeholder="seuemail@exemplo.com" className="dark:bg-blue-700 dark:border-blue-600" />
                                                    <Input label="Telefone" id="register-phone" type="tel" placeholder="+244 9XX XXX XXX" className="dark:bg-blue-700 dark:border-blue-600" />
                                                    <Input label="Senha" id="register-password" type="password" placeholder="********" className="dark:bg-blue-700 dark:border-blue-600" />
                                                </CardContent>
                                                <CardFooter>
                                                    {/* Add registration logic */}
                                                    <Button className="w-full bg-blue-600 hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600">Cadastrar</Button>
                                                </CardFooter>
                                            </Card>
                                        </TabsContent>
                                    </Tabs>
                                </SheetContent>
                            </Sheet>
                        )}
                    </div>
                </div>
            </header>

            {/* Main Content Area */}
            <main className="container py-8">
                {/* Admin Panel */}
                {user?.isAdmin ? (
                    <Tabs defaultValue="manageScripts" className="w-full">
                        {/* Admin Tabs List */}
                        <TabsList className="grid w-full grid-cols-3 mb-8 dark:bg-blue-800">
                            <TabsTrigger value="manageScripts" className="dark:data-[state=active]:bg-blue-700 dark:data-[state=active]:text-blue-50">Gerenciar Scripts</TabsTrigger>
                            <TabsTrigger value="adminRules" className="dark:data-[state=active]:bg-blue-700 dark:data-[state=active]:text-blue-50">Regras Admin</TabsTrigger>
                            <TabsTrigger value="adminConfig" className="dark:data-[state=active]:bg-blue-700 dark:data-[state=active]:text-blue-50">Configurações</TabsTrigger>
                        </TabsList>

                        {/* Manage Scripts Tab */}
                        <TabsContent value="manageScripts">
                            <Card className="dark:bg-blue-900">
                                <CardHeader>
                                    <CardTitle>Gerenciar Scripts</CardTitle>
                                    <CardDescription className="dark:text-blue-300">Adicione, edite ou remova scripts.</CardDescription>
                                </CardHeader>
                                <CardContent className="space-y-6">
                                    {/* List Existing Scripts */}
                                    {scripts.map((script) => (
                                        <Card key={script.id} className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 dark:bg-blue-800">
                                            <div className="flex-1">
                                                <CardTitle className="text-base">{script.title}</CardTitle>
                                                <CardDescription className="text-sm mt-1 dark:text-blue-200">{script.description}</CardDescription>
                                                <p className="text-sm font-medium mt-2">Preço: ${script.price.toFixed(2)}</p>
                                            </div>
                                            <div className="flex gap-2 mt-2 sm:mt-0">
                                                <Button variant="outline" size="sm" className="dark:border-blue-600 dark:text-blue-300 dark:hover:bg-blue-700">Editar</Button>
                                                <AlertDialog>
                                                    <AlertDialogTrigger asChild>
                                                        <Button variant="destructive" size="sm">Remover</Button>
                                                    </AlertDialogTrigger>
                                                    <AlertDialogContent className="dark:bg-blue-900">
                                                        <AlertDialogHeader>
                                                            <AlertDialogTitle>Tem certeza?</AlertDialogTitle>
                                                            <AlertDialogDescription className="dark:text-blue-300">
                                                                Esta ação não pode ser desfeita. O script será removido permanentemente.
                                                            </AlertDialogDescription>
                                                        </AlertDialogHeader>
                                                        <AlertDialogFooter>
                                                            <AlertDialogCancel className="dark:border-blue-600 dark:text-blue-300 dark:hover:bg-blue-700">Cancelar</AlertDialogCancel>
                                                            <AlertDialogAction className="bg-red-600 hover:bg-red-700">Remover</AlertDialogAction>
                                                        </AlertDialogFooter>
                                                    </AlertDialogContent>
                                                </AlertDialog>
                                            </div>
                                        </Card>
                                    ))}

                                    {/* Add New Script Form */}
                                    <Card className="mt-6 dark:bg-blue-800">
                                        <CardHeader>
                                            <CardTitle>Adicionar Novo Script</CardTitle>
                                        </CardHeader>
                                        <CardContent>
                                            {/* Use React Hook Form or similar for better form management */}
                                            <form onSubmit={(e) => {
                                                e.preventDefault();
                                                const formData = new FormData(e.target as HTMLFormElement);
                                                const newScriptData = {
                                                    title: formData.get('new-title') as string,
                                                    description: formData.get('new-description') as string,
                                                    price: parseFloat(formData.get('new-price') as string),
                                                    tags: (formData.get('new-tags') as string).split(',').map(tag => tag.trim()).filter(Boolean),
                                                    // Handle file inputs separately if needed
                                                };
                                                addScript(newScriptData);
                                                (e.target as HTMLFormElement).reset(); // Reset form after submission
                                            }} className="space-y-4">
                                                <Input label="Título" name="new-title" id="new-title" placeholder="Título do Script" required className="dark:bg-blue-700 dark:border-blue-600" />
                                                <Textarea label="Descrição" name="new-description" id="new-description" placeholder="Descrição detalhada do script" required className="dark:bg-blue-700 dark:border-blue-600" />
                                                <Input label="Preço ($)" name="new-price" id="new-price" type="number" step="0.01" placeholder="Ex: 99.90" required className="dark:bg-blue-700 dark:border-blue-600" />
                                                <Input label="Tags (separadas por vírgula)" name="new-tags" id="new-tags" placeholder="ex: automacao, python, web" className="dark:bg-blue-700 dark:border-blue-600" />
                                                {/* File inputs - requires more complex handling for uploads */}
                                                <Input label="Arquivo do Script (.zip)" name="new-file" id="new-file" type="file" accept=".zip" className="dark:bg-blue-700 dark:border-blue-600 file:text-blue-100" />
                                                <Input label="Imagem de Prévia" name="new-image" id="new-image" type="file" accept="image/*" className="dark:bg-blue-700 dark:border-blue-600 file:text-blue-100" />
                                                <Button type="submit" className="bg-blue-600 hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600">
                                                    <UploadCloud className="mr-2 h-4 w-4" />
                                                    Adicionar Script
                                                </Button>
                                            </form>
                                        </CardContent>
                                    </Card>
                                </CardContent>
                            </Card>
                        </TabsContent>

                        {/* Admin Rules Tab */}
                        <TabsContent value="adminRules">
                            <Card className="dark:bg-blue-900">
                                <CardHeader>
                                    <CardTitle>Regras do Administrador</CardTitle>
                                    <CardDescription className="dark:text-blue-300">Edite as regras da plataforma.</CardDescription>
                                </CardHeader>
                                <CardContent>
                                    <Textarea
                                        value={adminRules}
                                        onChange={(e) => setAdminRules(e.target.value)} // Directly update state for demo
                                        className="min-h-[200px] dark:bg-blue-800 dark:border-blue-600"
                                        aria-label="Editor de regras do administrador"
                                    />
                                </CardContent>
                                <CardFooter>
                                    <Button onClick={() => updateAdminRules(adminRules)} className="bg-blue-600 hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600">
                                        Salvar Regras
                                    </Button>
                                </CardFooter>
                            </Card>
                        </TabsContent>

                        {/* Admin Config Tab */}
                        <TabsContent value="adminConfig">
                            <Card className="dark:bg-blue-900">
                                <CardHeader>
                                    <CardTitle>Configurações do Administrador</CardTitle>
                                    <CardDescription className="dark:text-blue-300">Gerencie chaves e outras opções.</CardDescription>
                                </CardHeader>
                                <CardContent className="space-y-4">
                                    <div className="space-y-2">
                                        <label htmlFor="download-key" className="text-sm font-medium block">Chave de Download Atual</label>
                                        <div className="flex items-center gap-2">
                                            <Input id="download-key" value={downloadKey} readOnly disabled className="flex-1 dark:bg-blue-800 dark:border-blue-600 dark:text-blue-300" />
                                            <Button onClick={generateDownloadKey} variant="outline" className="dark:border-blue-600 dark:text-blue-300 dark:hover:bg-blue-700">
                                                <KeyRound className="mr-2 h-4 w-4" />
                                                Gerar Nova Chave
                                            </Button>
                                        </div>
                                    </div>
                                    {/* Placeholder for future settings */}
                                    <div>
                                        <h3 className="text-lg font-semibold mb-2 mt-6">Outras Configurações</h3>
                                         <p className="text-muted-foreground dark:text-blue-300">Área para futuras configurações (ex: controle de acesso, logs).</p>
                                    </div>
                                </CardContent>
                            </Card>
                        </TabsContent>
                    </Tabs>
                ) : (
                    /* User View (Non-Admin) */
                    <>
                        {/* Welcome Section */}
                        <section className="mb-12 text-center">
                            <h2 className="text-3xl sm:text-4xl font-bold mb-3">Bem-vindo à Script Market</h2>
                            <p className="text-lg text-muted-foreground dark:text-blue-300 max-w-2xl mx-auto">
                                A sua plataforma completa para comprar e vender scripts seguros e eficientes em Angola.
                            </p>
                        </section>

                        {/* Featured Scripts Section */}
                        <section>
                            <h2 className="text-2xl font-semibold mb-6">Scripts em Destaque</h2>
                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                                {scripts.map((script) => (
                                    <Card key={script.id} className="group overflow-hidden flex flex-col dark:bg-blue-900">
                                        <div className="relative h-48 w-full">
                                            <img
                                                src={script.image}
                                                alt={`Prévia de ${script.title}`}
                                                className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                                                onError={(e) => (e.currentTarget.src = 'https://placehold.co/400x200/7E8EFF/31343C?text=Imagem+Indispon%C3%ADvel')} // Fallback
                                            />
                                            {/* Overlay effect on hover */}
                                            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                                        </div>
                                        <CardHeader className="flex-grow">
                                            <CardTitle className="text-lg">{script.title}</CardTitle>
                                            <CardDescription className="mt-1 text-sm dark:text-blue-200">{script.description}</CardDescription>
                                        </CardHeader>
                                        <CardContent>
                                            <p className="text-lg font-semibold">Preço: ${script.price.toFixed(2)}</p>
                                            {/* Tags */}
                                            <div className="mt-3 flex flex-wrap gap-2">
                                                {script.tags.map((tag) => (
                                                    <span key={tag} className="bg-secondary text-secondary-foreground dark:bg-blue-700 dark:text-blue-100 px-2 py-0.5 rounded-full text-xs font-medium">
                                                        {tag}
                                                    </span>
                                                ))}
                                            </div>
                                        </CardContent>
                                        <CardFooter>
                                            <Button
                                                className="w-full bg-blue-600 hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600 disabled:opacity-50"
                                                onClick={() => addToCart(script)}
                                                disabled={!!cart.find((item) => item.id === script.id) || !user} // Disable if in cart or not logged in
                                                aria-label={cart.find((item) => item.id === script.id) ? `${script.title} já está no carrinho` : `Adicionar ${script.title} ao carrinho`}
                                            >
                                                {cart.find((item) => item.id === script.id)
                                                    ? (<><CheckCircle className="mr-2 h-4 w-4"/> Adicionado</>)
                                                    : "Adicionar ao Carrinho"
                                                }
                                            </Button>
                                        </CardFooter>
                                    </Card>
                                ))}
                            </div>
                            {!user && (
                                <p className="text-center mt-6 text-muted-foreground dark:text-blue-300">
                                    <Button variant="link" onClick={() => setShowLoginSheet(true)} className="dark:text-blue-400">Faça login</Button> para adicionar itens ao carrinho.
                                </p>
                            )}
                        </section>
                    </>
                )}
            </main>

            {/* Footer */}
            <footer className={cn(
                "py-6 border-t mt-12",
                "bg-gray-100 text-gray-600 border-gray-200", // Light mode footer
                "dark:bg-blue-900 dark:text-blue-300 dark:border-blue-800" // Dark mode blue footer
            )}>
                <div className="container text-center text-sm">
                    <p>&copy; {new Date().getFullYear()} Script Market. Todos os direitos reservados.</p>
                    <p className="mt-1">Desenvolvido com ❤️ em Angola.</p>
                </div>
            </footer>

             {/* Helper Components (Input with Label) */}
             {/* These should ideally be in their own files */}
             {/* Removed the separate Input component definition as it's assumed to come from '@/components/ui/input' */}

        </div>
    );
};

// Helper component (can be moved to its own file)
// Note: shadcn/ui Input doesn't directly accept a label prop like this.
// You'd typically use the <Label> component from shadcn/ui separately.
// This is a simplified example.
interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
  id: string;
}

const InputWithLabel: React.FC<InputProps> = ({ label, id, ...props }) => (
  <div className="space-y-1">
    <label htmlFor={id} className="text-sm font-medium block dark:text-blue-100">{label}</label>
    <Input id={id} {...props} />
  </div>
);

// Helper component (can be moved to its own file)
interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label: string;
  id: string;
}
const TextareaWithLabel: React.FC<TextareaProps> = ({ label, id, ...props }) => (
    <div className="space-y-1">
        <label htmlFor={id} className="text-sm font-medium block dark:text-blue-100">{label}</label>
        <Textarea id={id} {...props} />
    </div>
);


export default App;


