import React, { useState, useEffect } from 'react';
import { UploadCloud, KeyRound, AlertTriangle } from 'lucide-react';
import { getAllScripts, addScript, deleteScript } from '../services/scripts';
import { getAdminRules, updateAdminRules, getDownloadKey, generateDownloadKey } from '../services/admin';
import type { Script } from '../types';

const AdminPanel: React.FC = () => {
  const [activeTab, setActiveTab] = useState('manageScripts');
  const [scripts, setScripts] = useState<Script[]>([]);
  const [adminRules, setAdminRules] = useState('');
  const [downloadKey, setDownloadKey] = useState('');
  const [loading, setLoading] = useState(false);
  
  const [newScript, setNewScript] = useState({
    title: '',
    description: '',
    price: '',
    tags: ''
  });
  const [scriptFile, setScriptFile] = useState<File | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);

  // Load scripts when component mounts
  useEffect(() => {
    const loadScripts = async () => {
      try {
        setLoading(true);
        const allScripts = await getAllScripts();
        setScripts(allScripts);
      } catch (err) {
        console.error('Error loading scripts:', err);
      } finally {
        setLoading(false);
      }
    };

    loadScripts();
  }, []);

  // Load admin data when tab changes
  useEffect(() => {
    const loadAdminData = async () => {
      if (activeTab === 'adminRules') {
        try {
          const rules = await getAdminRules();
          setAdminRules(rules);
        } catch (err) {
          console.error('Error loading admin rules:', err);
        }
      } else if (activeTab === 'adminConfig') {
        try {
          const key = await getDownloadKey();
          setDownloadKey(key);
        } catch (err) {
          console.error('Error loading download key:', err);
        }
      }
    };

    loadAdminData();
  }, [activeTab]);

  // Handle script form input change
  const handleScriptInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setNewScript(prev => ({ ...prev, [name]: value }));
  };

  // Handle script file input change
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      if (e.target.name === 'scriptFile') {
        setScriptFile(e.target.files[0]);
      } else if (e.target.name === 'imageFile') {
        setImageFile(e.target.files[0]);
      }
    }
  };

  // Add new script
  const handleAddScript = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      setLoading(true);
      
      const scriptData = {
        title: newScript.title,
        description: newScript.description,
        price: parseFloat(newScript.price),
        tags: newScript.tags.split(',').map(tag => tag.trim()).filter(Boolean),
        userId: 'admin', // In a real app, use the current user's ID
      };
      
      const newScriptData = await addScript(scriptData, scriptFile || undefined, imageFile || undefined);
      
      setScripts(prev => [newScriptData, ...prev]);
      
      // Reset form
      setNewScript({
        title: '',
        description: '',
        price: '',
        tags: ''
      });
      setScriptFile(null);
      setImageFile(null);
      
      alert('Script adicionado com sucesso!');
    } catch (err) {
      console.error('Error adding script:', err);
      alert('Erro ao adicionar script. Por favor, tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  // Delete script
  const handleDeleteScript = async (scriptId: string) => {
    if (!confirm('Tem certeza que deseja remover este script? Esta ação não pode ser desfeita.')) {
      return;
    }
    
    try {
      setLoading(true);
      await deleteScript(scriptId);
      setScripts(prev => prev.filter(script => script.id !== scriptId));
      alert('Script removido com sucesso!');
    } catch (err) {
      console.error('Error deleting script:', err);
      alert('Erro ao remover script. Por favor, tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  // Update admin rules
  const handleUpdateRules = async () => {
    try {
      setLoading(true);
      await updateAdminRules(adminRules);
      alert('Regras atualizadas com sucesso!');
    } catch (err) {
      console.error('Error updating rules:', err);
      alert('Erro ao atualizar regras. Por favor, tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  // Generate new download key
  const handleGenerateKey = async () => {
    try {
      setLoading(true);
      const newKey = await generateDownloadKey();
      setDownloadKey(newKey);
      alert('Nova chave de download gerada com sucesso!');
    } catch (err) {
      console.error('Error generating key:', err);
      alert('Erro ao gerar nova chave. Por favor, tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <h2 className="text-2xl font-bold mb-6">Painel de Administração</h2>
      
      {/* Admin Tabs */}
      <div className="flex border-b dark:border-blue-800 mb-6">
        <button
          className={`px-4 py-2 font-medium ${
            activeTab === 'manageScripts'
              ? 'border-b-2 border-blue-600 dark:border-blue-400 text-blue-600 dark:text-blue-400'
              : 'text-gray-600 dark:text-blue-300'
          }`}
          onClick={() => setActiveTab('manageScripts')}
        >
          Gerenciar Scripts
        </button>
        <button
          className={`px-4 py-2 font-medium ${
            activeTab === 'adminRules'
              ? 'border-b-2 border-blue-600 dark:border-blue-400 text-blue-600 dark:text-blue-400'
              : 'text-gray-600 dark:text-blue-300'
          }`}
          onClick={() => setActiveTab('adminRules')}
        >
          Regras Admin
        </button>
        <button
          className={`px-4 py-2 font-medium ${
            activeTab === 'adminConfig'
              ? 'border-b-2 border-blue-600 dark:border-blue-400 text-blue-600 dark:text-blue-400'
              : 'text-gray-600 dark:text-blue-300'
          }`}
          onClick={() => setActiveTab('adminConfig')}
        >
          Configurações
        </button>
      </div>
      
      {/* Tab Content */}
      {activeTab === 'manageScripts' && (
        <div>
          <div className="bg-white dark:bg-blue-900 rounded-lg shadow-md p-6 mb-6">
            <h3 className="text-xl font-semibold mb-4">Scripts Disponíveis</h3>
            
            {loading && scripts.length === 0 ? (
              <div className="flex items-center justify-center h-40">
                <div className="animate-spin h-8 w-8 border-4 border-blue-600 dark:border-blue-400 rounded-full border-t-transparent"></div>
              </div>
            ) : scripts.length === 0 ? (
              <p className="text-gray-600 dark:text-blue-300 text-center py-8">
                Nenhum script disponível no momento.
              </p>
            ) : (
              <div className="space-y-4">
                {scripts.map(script => (
                  <div 
                    key={script.id}
                    className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 bg-gray-50 dark:bg-blue-800 rounded-lg"
                  >
                    <div className="flex-1">
                      <h4 className="font-medium">{script.title}</h4>
                      <p className="text-sm text-gray-600 dark:text-blue-300 mt-1">{script.description}</p>
                      <p className="text-sm font-medium mt-2">${script.price.toFixed(2)}</p>
                    </div>
                    <div className="flex gap-2 self-end sm:self-auto">
                      <button
                        onClick={() => alert('Função de edição em desenvolvimento')}
                        className="px-3 py-1 text-sm rounded-md border border-gray-300 dark:border-blue-700 hover:bg-gray-100 dark:hover:bg-blue-700"
                      >
                        Editar
                      </button>
                      <button
                        onClick={() => handleDeleteScript(script.id)}
                        className="px-3 py-1 text-sm rounded-md bg-red-600 hover:bg-red-700 text-white"
                      >
                        Remover
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
          
          <div className="bg-white dark:bg-blue-900 rounded-lg shadow-md p-6">
            <h3 className="text-xl font-semibold mb-4">Adicionar Novo Script</h3>
            
            <form onSubmit={handleAddScript} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Título</label>
                <input
                  type="text"
                  name="title"
                  value={newScript.title}
                  onChange={handleScriptInputChange}
                  required
                  className="w-full px-3 py-2 border rounded-md dark:bg-blue-800 dark:border-blue-700 dark:text-blue-50"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Descrição</label>
                <textarea
                  name="description"
                  value={newScript.description}
                  onChange={handleScriptInputChange}
                  required
                  className="w-full px-3 py-2 border rounded-md dark:bg-blue-800 dark:border-blue-700 dark:text-blue-50 min-h-[100px]"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Preço ($)</label>
                <input
                  type="number"
                  step="0.01"
                  name="price"
                  value={newScript.price}
                  onChange={handleScriptInputChange}
                  required
                  className="w-full px-3 py-2 border rounded-md dark:bg-blue-800 dark:border-blue-700 dark:text-blue-50"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Tags (separadas por vírgula)</label>
                <input
                  type="text"
                  name="tags"
                  value={newScript.tags}
                  onChange={handleScriptInputChange}
                  placeholder="ex: automação, python, web"
                  className="w-full px-3 py-2 border rounded-md dark:bg-blue-800 dark:border-blue-700 dark:text-blue-50"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Arquivo do Script (.zip)</label>
                <input
                  type="file"
                  name="scriptFile"
                  accept=".zip"
                  onChange={handleFileChange}
                  className="w-full px-3 py-2 border rounded-md dark:bg-blue-800 dark:border-blue-700 dark:text-blue-50"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Imagem de Prévia</label>
                <input
                  type="file"
                  name="imageFile"
                  accept="image/*"
                  onChange={handleFileChange}
                  className="w-full px-3 py-2 border rounded-md dark:bg-blue-800 dark:border-blue-700 dark:text-blue-50"
                />
              </div>
              
              <button
                type="submit"
                disabled={loading}
                className="px-4 py-2 rounded-md bg-blue-600 hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600 text-white font-medium disabled:opacity-50 flex items-center"
              >
                <UploadCloud className="mr-2 h-4 w-4" />
                {loading ? 'Adicionando...' : 'Adicionar Script'}
              </button>
            </form>
          </div>
        </div>
      )}
      
      {activeTab === 'adminRules' && (
        <div className="bg-white dark:bg-blue-900 rounded-lg shadow-md p-6">
          <h3 className="text-xl font-semibold mb-4">Regras do Administrador</h3>
          
          <textarea
            value={adminRules}
            onChange={(e) => setAdminRules(e.target.value)}
            className="w-full px-3 py-2 border rounded-md dark:bg-blue-800 dark:border-blue-700 dark:text-blue-50 min-h-[300px]"
          />
          
          <button
            onClick={handleUpdateRules}
            disabled={loading}
            className="mt-4 px-4 py-2 rounded-md bg-blue-600 hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600 text-white font-medium disabled:opacity-50"
          >
            {loading ? 'Salvando...' : 'Salvar Regras'}
          </button>
        </div>
      )}
      
      {activeTab === 'adminConfig' && (
        <div className="bg-white dark:bg-blue-900 rounded-lg shadow-md p-6">
          <h3 className="text-xl font-semibold mb-4">Configurações do Administrador</h3>
          
          <div className="mb-8">
            <h4 className="text-lg font-medium mb-2">Chave de Download</h4>
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={downloadKey}
                readOnly
                className="flex-1 px-3 py-2 border rounded-md bg-gray-50 dark:bg-blue-800 dark:border-blue-700 dark:text-blue-50"
              />
              <button
                onClick={handleGenerateKey}
                disabled={loading}
                className="px-4 py-2 rounded-md border border-gray-300 dark:border-blue-700 hover:bg-gray-100 dark:hover:bg-blue-700 flex items-center whitespace-nowrap"
              >
                <KeyRound className="mr-2 h-4 w-4" />
                {loading ? 'Gerando...' : 'Gerar Nova Chave'}
              </button>
            </div>
          </div>
          
          <div className="bg-yellow-50 dark:bg-yellow-900/20 border-l-4 border-yellow-500 p-4 rounded-r-md">
            <div className="flex">
              <AlertTriangle className="h-6 w-6 text-yellow-500 mr-3 flex-shrink-0" />
              <div>
                <h4 className="font-medium text-yellow-800 dark:text-yellow-400">Aviso de Segurança</h4>
                <p className="text-sm text-yellow-700 dark:text-yellow-300">
                  Lembre-se de proteger as chaves de download e outras configurações sensíveis.
                  Apenas administradores devem ter acesso a estas informações.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminPanel;