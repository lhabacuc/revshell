import React, { useState } from 'react';
import { XCircle, LogIn, User, Mail, Phone, Lock } from 'lucide-react';
import { signIn, signUp } from '../services/auth';

interface LoginSheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const LoginSheet: React.FC<LoginSheetProps> = ({ open, onOpenChange }) => {
  const [activeTab, setActiveTab] = useState('login');
  const [loading, setLoading] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  
  const [loginForm, setLoginForm] = useState({
    email: '',
    password: ''
  });
  
  const [registerForm, setRegisterForm] = useState({
    name: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: ''
  });

  // Handle login input change
  const handleLoginChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setLoginForm(prev => ({ ...prev, [name]: value }));
  };

  // Handle register input change
  const handleRegisterChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setRegisterForm(prev => ({ ...prev, [name]: value }));
  };

  // Handle login form submit
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    
    // Validate form
    if (!loginForm.email || !loginForm.password) {
      setFormError('Por favor, preencha todos os campos.');
      return;
    }
    
    try {
      setLoading(true);
      await signIn(loginForm.email, loginForm.password);
      onOpenChange(false);
    } catch (error: any) {
      console.error('Login error:', error);
      setFormError(
        error.code === 'auth/invalid-credential' 
          ? 'Email ou senha inválidos.' 
          : 'Erro ao fazer login. Tente novamente.'
      );
    } finally {
      setLoading(false);
    }
  };

  // Handle register form submit
  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    
    // Validate form
    if (!registerForm.name || !registerForm.email || !registerForm.password) {
      setFormError('Por favor, preencha todos os campos obrigatórios.');
      return;
    }
    
    if (registerForm.password !== registerForm.confirmPassword) {
      setFormError('As senhas não coincidem.');
      return;
    }
    
    if (registerForm.password.length < 6) {
      setFormError('A senha deve ter pelo menos 6 caracteres.');
      return;
    }
    
    try {
      setLoading(true);
      await signUp(
        registerForm.email, 
        registerForm.password, 
        registerForm.name,
        registerForm.phone
      );
      onOpenChange(false);
    } catch (error: any) {
      console.error('Register error:', error);
      if (error.code === 'auth/email-already-in-use') {
        setFormError('Este email já está em uso.');
      } else {
        setFormError('Erro ao criar conta. Tente novamente.');
      }
    } finally {
      setLoading(false);
    }
  };

  // Handle admin login (for demo)
  const handleAdminLogin = async () => {
    try {
      setLoading(true);
      // In a real app, you'd use a real admin account
      // This is just for demonstration purposes
      await signIn('admin@example.com', 'admin123');
      onOpenChange(false);
    } catch (error) {
      console.error('Admin login error:', error);
      setFormError('Erro ao fazer login como admin.');
    } finally {
      setLoading(false);
    }
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm">
      <div className="fixed right-0 top-0 h-full w-full max-w-md bg-white dark:bg-blue-900 shadow-lg">
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="p-4 border-b dark:border-blue-800 flex items-center justify-between">
            <div>
              <h2 className="text-lg font-semibold">Acessar Conta</h2>
              <p className="text-sm text-gray-600 dark:text-blue-300">
                Faça login ou crie uma conta.
              </p>
            </div>
            <button 
              onClick={() => onOpenChange(false)}
              className="text-gray-400 hover:text-gray-600 dark:text-blue-400 dark:hover:text-blue-200"
            >
              <XCircle className="h-6 w-6" />
            </button>
          </div>

          {/* Tabs */}
          <div className="border-b dark:border-blue-800">
            <div className="flex">
              <button
                className={`flex-1 px-4 py-2 font-medium ${
                  activeTab === 'login'
                    ? 'border-b-2 border-blue-600 dark:border-blue-400 text-blue-600 dark:text-blue-400'
                    : 'text-gray-600 dark:text-blue-300'
                }`}
                onClick={() => setActiveTab('login')}
              >
                Login
              </button>
              <button
                className={`flex-1 px-4 py-2 font-medium ${
                  activeTab === 'register'
                    ? 'border-b-2 border-blue-600 dark:border-blue-400 text-blue-600 dark:text-blue-400'
                    : 'text-gray-600 dark:text-blue-300'
                }`}
                onClick={() => setActiveTab('register')}
              >
                Cadastro
              </button>
            </div>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-auto p-4">
            {formError && (
              <div className="mb-4 p-3 rounded-md bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300 text-sm">
                {formError}
              </div>
            )}
            
            {activeTab === 'login' ? (
              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Email</label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Mail className="h-5 w-5 text-gray-400 dark:text-blue-500" />
                    </div>
                    <input
                      type="email"
                      name="email"
                      placeholder="seu@email.com"
                      value={loginForm.email}
                      onChange={handleLoginChange}
                      className="w-full pl-10 pr-3 py-2 border rounded-md dark:bg-blue-800 dark:border-blue-700 dark:text-blue-50"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Senha</label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Lock className="h-5 w-5 text-gray-400 dark:text-blue-500" />
                    </div>
                    <input
                      type="password"
                      name="password"
                      placeholder="********"
                      value={loginForm.password}
                      onChange={handleLoginChange}
                      className="w-full pl-10 pr-3 py-2 border rounded-md dark:bg-blue-800 dark:border-blue-700 dark:text-blue-50"
                    />
                  </div>
                </div>
                
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-2 rounded-md bg-blue-600 hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600 text-white font-medium disabled:opacity-50"
                >
                  {loading ? 'Entrando...' : 'Entrar'}
                </button>
                
                {/* Demo admin login */}
                <button
                  type="button"
                  onClick={handleAdminLogin}
                  className="w-full text-center text-sm text-blue-600 dark:text-blue-400 hover:underline mt-2"
                >
                  Entrar como Admin (Demo)
                </button>
              </form>
            ) : (
              <form onSubmit={handleRegister} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Nome Completo</label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <User className="h-5 w-5 text-gray-400 dark:text-blue-500" />
                    </div>
                    <input
                      type="text"
                      name="name"
                      placeholder="Seu nome"
                      value={registerForm.name}
                      onChange={handleRegisterChange}
                      className="w-full pl-10 pr-3 py-2 border rounded-md dark:bg-blue-800 dark:border-blue-700 dark:text-blue-50"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Email</label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Mail className="h-5 w-5 text-gray-400 dark:text-blue-500" />
                    </div>
                    <input
                      type="email"
                      name="email"
                      placeholder="seu@email.com"
                      value={registerForm.email}
                      onChange={handleRegisterChange}
                      className="w-full pl-10 pr-3 py-2 border rounded-md dark:bg-blue-800 dark:border-blue-700 dark:text-blue-50"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Telefone</label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Phone className="h-5 w-5 text-gray-400 dark:text-blue-500" />
                    </div>
                    <input
                      type="tel"
                      name="phone"
                      placeholder="+244 9XX XXX XXX"
                      value={registerForm.phone}
                      onChange={handleRegisterChange}
                      className="w-full pl-10 pr-3 py-2 border rounded-md dark:bg-blue-800 dark:border-blue-700 dark:text-blue-50"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Senha</label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Lock className="h-5 w-5 text-gray-400 dark:text-blue-500" />
                    </div>
                    <input
                      type="password"
                      name="password"
                      placeholder="********"
                      value={registerForm.password}
                      onChange={handleRegisterChange}
                      className="w-full pl-10 pr-3 py-2 border rounded-md dark:bg-blue-800 dark:border-blue-700 dark:text-blue-50"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Confirmar Senha</label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Lock className="h-5 w-5 text-gray-400 dark:text-blue-500" />
                    </div>
                    <input
                      type="password"
                      name="confirmPassword"
                      placeholder="********"
                      value={registerForm.confirmPassword}
                      onChange={handleRegisterChange}
                      className="w-full pl-10 pr-3 py-2 border rounded-md dark:bg-blue-800 dark:border-blue-700 dark:text-blue-50"
                    />
                  </div>
                </div>
                
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-2 rounded-md bg-blue-600 hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600 text-white font-medium disabled:opacity-50"
                >
                  {loading ? 'Cadastrando...' : 'Cadastrar'}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginSheet;