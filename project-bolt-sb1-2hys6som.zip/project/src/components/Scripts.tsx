import React, { useEffect, useState } from 'react';
import { CheckCircle, ShoppingCart } from 'lucide-react';
import { getAllScripts } from '../services/scripts';
import { addToCart, getUserCart } from '../services/cart';
import { useAuth } from '../contexts/AuthContext';
import type { Script } from '../types';

const Scripts: React.FC = () => {
  const { currentUser } = useAuth();
  const [scripts, setScripts] = useState<Script[]>([]);
  const [cartItems, setCartItems] = useState<Script[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [addingToCart, setAddingToCart] = useState<string | null>(null);

  // Load scripts
  useEffect(() => {
    const loadScripts = async () => {
      try {
        setLoading(true);
        const allScripts = await getAllScripts();
        setScripts(allScripts);
      } catch (err) {
        console.error('Error loading scripts:', err);
        setError('Failed to load scripts. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    loadScripts();
  }, []);

  // Load cart items if user is logged in
  useEffect(() => {
    const loadCart = async () => {
      if (currentUser) {
        try {
          const cart = await getUserCart(currentUser.id);
          setCartItems(cart);
        } catch (err) {
          console.error('Error loading cart:', err);
        }
      } else {
        setCartItems([]);
      }
    };

    loadCart();
  }, [currentUser]);

  // Add script to cart
  const handleAddToCart = async (script: Script) => {
    if (!currentUser) {
      document.dispatchEvent(new CustomEvent('open-login-sheet'));
      return;
    }

    try {
      setAddingToCart(script.id);
      await addToCart(currentUser.id, script.id);
      setCartItems(prev => [...prev, script]);
    } catch (err) {
      console.error('Error adding to cart:', err);
      alert('Failed to add script to cart. Please try again.');
    } finally {
      setAddingToCart(null);
    }
  };

  // Check if script is in cart
  const isInCart = (scriptId: string) => {
    return cartItems.some(item => item.id === scriptId);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin h-8 w-8 border-4 border-blue-600 dark:border-blue-400 rounded-full border-t-transparent"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-12">
        <p className="text-red-500 dark:text-red-400">{error}</p>
        <button 
          onClick={() => window.location.reload()}
          className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600"
        >
          Tentar novamente
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <section className="text-center space-y-4 py-8 px-4 bg-gradient-to-r from-blue-500 to-blue-600 dark:from-blue-600 dark:to-blue-700 text-white rounded-lg shadow-lg">
        <h1 className="text-4xl font-bold">Script Market</h1>
        <p className="text-xl max-w-2xl mx-auto text-blue-100">
          Sua plataforma completa para comprar e vender scripts seguros e eficientes em Angola.
        </p>
      </section>

      {/* Scripts Grid */}
      <section className="space-y-6">
        <h2 className="text-2xl font-bold dark:text-white">Scripts em Destaque</h2>
        
        {scripts.length === 0 ? (
          <div className="text-center py-12 bg-white dark:bg-blue-900 rounded-lg shadow">
            <ShoppingCart className="h-12 w-12 mx-auto text-gray-400 dark:text-blue-500 mb-4" />
            <p className="text-gray-600 dark:text-blue-300">Nenhum script disponível no momento.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {scripts.map((script) => (
              <div 
                key={script.id} 
                className="group bg-white dark:bg-blue-900 rounded-lg shadow-lg overflow-hidden transition-transform hover:scale-[1.02] hover:shadow-xl"
              >
                <div className="relative h-48">
                  <img
                    src={script.image || `https://placehold.co/400x200/7E8EFF/31343C?text=${encodeURIComponent(script.title)}`}
                    alt={script.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
                
                <div className="p-6 space-y-4">
                  <h3 className="text-xl font-semibold dark:text-white">{script.title}</h3>
                  <p className="text-gray-600 dark:text-blue-300">{script.description}</p>
                  
                  <div className="flex flex-wrap gap-2">
                    {script.tags.map((tag) => (
                      <span 
                        key={tag}
                        className="px-3 py-1 text-sm bg-blue-100 text-blue-800 dark:bg-blue-800 dark:text-blue-100 rounded-full"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                  
                  <div className="flex items-center justify-between pt-4 border-t dark:border-blue-800">
                    <span className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                      ${script.price.toFixed(2)}
                    </span>
                    
                    <button
                      onClick={() => handleAddToCart(script)}
                      disabled={isInCart(script.id) || addingToCart === script.id}
                      className={`
                        px-4 py-2 rounded-md text-white font-medium flex items-center gap-2
                        ${isInCart(script.id)
                          ? 'bg-green-600 hover:bg-green-700 dark:bg-green-500 dark:hover:bg-green-600'
                          : 'bg-blue-600 hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600'
                        }
                        disabled:opacity-50 disabled:cursor-not-allowed
                      `}
                    >
                      {addingToCart === script.id ? (
                        <div className="animate-spin h-5 w-5 border-2 border-white rounded-full border-t-transparent" />
                      ) : isInCart(script.id) ? (
                        <>
                          <CheckCircle className="h-5 w-5" />
                          <span>No Carrinho</span>
                        </>
                      ) : (
                        <>
                          <ShoppingCart className="h-5 w-5" />
                          <span>Adicionar</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
};

export default Scripts;