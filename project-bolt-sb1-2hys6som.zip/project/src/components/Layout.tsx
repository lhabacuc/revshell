import React, { useState } from 'react';
import { 
  ShoppingCart, 
  User, 
  LogIn,
  Moon, 
  SunMedium,
  Store,
  Menu,
  X
} from 'lucide-react';
import { cn } from '../lib/utils';
import { useTheme } from '../contexts/ThemeContext';
import { useAuth } from '../contexts/AuthContext';
import CartSheet from './CartSheet';
import AccountSheet from './AccountSheet';
import LoginSheet from './LoginSheet';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const { theme, setTheme } = useTheme();
  const { currentUser } = useAuth();
  const [showCartSheet, setShowCartSheet] = useState(false);
  const [showAccountSheet, setShowAccountSheet] = useState(false);
  const [showLoginSheet, setShowLoginSheet] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const toggleDarkMode = () => {
    const newTheme = theme === 'dark' ? 'light' : 'dark';
    setTheme(newTheme);
  };

  return (
    <div className={cn(
      "min-h-screen bg-gradient-to-br from-primary-50 to-primary-100 text-dark-800",
      "dark:from-dark-800 dark:to-dark-700 dark:text-dark-100"
    )}>
      {/* Header */}
      <header className={cn(
        "sticky top-0 z-50 w-full border-b backdrop-blur-md",
        "border-primary-200 bg-white/80",
        "dark:border-dark-600 dark:bg-dark-800/80"
      )}>
        <div className="container flex items-center justify-between h-16">
          {/* Logo/Brand */}
          <div className="flex items-center gap-2">
            <Store className="h-6 w-6 text-primary-600 dark:text-primary-400" />
            <h1 className="text-xl font-bold bg-gradient-to-r from-primary-600 to-primary-500 bg-clip-text text-transparent dark:from-primary-400 dark:to-primary-300">
              Script Market
            </h1>
          </div>

          {/* Mobile menu button */}
          <button 
            className="md:hidden flex items-center" 
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>

          {/* Desktop Actions */}
          <div className="hidden md:flex items-center gap-4">
            {/* Dark Mode Toggle */}
            <button 
              onClick={toggleDarkMode} 
              className="p-2 rounded-full hover:bg-primary-100 dark:hover:bg-dark-600 transition-colors"
              aria-label="Toggle dark mode"
            >
              {theme === 'dark' ? (
                <SunMedium className="h-5 w-5" />
              ) : (
                <Moon className="h-5 w-5" />
              )}
            </button>

            {/* Cart */}
            {currentUser && (
              <button 
                onClick={() => setShowCartSheet(true)}
                className="p-2 rounded-full hover:bg-primary-100 dark:hover:bg-dark-600 transition-colors relative"
                aria-label="Open cart"
              >
                <ShoppingCart className="h-5 w-5" />
              </button>
            )}

            {/* Account / Login */}
            {currentUser ? (
              <button 
                onClick={() => setShowAccountSheet(true)}
                className="p-2 rounded-full hover:bg-primary-100 dark:hover:bg-dark-600 transition-colors"
                aria-label="Open account"
              >
                <User className="h-5 w-5" />
              </button>
            ) : (
              <button 
                onClick={() => setShowLoginSheet(true)}
                className="flex items-center gap-2 px-4 py-2 rounded-md bg-primary-500 hover:bg-primary-600 text-white transition-colors dark:bg-primary-600 dark:hover:bg-primary-700"
              >
                <LogIn className="h-4 w-4" />
                <span>Login / Cadastro</span>
              </button>
            )}
          </div>
        </div>

        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-white dark:bg-dark-800 border-b border-primary-200 dark:border-dark-600">
            <div className="container py-4 space-y-3">
              <button 
                onClick={toggleDarkMode} 
                className="flex items-center w-full gap-2 px-4 py-2 rounded-md hover:bg-primary-100 dark:hover:bg-dark-600 transition-colors"
                aria-label="Toggle dark mode"
              >
                {theme === 'dark' ? (
                  <>
                    <SunMedium className="h-5 w-5" />
                    <span>Light Mode</span>
                  </>
                ) : (
                  <>
                    <Moon className="h-5 w-5" />
                    <span>Dark Mode</span>
                  </>
                )}
              </button>

              {currentUser && (
                <button 
                  onClick={() => {
                    setShowCartSheet(true);
                    setMobileMenuOpen(false);
                  }}
                  className="flex items-center w-full gap-2 px-4 py-2 rounded-md hover:bg-primary-100 dark:hover:bg-dark-600 transition-colors"
                >
                  <ShoppingCart className="h-5 w-5" />
                  <span>Carrinho</span>
                </button>
              )}

              {currentUser ? (
                <button 
                  onClick={() => {
                    setShowAccountSheet(true);
                    setMobileMenuOpen(false);
                  }}
                  className="flex items-center w-full gap-2 px-4 py-2 rounded-md hover:bg-primary-100 dark:hover:bg-dark-600 transition-colors"
                >
                  <User className="h-5 w-5" />
                  <span>Minha Conta</span>
                </button>
              ) : (
                <button 
                  onClick={() => {
                    setShowLoginSheet(true);
                    setMobileMenuOpen(false);
                  }}
                  className="flex items-center w-full gap-2 px-4 py-2 rounded-md bg-primary-500 hover:bg-primary-600 text-white transition-colors dark:bg-primary-600 dark:hover:bg-primary-700"
                >
                  <LogIn className="h-5 w-5" />
                  <span>Login / Cadastro</span>
                </button>
              )}
            </div>
          </div>
        )}
      </header>

      {/* Main Content Area */}
      <main className="container py-8">
        {children}
      </main>

      {/* Footer */}
      <footer className={cn(
        "py-6 border-t mt-12",
        "bg-white/50 text-dark-600 border-primary-200",
        "dark:bg-dark-800/50 dark:text-dark-300 dark:border-dark-600"
      )}>
        <div className="container text-center text-sm">
          <p>&copy; {new Date().getFullYear()} Script Market. Todos os direitos reservados.</p>
          <p className="mt-1">Desenvolvido com ❤️ em Angola.</p>
        </div>
      </footer>

      {/* Sheets */}
      <CartSheet open={showCartSheet} onOpenChange={setShowCartSheet} />
      <AccountSheet open={showAccountSheet} onOpenChange={setShowAccountSheet} />
      <LoginSheet open={showLoginSheet} onOpenChange={setShowLoginSheet} />
    </div>
  );
};

export default Layout;