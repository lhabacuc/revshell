import React, { useEffect, useState } from 'react';
import { XCircle, ShoppingCart, Loader2 } from 'lucide-react';
import { getUserCart, removeFromCart } from '../services/cart';
import { checkout } from '../services/purchases';
import { useAuth } from '../contexts/AuthContext';
import type { Script } from '../types';

interface CartSheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const CartSheet: React.FC<CartSheetProps> = ({ open, onOpenChange }) => {
  const { currentUser } = useAuth();
  const [cart, setCart] = useState<Script[]>([]);
  const [loading, setLoading] = useState(false);
  const [checkoutLoading, setCheckoutLoading] = useState(false);

  // Load cart when sheet opens
  useEffect(() => {
    const loadCart = async () => {
      if (open && currentUser) {
        try {
          setLoading(true);
          const userCart = await getUserCart(currentUser.id);
          setCart(userCart);
        } catch (err) {
          console.error('Error loading cart:', err);
        } finally {
          setLoading(false);
        }
      }
    };

    loadCart();
  }, [open, currentUser]);

  // Handle remove from cart
  const handleRemoveFromCart = async (scriptId: string) => {
    if (!currentUser) return;

    try {
      await removeFromCart(currentUser.id, scriptId);
      setCart(cart.filter(item => item.id !== scriptId));
    } catch (err) {
      console.error('Error removing from cart:', err);
    }
  };

  // Calculate cart total
  const calculateTotal = () => {
    return cart.reduce((total, item) => total + item.price, 0);
  };

  // Handle checkout
  const handleCheckout = async () => {
    if (!currentUser || cart.length === 0) return;

    try {
      setCheckoutLoading(true);
      await checkout(currentUser.id);
      setCart([]);
      alert('Compra realizada com sucesso!');
      onOpenChange(false);
    } catch (err) {
      console.error('Error during checkout:', err);
      alert('Erro ao finalizar compra. Por favor, tente novamente.');
    } finally {
      setCheckoutLoading(false);
    }
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm">
      <div className="fixed right-0 top-0 h-full w-full max-w-sm bg-white dark:bg-blue-900 shadow-lg">
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="p-4 border-b dark:border-blue-800 flex items-center justify-between">
            <div>
              <h2 className="text-lg font-semibold">Seu Carrinho</h2>
              <p className="text-sm text-gray-600 dark:text-blue-300">Revise os itens antes de finalizar.</p>
            </div>
            <button 
              onClick={() => onOpenChange(false)}
              className="text-gray-400 hover:text-gray-600 dark:text-blue-400 dark:hover:text-blue-200"
            >
              <XCircle className="h-6 w-6" />
            </button>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-auto p-4">
            {loading ? (
              <div className="flex items-center justify-center h-40">
                <Loader2 className="h-8 w-8 animate-spin text-blue-600 dark:text-blue-400" />
              </div>
            ) : cart.length === 0 ? (
              <div className="flex flex-col items-center justify-center text-center h-40">
                <ShoppingCart className="h-12 w-12 text-gray-300 dark:text-blue-700 mb-4" />
                <p className="text-gray-600 dark:text-blue-300">Seu carrinho está vazio.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {cart.map(item => (
                  <div 
                    key={item.id}
                    className="flex items-center justify-between p-3 rounded-lg bg-gray-50 dark:bg-blue-800"
                  >
                    <div>
                      <h3 className="font-medium">{item.title}</h3>
                      <p className="text-sm text-gray-600 dark:text-blue-300">
                        ${item.price.toFixed(2)}
                      </p>
                    </div>
                    <button
                      onClick={() => handleRemoveFromCart(item.id)}
                      className="text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300"
                    >
                      <XCircle className="h-5 w-5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="p-4 border-t dark:border-blue-800">
            {cart.length > 0 && (
              <div className="font-bold text-lg mb-4">
                Total: ${calculateTotal().toFixed(2)}
              </div>
            )}
            <button
              onClick={handleCheckout}
              disabled={cart.length === 0 || checkoutLoading}
              className="w-full py-2 rounded-md bg-blue-600 hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600 text-white font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
            >
              {checkoutLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Finalizando...
                </>
              ) : (
                "Finalizar Compra"
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CartSheet;