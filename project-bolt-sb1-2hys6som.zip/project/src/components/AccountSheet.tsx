import React, { useState, useEffect } from 'react';
import { XCircle, User, LogOut, File } from 'lucide-react';
import { logOut, updateUserProfile } from '../services/auth';
import { getUserPurchases } from '../services/purchases';
import { useAuth } from '../contexts/AuthContext';
import type { Script } from '../types';

interface AccountSheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const AccountSheet: React.FC<AccountSheetProps> = ({ open, onOpenChange }) => {
  const { currentUser, refreshUserProfile } = useAuth();
  const [activeTab, setActiveTab] = useState('profile');
  const [purchases, setPurchases] = useState<Script[]>([]);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: ''
  });

  // Initialize form data when user changes
  useEffect(() => {
    if (currentUser) {
      setFormData({
        name: currentUser.name,
        email: currentUser.email,
        phone: currentUser.phone
      });
    }
  }, [currentUser]);

  // Load purchases when tab changes
  useEffect(() => {
    const loadPurchases = async () => {
      if (currentUser && activeTab === 'purchases') {
        try {
          setLoading(true);
          const userPurchases = await getUserPurchases(currentUser.id);
          setPurchases(userPurchases);
        } catch (err) {
          console.error('Error loading purchases:', err);
        } finally {
          setLoading(false);
        }
      }
    };

    loadPurchases();
  }, [activeTab, currentUser]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleProfileUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    try {
      setLoading(true);
      await updateUserProfile(currentUser.id, {
        name: formData.name,
        phone: formData.phone
      });
      await refreshUserProfile();
      alert('Perfil atualizado com sucesso!');
    } catch (err) {
      console.error('Error updating profile:', err);
      alert('Erro ao atualizar perfil. Por favor, tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await logOut();
      onOpenChange(false);
    } catch (err) {
      console.error('Error logging out:', err);
    }
  };

  if (!open || !currentUser) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm">
      <div className="fixed right-0 top-0 h-full w-full max-w-md bg-white dark:bg-blue-900 shadow-lg">
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="p-4 border-b dark:border-blue-800 flex items-center justify-between">
            <div>
              <h2 className="text-lg font-semibold">Minha Conta</h2>
              <p className="text-sm text-gray-600 dark:text-blue-300">
                Bem-vindo, {currentUser.name}!
              </p>
            </div>
            <button 
              onClick={() => onOpenChange(false)}
              className="text-gray-400 hover:text-gray-600 dark:text-blue-400 dark:hover:text-blue-200"
            >
              <XCircle className="h-6 w-6" />
            </button>
          </div>

          {/* Tabs */}
          <div className="border-b dark:border-blue-800">
            <div className="flex">
              <button
                className={`px-4 py-2 font-medium text-sm ${
                  activeTab === 'profile'
                    ? 'border-b-2 border-blue-600 dark:border-blue-400 text-blue-600 dark:text-blue-400'
                    : 'text-gray-600 dark:text-blue-300'
                }`}
                onClick={() => setActiveTab('profile')}
              >
                Perfil
              </button>
              <button
                className={`px-4 py-2 font-medium text-sm ${
                  activeTab === 'purchases'
                    ? 'border-b-2 border-blue-600 dark:border-blue-400 text-blue-600 dark:text-blue-400'
                    : 'text-gray-600 dark:text-blue-300'
                }`}
                onClick={() => setActiveTab('purchases')}
              >
                Compras
              </button>
            </div>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-auto p-4">
            {activeTab === 'profile' ? (
              <form onSubmit={handleProfileUpdate} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Nome</label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border rounded-md dark:bg-blue-800 dark:border-blue-700 dark:text-blue-50"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Email</label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    disabled
                    className="w-full px-3 py-2 border rounded-md bg-gray-100 dark:bg-blue-800/50 dark:border-blue-700 dark:text-blue-200 cursor-not-allowed"
                  />
                  <p className="text-xs text-gray-500 dark:text-blue-400 mt-1">
                    O email não pode ser alterado
                  </p>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Telefone</label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border rounded-md dark:bg-blue-800 dark:border-blue-700 dark:text-blue-50"
                  />
                </div>
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-2 rounded-md bg-blue-600 hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600 text-white font-medium disabled:opacity-50"
                >
                  {loading ? 'Atualizando...' : 'Atualizar Perfil'}
                </button>
              </form>
            ) : (
              <div>
                <h3 className="text-lg font-semibold mb-4">Minhas Compras</h3>
                {loading ? (
                  <div className="flex items-center justify-center h-40">
                    <div className="animate-spin h-8 w-8 border-4 border-blue-600 dark:border-blue-400 rounded-full border-t-transparent"></div>
                  </div>
                ) : purchases.length === 0 ? (
                  <div className="text-center py-8">
                    <p className="text-gray-600 dark:text-blue-300">
                      Você ainda não fez nenhuma compra.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {purchases.map(script => (
                      <div 
                        key={script.id}
                        className="p-4 rounded-lg bg-gray-50 dark:bg-blue-800"
                      >
                        <h4 className="font-medium text-lg">{script.title}</h4>
                        <p className="text-sm text-gray-600 dark:text-blue-300 mb-3">
                          Preço: ${script.price.toFixed(2)}
                        </p>
                        <a
                          href={script.file}
                          download
                          className="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 flex items-center"
                        >
                          <File className="mr-1 h-4 w-4" />
                          Baixar Script
                        </a>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="p-4 border-t dark:border-blue-800">
            <button
              onClick={handleLogout}
              className="w-full py-2 rounded-md border border-gray-300 dark:border-blue-700 text-gray-700 dark:text-blue-300 font-medium hover:bg-gray-100 dark:hover:bg-blue-800 flex items-center justify-center"
            >
              <LogOut className="mr-2 h-4 w-4" />
              Sair
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AccountSheet;