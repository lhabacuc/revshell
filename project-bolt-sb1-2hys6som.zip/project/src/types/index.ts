// Type definitions for the application

export interface Script {
  id: string;
  title: string;
  description: string;
  price: number;
  file: string;
  image: string;
  tags: string[];
  createdAt: Date;
  userId: string; // ID of the user who uploaded the script
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  isAdmin: boolean;
  createdAt: Date;
}

export interface CartItem {
  id: string;
  scriptId: string;
  userId: string;
  addedAt: Date;
}

export interface Purchase {
  id: string;
  scriptId: string;
  userId: string;
  purchasedAt: Date;
  price: number;
}

export interface AdminRules {
  id: string;
  content: string;
  updatedAt: Date;
}

export interface DownloadKey {
  id: string;
  key: string;
  createdAt: Date;
  isActive: boolean;
}