import React from 'react';
import { ThemeProvider } from './contexts/ThemeContext';
import { AuthProvider } from './contexts/AuthContext';
import Layout from './components/Layout';
import Scripts from './components/Scripts';
import AdminPanel from './components/AdminPanel';
import { useAuth } from './contexts/AuthContext';

const AppContent: React.FC = () => {
  const { currentUser, loading } = useAuth();
  
  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-blue-950 flex items-center justify-center">
        <div className="animate-spin h-8 w-8 border-4 border-blue-600 dark:border-blue-400 rounded-full border-t-transparent"></div>
      </div>
    );
  }
  
  return (
    <Layout>
      {currentUser?.isAdmin ? <AdminPanel /> : <Scripts />}
    </Layout>
  );
};

function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;