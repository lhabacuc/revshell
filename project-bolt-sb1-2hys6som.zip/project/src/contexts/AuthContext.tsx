import React, { createContext, useState, useEffect, useContext, useMemo } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import { auth } from '../lib/firebase';
import { getCurrentUserProfile } from '../services/auth';
import type { User } from '../types';

// Define the context shape
interface AuthContextType {
  currentUser: User | null;
  loading: boolean;
  error: string | null;
  refreshUserProfile: () => Promise<void>;
}

// Create the context
const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Provider component
export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Refresh the user profile data
  const refreshUserProfile = async () => {
    try {
      if (auth.currentUser) {
        const userProfile = await getCurrentUserProfile();
        setCurrentUser(userProfile);
      }
    } catch (err) {
      setError('Error fetching user profile');
      console.error('Error in refreshUserProfile:', err);
    }
  };

  // Listen for auth state changes
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setLoading(true);
      try {
        if (user) {
          const userProfile = await getCurrentUserProfile();
          setCurrentUser(userProfile);
        } else {
          setCurrentUser(null);
        }
      } catch (err) {
        setError('Error during authentication');
        console.error('Auth state change error:', err);
      } finally {
        setLoading(false);
      }
    });

    // Cleanup subscription
    return () => unsubscribe();
  }, []);

  const value = useMemo(
    () => ({
      currentUser,
      loading,
      error,
      refreshUserProfile
    }),
    [currentUser, loading, error]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

// Custom hook to use the auth context
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};