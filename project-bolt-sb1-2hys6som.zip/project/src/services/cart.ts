import {
  collection,
  doc,
  addDoc,
  getDocs,
  deleteDoc,
  query,
  where,
  serverTimestamp
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { getScriptById } from './scripts';
import type { CartItem, Script } from '../types';

// Add an item to the cart
export const addToCart = async (userId: string, scriptId: string): Promise<string> => {
  try {
    // Check if item already exists in cart
    const cartQuery = query(
      collection(db, 'carts'),
      where('userId', '==', userId),
      where('scriptId', '==', scriptId)
    );
    const existingCart = await getDocs(cartQuery);
    
    if (!existingCart.empty) {
      return existingCart.docs[0].id; // Item already in cart
    }
    
    // Add to cart
    const cartRef = await addDoc(collection(db, 'carts'), {
      userId,
      scriptId,
      addedAt: serverTimestamp()
    });
    
    return cartRef.id;
  } catch (error) {
    console.error('Error adding to cart:', error);
    throw new Error('Failed to add item to cart');
  }
};

// Get all items in a user's cart with their script details
export const getUserCart = async (userId: string): Promise<Script[]> => {
  try {
    const cartQuery = query(
      collection(db, 'carts'),
      where('userId', '==', userId)
    );
    const cartSnapshot = await getDocs(cartQuery);
    
    // No items in cart
    if (cartSnapshot.empty) {
      return [];
    }
    
    // Get all script details for cart items
    const cartItems = await Promise.all(
      cartSnapshot.docs.map(async (doc) => {
        const cartData = doc.data() as CartItem;
        try {
          const script = await getScriptById(cartData.scriptId);
          return script;
        } catch (error) {
          console.error(`Error fetching script ${cartData.scriptId}:`, error);
          return null;
        }
      })
    );
    
    // Filter out any null scripts (in case a script was deleted)
    return cartItems.filter((item): item is Script => item !== null);
  } catch (error) {
    console.error('Error getting cart:', error);
    throw new Error('Failed to fetch cart items');
  }
};

// Remove an item from the cart
export const removeFromCart = async (userId: string, scriptId: string): Promise<void> => {
  try {
    const cartQuery = query(
      collection(db, 'carts'),
      where('userId', '==', userId),
      where('scriptId', '==', scriptId)
    );
    const cartSnapshot = await getDocs(cartQuery);
    
    if (!cartSnapshot.empty) {
      await deleteDoc(doc(db, 'carts', cartSnapshot.docs[0].id));
    }
  } catch (error) {
    console.error('Error removing from cart:', error);
    throw new Error('Failed to remove item from cart');
  }
};

// Clear all items from a user's cart
export const clearCart = async (userId: string): Promise<void> => {
  try {
    const cartQuery = query(
      collection(db, 'carts'),
      where('userId', '==', userId)
    );
    const cartSnapshot = await getDocs(cartQuery);
    
    const deletePromises = cartSnapshot.docs.map(doc => deleteDoc(doc.ref));
    await Promise.all(deletePromises);
  } catch (error) {
    console.error('Error clearing cart:', error);
    throw new Error('Failed to clear cart');
  }
};