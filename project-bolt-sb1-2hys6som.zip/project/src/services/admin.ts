import {
  doc,
  getDoc,
  setDoc,
  updateDoc,
  serverTimestamp
} from 'firebase/firestore';
import { db } from '../lib/firebase';

// Get admin rules
export const getAdminRules = async (): Promise<string> => {
  try {
    const rulesDoc = await getDoc(doc(db, 'admin', 'rules'));
    
    if (rulesDoc.exists()) {
      return rulesDoc.data().content || '';
    } else {
      // Default rules if document doesn't exist
      const defaultRules = "1. Não é permitido o upload de scripts que violem direitos autorais.\n2. Os administradores devem revisar os scripts antes da publicação.\n3. É proibido divulgar informações confidenciais dos usuários.\n4. Os preços dos scripts devem ser definidos de forma justa.\n5. Qualquer violação destas regras pode resultar na suspensão da conta.";
      
      // Create the document with default rules
      await setDoc(doc(db, 'admin', 'rules'), {
        content: defaultRules,
        updatedAt: serverTimestamp()
      });
      
      return defaultRules;
    }
  } catch (error) {
    console.error('Error getting admin rules:', error);
    throw error;
  }
};

// Update admin rules
export const updateAdminRules = async (content: string): Promise<void> => {
  try {
    await updateDoc(doc(db, 'admin', 'rules'), {
      content,
      updatedAt: serverTimestamp()
    });
  } catch (error) {
    console.error('Error updating admin rules:', error);
    throw error;
  }
};

// Get download key
export const getDownloadKey = async (): Promise<string> => {
  try {
    const keyDoc = await getDoc(doc(db, 'admin', 'downloadKey'));
    
    if (keyDoc.exists()) {
      return keyDoc.data().key || '';
    } else {
      // Generate default key if document doesn't exist
      const defaultKey = `CHAVE-${Math.random().toString(36).substring(2, 10).toUpperCase()}`;
      
      // Create the document with default key
      await setDoc(doc(db, 'admin', 'downloadKey'), {
        key: defaultKey,
        isActive: true,
        createdAt: serverTimestamp()
      });
      
      return defaultKey;
    }
  } catch (error) {
    console.error('Error getting download key:', error);
    throw error;
  }
};

// Generate new download key
export const generateDownloadKey = async (): Promise<string> => {
  try {
    const newKey = `CHAVE-${Math.random().toString(36).substring(2, 10).toUpperCase()}`;
    
    await updateDoc(doc(db, 'admin', 'downloadKey'), {
      key: newKey,
      isActive: true,
      createdAt: serverTimestamp()
    });
    
    return newKey;
  } catch (error) {
    console.error('Error generating download key:', error);
    throw error;
  }
};

// Check if a user is an admin
export const isUserAdmin = async (userId: string): Promise<boolean> => {
  try {
    const userDoc = await getDoc(doc(db, 'users', userId));
    
    if (userDoc.exists()) {
      return userDoc.data().isAdmin === true;
    }
    
    return false;
  } catch (error) {
    console.error('Error checking admin status:', error);
    throw error;
  }
};