import {
  collection,
  doc,
  addDoc,
  getDocs,
  query,
  where,
  serverTimestamp
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { getUserCart, clearCart } from './cart';
import { getScriptById } from './scripts';
import type { Script, Purchase } from '../types';

// Process checkout to create purchases
export const checkout = async (userId: string): Promise<string[]> => {
  try {
    // Get all cart items
    const cartItems = await getUserCart(userId);
    
    if (cartItems.length === 0) {
      throw new Error('Cart is empty');
    }
    
    // Add each item to purchases
    const purchasePromises = cartItems.map(async (script) => {
      const purchaseRef = await addDoc(collection(db, 'purchases'), {
        userId,
        scriptId: script.id,
        price: script.price,
        purchasedAt: serverTimestamp()
      });
      
      return purchaseRef.id;
    });
    
    const purchaseIds = await Promise.all(purchasePromises);
    
    // Clear the cart after successful purchase
    await clearCart(userId);
    
    return purchaseIds;
  } catch (error) {
    console.error('Error during checkout:', error);
    throw error;
  }
};

// Get all user purchases with script details
export const getUserPurchases = async (userId: string): Promise<Script[]> => {
  try {
    const purchaseQuery = query(
      collection(db, 'purchases'),
      where('userId', '==', userId)
    );
    const purchaseSnapshot = await getDocs(purchaseQuery);
    
    // No purchases
    if (purchaseSnapshot.empty) {
      return [];
    }
    
    // Get script details for each purchase
    const purchasePromises = purchaseSnapshot.docs.map(async (doc) => {
      const purchaseData = doc.data() as Purchase;
      const script = await getScriptById(purchaseData.scriptId);
      return script;
    });
    
    const purchases = await Promise.all(purchasePromises);
    
    // Filter out any null scripts (in case a script was deleted)
    return purchases.filter(item => item !== null) as Script[];
  } catch (error) {
    console.error('Error getting purchases:', error);
    throw error;
  }
};