import {
  collection,
  doc,
  addDoc,
  getDoc,
  getDocs,
  updateDoc,
  deleteDoc,
  query,
  orderBy,
  serverTimestamp,
  where
} from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL, deleteObject } from 'firebase/storage';
import { db, storage } from '../lib/firebase';
import type { Script } from '../types';

// Get all scripts
export const getAllScripts = async (): Promise<Script[]> => {
  try {
    const scriptsQuery = query(collection(db, 'scripts'), orderBy('createdAt', 'desc'));
    const querySnapshot = await getDocs(scriptsQuery);
    
    return querySnapshot.docs.map(doc => {
      const data = doc.data();
      return {
        id: doc.id,
        title: data.title,
        description: data.description,
        price: data.price,
        file: data.file,
        image: data.image,
        tags: data.tags,
        createdAt: data.createdAt?.toDate() || new Date(),
        userId: data.userId
      };
    });
  } catch (error) {
    console.error('Error getting scripts:', error);
    throw error;
  }
};

// Get a single script by ID
export const getScriptById = async (scriptId: string): Promise<Script | null> => {
  try {
    const scriptDoc = await getDoc(doc(db, 'scripts', scriptId));
    
    if (scriptDoc.exists()) {
      const data = scriptDoc.data();
      return {
        id: scriptDoc.id,
        title: data.title,
        description: data.description,
        price: data.price,
        file: data.file,
        image: data.image,
        tags: data.tags,
        createdAt: data.createdAt?.toDate() || new Date(),
        userId: data.userId
      };
    }
    
    return null;
  } catch (error) {
    console.error('Error getting script:', error);
    throw error;
  }
};

// Add a new script
export const addScript = async (
  scriptData: Omit<Script, 'id' | 'file' | 'image' | 'createdAt'>,
  scriptFile?: File,
  imageFile?: File
): Promise<Script> => {
  try {
    let fileUrl = '';
    let imageUrl = '';
    
    // Upload script file if provided
    if (scriptFile) {
      const fileRef = ref(storage, `scripts/${Date.now()}_${scriptFile.name}`);
      await uploadBytes(fileRef, scriptFile);
      fileUrl = await getDownloadURL(fileRef);
    }
    
    // Upload image if provided
    if (imageFile) {
      const imageRef = ref(storage, `images/${Date.now()}_${imageFile.name}`);
      await uploadBytes(imageRef, imageFile);
      imageUrl = await getDownloadURL(imageRef);
    } else {
      // Default placeholder image
      imageUrl = `https://placehold.co/400x200/7E8EFF/31343C?text=${encodeURIComponent(scriptData.title)}`;
    }
    
    // Create script document in Firestore
    const docRef = await addDoc(collection(db, 'scripts'), {
      ...scriptData,
      file: fileUrl,
      image: imageUrl,
      createdAt: serverTimestamp()
    });
    
    return {
      id: docRef.id,
      ...scriptData,
      file: fileUrl,
      image: imageUrl,
      createdAt: new Date()
    };
  } catch (error) {
    console.error('Error adding script:', error);
    throw error;
  }
};

// Update a script
export const updateScript = async (
  scriptId: string,
  scriptData: Partial<Omit<Script, 'id' | 'createdAt'>>,
  scriptFile?: File,
  imageFile?: File
): Promise<void> => {
  try {
    const updateData: any = { ...scriptData };
    const scriptRef = doc(db, 'scripts', scriptId);
    
    // Get current script data for file/image reference
    const currentScript = await getScriptById(scriptId);
    
    // Upload new script file if provided
    if (scriptFile) {
      // Delete old file if it exists
      if (currentScript?.file && currentScript.file.startsWith('https://firebasestorage.googleapis.com')) {
        try {
          const oldFileRef = ref(storage, currentScript.file);
          await deleteObject(oldFileRef);
        } catch (error) {
          console.warn('Error deleting old file, may not exist:', error);
        }
      }
      
      const fileRef = ref(storage, `scripts/${Date.now()}_${scriptFile.name}`);
      await uploadBytes(fileRef, scriptFile);
      updateData.file = await getDownloadURL(fileRef);
    }
    
    // Upload new image if provided
    if (imageFile) {
      // Delete old image if it exists
      if (currentScript?.image && currentScript.image.startsWith('https://firebasestorage.googleapis.com')) {
        try {
          const oldImageRef = ref(storage, currentScript.image);
          await deleteObject(oldImageRef);
        } catch (error) {
          console.warn('Error deleting old image, may not exist:', error);
        }
      }
      
      const imageRef = ref(storage, `images/${Date.now()}_${imageFile.name}`);
      await uploadBytes(imageRef, imageFile);
      updateData.image = await getDownloadURL(imageRef);
    }
    
    // Update script in Firestore
    await updateDoc(scriptRef, updateData);
  } catch (error) {
    console.error('Error updating script:', error);
    throw error;
  }
};

// Delete a script
export const deleteScript = async (scriptId: string): Promise<void> => {
  try {
    // Get script data to delete files
    const script = await getScriptById(scriptId);
    
    if (script) {
      // Delete script file if it exists
      if (script.file && script.file.startsWith('https://firebasestorage.googleapis.com')) {
        try {
          const fileRef = ref(storage, script.file);
          await deleteObject(fileRef);
        } catch (error) {
          console.warn('Error deleting file, may not exist:', error);
        }
      }
      
      // Delete image if it exists
      if (script.image && script.image.startsWith('https://firebasestorage.googleapis.com')) {
        try {
          const imageRef = ref(storage, script.image);
          await deleteObject(imageRef);
        } catch (error) {
          console.warn('Error deleting image, may not exist:', error);
        }
      }
    }
    
    // Delete script document
    await deleteDoc(doc(db, 'scripts', scriptId));
  } catch (error) {
    console.error('Error deleting script:', error);
    throw error;
  }
};