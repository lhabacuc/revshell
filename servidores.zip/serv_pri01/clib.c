#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080

int	main(void)
{
	int					sock;
	struct sockaddr_in	server_address;
	char				buffer[1024] = {0};
	const char			*message = "Olá, servidor!";

	sock = socket(AF_INET, SOCK_STREAM, 0);
	if (sock < 0)
	{
		perror("Falha ao criar socket");
		exit(EXIT_FAILURE);
	}
	server_address.sin_family = AF_INET;
	server_address.sin_port = htons(PORT);
	if (inet_pton(AF_INET, "11.10.9.10", &server_address.sin_addr) <= 0)
	{
		perror("Endereço inválido ou não suportado");
		close(sock);
		exit(EXIT_FAILURE);
	}

	if (connect(sock, (struct sockaddr *)&server_address, sizeof(server_address)) < 0)
	{
		perror("Falha na conexão");
		close(sock);
		exit(EXIT_FAILURE);
	}

	send(sock, message, strlen(message), 0);
	printf("Mensagem enviada ao servidor: %s\n", message);

	int	valread;

	valread = read(sock, buffer, 1024);
	printf("Resposta do servidor: %s\n", buffer);
	close(sock);
	return (0);
}

/*
void	send_command(const char *command,const char *ip)
{
	int sock = 0;
	struct sockaddr_in serv_addr;
	char buffer[1024] = {0};

	if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		printf("Socket creation error\n");
		return;
	}

	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(PORT);

	if (inet_pton(AF_INET, ip, &serv_addr.sin_addr) <= 0)
	{
		printf("Invalid address/ Address not supported\n");
		return;
	}

	if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0)
	{
		printf("Connection Failed\n");
		return;
	}
	send(sock, command, strlen(command), 0);
	//printf("Command sent: %s\n", command);
	//read(sock, buffer, sizeof(buffer));
	//printf("Server response: %s\n", buffer);
	close(sock);
}

int	main(int ac, char **av)
{
	char c[1024];

	if (ac > 1)
	{
		while (1)
		{
			write(1, "\033[H\033[J", 7);
			printf("Enter MSM : ");
			if (fgets(c, 1024, stdin) == NULL)
				break;
			c[strcspn(c, "\n")] = '\0';
			if (ac == 3)
				send_command(c, av[1]);
			else
				send_command(c, "10.11.10.10");
		}
	}
	return (0);
}
*/
