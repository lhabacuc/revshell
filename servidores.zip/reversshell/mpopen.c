#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>

char	*my_popen(const char *cmd)
{
	int		fd[2];
	pid_t	pid;
	char	*shell;
	char	*argv[4];
	char	buffer[1024];
	char	*result;
	int		nbytes;
	int		total;
	int		status;

	shell = "/bin/zsh"; // ou "/bin/bash"
	if (pipe(fd) == -1)
		return (NULL);
	pid = fork();
	if (pid == -1)
		return (NULL);
	if (pid == 0)
	{
		close(fd[0]);
		dup2(fd[1], STDOUT_FILENO);
		dup2(fd[1], STDERR_FILENO);
		close(fd[1]);

		argv[0] = shell;
		argv[1] = "-c";
		argv[2] = (char *)cmd;
		argv[3] = NULL;
		execve(shell, argv, environ);
		exit(1);
	}
	close(fd[1]);
	total = 0;
	result = malloc(1);
	if (!result)
		return (NULL);
	result[0] = '\0';
	nbytes = read(fd[0], buffer, sizeof(buffer) - 1);
	while (nbytes > 0)
	{
		buffer[nbytes] = '\0';
		result = realloc(result, total + nbytes + 1);
		if (!result)
			return (NULL);
		memcpy(result + total, buffer, nbytes + 1);
		total += nbytes;
		nbytes = read(fd[0], buffer, sizeof(buffer) - 1);
	}
	close(fd[0]);
	waitpid(pid, &status, 0);
	return (result);
}

