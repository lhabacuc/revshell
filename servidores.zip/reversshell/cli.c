#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
# include <readline/readline.h>
# include <readline/history.h>

#define PORT 9970
#define input_SIZE 2048

int	main(int AC, char *av[])
{
	int	bytes_read;
	int	sock;
	char	response[input_SIZE];
	struct	sockaddr_in server_addr;
	char	*input;

	if (AC != 2)
	{
		printf("Uso: %s <IP do servidor>\n", av[0]);
		return 1;
	}

	sock = socket(AF_INET, SOCK_STREAM, 0);
	if (sock < 0)
	{
		perror("Erro ao criar socket");
		return 1;
	}

	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(PORT);
	inet_pton(AF_INET, av[1], &server_addr.sin_addr);

	if (connect(sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0)
	{
		perror("Erro ao conectar");
		return 1;
	}

	while (1)
	{
		input = readline("[#][6532][&]>> ");
		if (!input)
			break ;
		if (strcmp(input, "") == 0)
			continue ;
		if (strcmp(input, "clear") == 0)
		{
			system("clear");
			continue ;
		}
		if (strcmp(input, "exit") == 0)
			break ;

		write(sock, input, strlen(input));

		memset(response, 0, sizeof(response));
		bytes_read = read(sock, response, sizeof(response) - 1);
		printf("%s", response);
	}
	close(sock);
	return 0;
}

