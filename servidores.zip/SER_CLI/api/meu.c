#include <stdio.h>
#include <math.h>

double	calcular_area_circulo(double raio)
{
	return (M_PI * raio * raio);
}

double	calcular_area_quadrado(double lado)
{
	return (lado * lado);
}

double	calcular_area_retangulo(double largura, double altura)
{
	return (largura * altura);
}

int	main(void)
{
	double	raio = 5.0;
	double	lado = 4.0;
	double	largura = 7.0;
	double	altura = 3.0;

	printf("Área do círculo: %.2f\n", calcular_area_circulo(raio));
	printf("Área do quadrado: %.2f\n", calcular_area_quadrado(lado));
	printf("Área do retângulo: %.2f\n", calcular_area_retangulo(largura, altura));

	return (0);
}

