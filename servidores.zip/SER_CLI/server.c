#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netinet/in.h>

#include "ft_split.c"

#define PORT 8080
#define BUFFER_SIZE 1024
#define NUM_BAD_COMMANDS 102
#define MSG_FILE "msg.db"

void	handle_status(int client_socket);
void	handle_upt(int client_socket, const char *filename, const char *username)
{
	char buffer[BUFFER_SIZE];
	int bytes_read;
	FILE *fp;

	fp = fopen(filename, "wb");
	if (fp == NULL)
	{
		char *response = "HTTP/1.1 500 Internal Server Error\r\n\r\nErro ao criar o arquivo no servidor.\n";
		write(client_socket, response, strlen(response));
		return;
	}

	while ((bytes_read = read(client_socket, buffer, BUFFER_SIZE)) > 0)
	{
		fwrite(buffer, 1, bytes_read, fp);
		if (bytes_read < BUFFER_SIZE)
		break;
	}
	fclose(fp);
	char *response = "HTTP/1.1 200 OK\r\n\r\nUpload realizado com sucesso.\n";
	write(client_socket, response, strlen(response));
}


int	is_command_valid(const char *command)
{
	const char	*bad_commands[NUM_BAD_COMMANDS] = {
		"rm", "rm -f", "rm -r", "cat", "shutdown", "reboot", "mkfs", "dd",
		"chmod", "chown", "passwd", "userdel", "groupdel", "rmdir", "kill",
		"pkill", "killall", "halt", "poweroff", "ddrescue", "format",
		"mkfs.ext4", "mkfs.xfs", "mount", "umount", "fsck", "wipe", "tune2fs",
		"e2fsck", "parted", "gparted", "partprobe", "dd if=", "dd of=",
		"pvcreate", "vgcreate", "lvcreate", "vgextend", "lvextend", "vgremove",
		"lvremove", "pvremove", "pvmove", "mdadm", "mkinitramfs",
		"update-initramfs", "update-grub", "grub-install", "grub-mkconfig",
		"systemctl stop", "systemctl restart", "systemctl disable",
		"systemctl enable", "systemctl mask", "systemctl unmask", "service stop",
		"service restart", "service disable", "service enable", "iptables -F",
		"iptables -X", "iptables -t nat -F", "iptables -t mangle -F",
		"iptables -t raw -F", "firewalld-cmd --permanent --add-service=http",
		"firewalld-cmd --permanent --remove-service=http", "firewall-cmd --reload",
		"systemctl disable firewalld", "systemctl stop firewalld",
		"systemctl mask firewalld", "systemctl unmask firewalld", "passwd -d",
		"useradd", "usermod", "groupadd", "groupmod", "usermod -aG", "usermod -L",
		"usermod -U", "crontab -r", "crontab -e", "crontab -l", "shutdown -r now",
		"shutdown -h +5", "shutdown -c", "reboot -f", "reboot -p"
	};
	int			i;

	if (command == NULL)
	{
		fprintf(stderr, "Error: NULL command provided\n");
		return (1);
	}
	i = 0;
	while (i < NUM_BAD_COMMANDS)
	{
		if (bad_commands[i] != NULL && strstr(command, bad_commands[i]) != NULL)
		{
			fprintf(stderr, "Error: Command contains forbidden word '%s'\n", bad_commands[i]);
			return (1);
		}
		i++;
	}
	return (0);
}

void	log_request(struct sockaddr_in *client_addr, const char *method, const char *command, const char *username)
{
	char	client_ip[INET_ADDRSTRLEN];
	inet_ntop(AF_INET, &(client_addr->sin_addr), client_ip, INET_ADDRSTRLEN);
	printf("Cliente %s:%d (%s) requisitou %s %s\n", client_ip,
	ntohs(client_addr->sin_port), username, method, command);
}

void	handle_get(int client_socket, const char *command)
{
	char	output[BUFFER_SIZE];
	FILE	*fp;

	fp = popen(command, "r");
	if (fp == NULL)
	{
		char *response = "HTTP/1.1 500 \r\n\r\nErro ao executar o programa.";
		write(client_socket, response, strlen(response));
	}
	else
	{
		while (fgets(output, sizeof(output), fp) != NULL)
			write(client_socket, output, strlen(output));
		pclose(fp);
	}
}

void	handle_post(int client_socket, const char *data)
{
	char	response[BUFFER_SIZE + 50];
	snprintf(response, sizeof(response), "HTTP/1.1 200 OK\r\nDados recebidos: %s", data);
	write(client_socket, response, strlen(response));
}

void	handle_cmd(int client_socket, const char *command)
{
	char	output[BUFFER_SIZE];
	FILE	*fp;

	fp = popen(command, "r");
	if (fp == NULL)
	{
		char *response = "HTTP/1.1 500 \r\n\r\nErro ao executar o comando.";
		write(client_socket, response, strlen(response));
	}
	else
	{
		while (fgets(output, sizeof(output), fp) != NULL)
			write(client_socket, output, strlen(output));
		pclose(fp);
	}
}

void	handle_msg(int client_socket, const char *username, const char *message)
{
	FILE	*msg_file;
	char	response[BUFFER_SIZE + 50];

	msg_file = fopen(MSG_FILE, "a");
	if (msg_file == NULL)
	{
		char *error_response = "HTTP/1.1 500 \r\n\r\nErro ao gravar mensagem.\n";
		write(client_socket, error_response, strlen(error_response));
		return ;
	}
	if (username && message)
	{
		fprintf(msg_file, "===============================================\n");
		fprintf(msg_file, "-> %s:\n\t\t%s\n", username, message);
		snprintf(response, sizeof(response), "   \n");
	}
	else
	{
		char *error_response = "HTTP/1.1 400 \r\n\r\nUsername ou msg ausente.\n";
		write(client_socket, error_response, strlen(error_response));
		fclose(msg_file);
		return ;
	}
	fclose(msg_file);
	write(client_socket, response, strlen(response));
	handle_status(client_socket);
}

void	handle_status(int client_socket)
{
	FILE	*msg_file;
	char	line[BUFFER_SIZE];
	char	response[BUFFER_SIZE * 10] = "Mensagens:\n";

	msg_file = fopen(MSG_FILE, "r");
	if (msg_file == NULL)
	{
		char *error_response = "HTTP 500 \nErro ao ler mensagens.\n";
		write(client_socket, error_response, strlen(error_response));
		return ;
	}

	while (fgets(line, sizeof(line), msg_file) != NULL)
		strcat(response, line);

	fclose(msg_file);
	write(client_socket, response, strlen(response));
}

void	handle_client(int client_socket, struct sockaddr_in *client_addr)
{
	char	buffer[BUFFER_SIZE];
	int		read_size;
	char	**mt = NULL;
	char	*method = NULL;
	char	*path = NULL;
	char	*data = NULL;
	char	*username = NULL;
	char	*sudo = NULL;

	memset(buffer, 0, BUFFER_SIZE);
	read_size = read(client_socket, buffer, BUFFER_SIZE - 1);
	if (read_size > 0)
	{
		buffer[read_size] = '\0';
		printf("Recebido: %s\n", buffer);

		mt = ft_split(buffer);
		if (mt[0])
			method = mt[0];
		if (mt[1])
			path = mt[1];
		if (mt[2])
			sudo = mt[2];
		if (mt[3])
			username = mt[3];
		if (mt[4])
			data = mt[4];

		if (strcmp(method, "GET") == 0 || strcmp(method, "POST") == 0
		|| strcmp(method, "CMD") == 0 || strcmp(buffer, "DWN") == 0
		|| strcmp(method, "msg") == 0 || strcmp(method, "UPT") == 0)
		{
			if (is_command_valid(path) && (!sudo || strcmp(sudo, "sudosf") != 0))
			{
				char *response = "HTTP 400 Bad Request\r\nforbidden command.\n";
				write(client_socket, response, strlen(response));
				close(client_socket);
				return ;
			}

			log_request(client_addr, method, path, username ? username : "Desconhecido");

			if (strcmp(method, "GET") == 0)
				handle_get(client_socket, path);
			else if (strcmp(method, "POST") == 0)
				handle_post(client_socket, data);
			else if (strcmp(method, "CMD") == 0)
				handle_cmd(client_socket, path);
			else if (strcmp(buffer, "DWN") == 0)
			{
				char filepath[BUFFER_SIZE];
				strcpy(filepath, buffer + 4);

				char *newline = strchr(filepath, '\n');
				if (newline)
					*newline = '\0';

				FILE *fp = fopen(filepath, "rb");
				if (fp == NULL)
				{
					char *response = "Erro ao abrir o arquivo.\n";
					write(client_socket, response, strlen(response));
				}
				else
				{
					char send_buffer[BUFFER_SIZE];
					int bytes_read;

					while ((bytes_read = fread(send_buffer, 1, BUFFER_SIZE, fp)) > 0)
						write(client_socket, send_buffer, bytes_read);
					fclose(fp);
				}
			}
			if (strcmp(method, "UPT") == 0)
			{
				handle_upt(client_socket, path, username);
			}
			else if (strcmp(method, "msg") == 0 && username && data)
			{
				if (strcmp(data, "--status") == 0)
					handle_status(client_socket);
				else
					handle_msg(client_socket, username, data);
			}
		}
		else
		{
			char *response = "HTTP/1.1 400 Bad Request\r\nComando desconhecido.";
			write(client_socket, response, strlen(response));
		}
	}
	else if (read_size == 0)
		printf("Cliente desconectado.\n");
	else
		perror("Erro ao ler do socket");
	close(client_socket);
}

int	main(int argc, char *argv[])
{
	int					server_socket, client_socket;
	struct sockaddr_in	server_addr, client_addr;
	socklen_t			client_addr_len = sizeof(client_addr);

	server_socket = socket(AF_INET, SOCK_STREAM, 0);
	if (server_socket == -1)
	{
		perror("Erro ao criar socket");
		exit(EXIT_FAILURE);
	}

	server_addr.sin_family = AF_INET;
	server_addr.sin_addr.s_addr = INADDR_ANY;
	server_addr.sin_port = htons(PORT);

	if (bind(server_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0)
	{
		perror("Erro ao fazer bind");
		close(server_socket);
		exit(EXIT_FAILURE);
	}

	if (listen(server_socket, 3) < 0)
	{
		perror("Erro ao ouvir no socket");
		close(server_socket);
		exit(EXIT_FAILURE);
	}

	printf("Servidor ouvindo na porta %d...\n", PORT);

	while (1)
	{
		client_socket = accept(server_socket, (struct sockaddr *)&client_addr, &client_addr_len);
		if (client_socket < 0)
		{
			perror("Erro ao aceitar conexão");
			continue ;
		}

		handle_client(client_socket, &client_addr);
	}

	close(server_socket);
	return (0);
}


