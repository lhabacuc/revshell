#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <readline/readline.h>
#include <readline/history.h>
#include <pwd.h>

#define PORT 8080
#define BUFFER_SIZE 1024

typedef struct s_client
{
	char	method[10];
	char	path[BUFFER_SIZE];
	char	*username;
	char	prev[10];
	char	ip[21];
}		t_client;

char	*get_last_word(const char *path)
{
	const char	*last_word;

	if (!path)
		return (NULL);
	last_word = strrchr(path, '/');
	if (last_word)
		return ((char *)(last_word + 1));
	return ((char *)path);
}

void	send_request(t_client *cli, const char *data)
{
	int	client_socket;
	struct sockaddr_in server_addr;
	char	buffer[BUFFER_SIZE];
	char	request[BUFFER_SIZE * 2];

	client_socket = socket(AF_INET, SOCK_STREAM, 0);
	if (client_socket == -1)
	{
		perror("Erro ao criar socket");
		exit(EXIT_FAILURE);
	}

	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(PORT);
	server_addr.sin_addr.s_addr = inet_addr(cli->ip);

	if (connect(client_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) == -1)
	{
		perror("Erro ao conectar");
		close(client_socket);
		exit(EXIT_FAILURE);
	}

	if (strcmp(cli->method, "POST") == 0 || strcmp(cli->method, "msg") == 0 || strcmp(cli->method, "UPT") == 0)
	{
		snprintf(request, sizeof(request), "%s:%s:%s:%s:%s", cli->method,
		cli->path, cli->prev, cli->username, data);
	}
	else
		snprintf(request, sizeof(request), "%s:%s:%s:%s", cli->method, cli->path, cli->prev, cli->username);

	write(client_socket, request, strlen(request));

	if (strcmp(cli->method, "DWN") == 0)
	{
		FILE *fp = fopen(get_last_word(cli->path), "wb");
		if (fp == NULL)
		{
			perror("Erro ao criar arquivo");
			close(client_socket);
			return ;
		}

		int read_size;
		while ((read_size = read(client_socket, buffer, BUFFER_SIZE - 1)) > 0)
			fwrite(buffer, 1, read_size, fp);
		fclose(fp);
		printf("Arquivo baixado com sucesso.\n");
	}
	else if (strcmp(cli->method, "UPT") == 0)
	{
		FILE *fp = fopen(data, "rb");
		if (fp == NULL)
		{
			perror("Erro ao abrir arquivo para upload");
			close(client_socket);
			return ;
		}

		int read_size;
		while ((read_size = fread(buffer, 1, BUFFER_SIZE - 1, fp)) > 0)
			write(client_socket, buffer, read_size);
		fclose(fp);
		printf("Arquivo enviado com sucesso.\n");
	}
	else
	{
		int read_size;
		while ((read_size = read(client_socket, buffer, BUFFER_SIZE - 1)) > 0)
		{
			buffer[read_size] = '\0';
			printf("%s", buffer);
			memset(buffer, 0, BUFFER_SIZE);
		}
	}
	close(client_socket);
}

int	main(void)
{
	t_client	client;
	char		*input;
	struct passwd *pw;
	int			i;

	pw = getpwuid(getuid());
	if (pw)
		client.username = pw->pw_name;
	else
		client.username = "Desconhecido";

	for (i = 0; i < 21; i++)
		client.ip[i] = '\0';

	input = readline("Digite o IP: ");
	strncpy(client.ip, input, sizeof(client.ip) - 1);
	client.ip[sizeof(client.ip) - 1] = '\0';
	if (input == NULL)
		return (0);
	free(input);

	input = readline("Entrar como (sudo / user): ");
	strncpy(client.prev, input, sizeof(client.prev) - 1);
	client.prev[sizeof(client.prev) - 1] = '\0';
	if (input == NULL)
		return (0);
	do
	{
		free(input);
		input = readline("Digite o método (GET, POST, CMD, DWN, msg): ");
		strncpy(client.method, input, sizeof(client.method) - 1);
		client.method[sizeof(client.method) - 1] = '\0';
		if (input == NULL)
		{
			printf("\nSaindo...\n");
			break ;
		}
		free(input);
		while (1)
		{
			if (strcmp(client.method, "GET") != 0 && strcmp(client.method, "POST") != 0 &&
				strcmp(client.method, "CMD") != 0 && strcmp(client.method, "DWN") != 0 &&
				strcmp(client.method, "msg") != 0)
			{
				printf("Método inválido, digite GET, POST, CMD, DWN, msg.\n");
				break ;
			}

			input = readline("Digite o caminho: ");
			strncpy(client.path, input, sizeof(client.path) - 1);
			client.path[sizeof(client.path) - 1] = '\0';
			if (strcmp(input, "exit") == 0)
				break ;
			if (input == NULL)
			{
				printf("\nSaindo...\n");
				break ;
			}
			add_history(input);
			free(input);

			if (strcmp(client.method, "CMD") == 0)
			{
				input = readline("CMD Digite o comando: ");
				if (strcmp(input, "exit") == 0)
					break ;
				if (input == NULL)
				{
					printf("\nSaindo...\n");
					break ;
				}
				send_request(&client, input);
				free(input);
			}
			else if (strcmp(client.method, "UPT") == 0)
			{
				input = readline("UPT Digite o caminho do arquivo para upload: ");
				if (strcmp(input, "exit") == 0)
					break ;
				if (input == NULL)
				{
					printf("\nSaindo...\n");
					break ;
				}
				send_request(&client, input);
				free(input);
			}
			else
				send_request(&client, client.path);
		}
		input = readline("sair (yes, no)>: ");
	}
	while (strcmp(input, "yes") != 0);
	free(input);
	return (0);
}

