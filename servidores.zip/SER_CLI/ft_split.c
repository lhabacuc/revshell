#include <stdio.h>
#include <stdlib.h>

char	**ft_split(char *str)
{
	int		i;
	int		j;
	int		k;
	char	**split;

	i = 0;
	j = 0;
	if (!str)
		return (NULL);
	while (str[i] == ':')
		i++;
	split = malloc(sizeof(char *) * 800);
	while (str[i] != '\0')
	{
		k = 0;
		split[j] = malloc(sizeof(char *) * 1024);
		while (str[i] != ':' && str[i] != '\0')
			split[j][k++] = str[i++];
		split[j][k] = '\0';
		while (str[i] == ':')
			i++;
		j++;
	}
	split[j] = NULL;
	return (split);
}
