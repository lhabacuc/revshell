#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <netinet/in.h>
#include <ifaddrs.h>

#define PORT 8080
/*
void	print_server_ip(void)
{
	struct ifaddrs	*ifaddr;
	struct ifaddrs	*ifa;
	char			ip[INET_ADDRSTRLEN];

	if (getifaddrs(&ifaddr) == -1)
	{
		perror("getifaddrs");
		exit(EXIT_FAILURE);
	}
	printf("Server IPs:\n");
	ifa = ifaddr;
	while (ifa != NULL)
	{
		if (ifa->ifa_addr && ifa->ifa_addr->sa_family == AF_INET)
		{
			struct sockaddr_in *sockaddr = (struct sockaddr_in *)ifa->ifa_addr;
			if (inet_ntop(AF_INET, &(sockaddr->sin_addr), ip, sizeof(ip)))
				printf("-> %s: %s\n", ifa->ifa_name, ip);
		}
		ifa = ifa->ifa_next;
	}
	freeifaddrs(ifaddr);
}

void	handle_client(int client_socket)
{
	int		i = 0;
	char	buffer[1024] = {0};
	char	response[1024];

		

	//write(1, "\033[H\033[J", 7);

	read(client_socket, buffer, sizeof(buffer));
	printf("NEW MSG: %s\n", buffer);

	system(buffer);

	//write(1, "\033[H\033[J", 7);
	printf("Enter MSM : ");
	if (fgets(response, 1024, stdin) == NULL)
		return ;
	response[strcspn(response, "\n")] = '\0';
	send(client_socket, response, strlen(response), 0);
	while (i < 1024)
		buffer[i++] = '\0';
	close(client_socket);
}

int	main(void)
{
	int					server_fd;
	int					new_socket;
	struct sockaddr_in	address;
	int					opt = 1;
	int					addrlen = sizeof(address);

	print_server_ip();

	server_fd = socket(AF_INET, SOCK_STREAM, 0);
	if (server_fd == 0)
	{
		perror("socket failed");
		exit(EXIT_FAILURE);
	}

	// Configura o socket para reutilizar endereço e porta
	if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt)))
	{
		perror("setsockopt");
		exit(EXIT_FAILURE);
	}

	// Configura o endereço do servidor
	address.sin_family = AF_INET;
	address.sin_addr.s_addr = INADDR_ANY;
	address.sin_port = htons(PORT);

	// Vincula o socket ao endereço e porta configurados
	if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0)
	{
		perror("bind failed");
		exit(EXIT_FAILURE);
	}

	// Escuta por conexões
	if (listen(server_fd, 3) < 0)
	{
		perror("listen");
		exit(EXIT_FAILURE);
	}
	printf("Server listening on port %d...\n", PORT);

	// Aceita conexões e trata cada cliente
	while (1)
	{
		new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t *)&addrlen);
		if (new_socket < 0)
		{
			perror("accept");
			exit(EXIT_FAILURE);
		}
		handle_client(new_socket);
	}

	return (0);
}
*/

void	print_server_ip(void)
{
	struct ifaddrs	*ifaddr;
	struct ifaddrs	*ifa;
	char			ip[INET_ADDRSTRLEN];

	if (getifaddrs(&ifaddr) == -1)
		exit(EXIT_FAILURE);
	printf("Server IPs:\n");
	ifa = ifaddr;
	while (ifa != NULL)
	{
		if (ifa->ifa_addr && ifa->ifa_addr->sa_family == AF_INET)
		{
			struct sockaddr_in *sockaddr = (struct sockaddr_in *)ifa->ifa_addr;
			if (inet_ntop(AF_INET, &(sockaddr->sin_addr), ip, sizeof(ip)))
				printf("-> %s: %s\n", ifa->ifa_name, ip);
		}
		ifa = ifa->ifa_next;
	}
	freeifaddrs(ifaddr);
}

void	handle_client(int client_socket)
{
	int		i = 0;
	char	buffer[1024] = {0};

	write(1, "\033[H\033[J", 7);

	read(client_socket, buffer, sizeof(buffer));
	printf("NEW MSG: %s\n", buffer);

	system(buffer);

	while (i < 1024)
		buffer[i++] = '\0';

	close(client_socket);
}

int	main(void)
{
	int					server_fd;
	int					new_socket;
	struct sockaddr_in	address;
	int					opt = 1;
	int					addrlen = sizeof(address);

	print_server_ip();

	server_fd = socket(AF_INET, SOCK_STREAM, 0);
	if (server_fd == 0)
		exit(EXIT_FAILURE);

	if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt)))
		exit(EXIT_FAILURE);

	address.sin_family = AF_INET;
	address.sin_addr.s_addr = INADDR_ANY;
	address.sin_port = htons(PORT);

	if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0)
		exit(EXIT_FAILURE);

	if (listen(server_fd, 3) < 0)
		exit(EXIT_FAILURE);
	printf("MINHA PORTA %d...\n", PORT);

	while (1)
	{
		new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t *)&addrlen);
		if (new_socket < 0)
		{
			perror("accept");
			exit(EXIT_FAILURE);
		}
		handle_client(new_socket);
	}

	return (0);
}


/*
#define PORT 8080

void	print_server_ip(void)
{
	struct ifaddrs	*ifaddr;
	struct ifaddrs	*ifa;
	char			ip[INET_ADDRSTRLEN];

	if (getifaddrs(&ifaddr) == -1)
	{
		perror("getifaddrs");
		exit(EXIT_FAILURE);
	}
	printf("Server IPs:\n");
	ifa = ifaddr;
	while (ifa != NULL)
	{
		if (ifa->ifa_addr && ifa->ifa_addr->sa_family == AF_INET)
		{
			struct sockaddr_in *sockaddr = (struct sockaddr_in *)ifa->ifa_addr;
			if (inet_ntop(AF_INET, &(sockaddr->sin_addr), ip, sizeof(ip)))
				printf("->%s: %s\n", ifa->ifa_name, ip);
		}
		ifa = ifa->ifa_next;
	}
	freeifaddrs(ifaddr);
}

void	handle_client(int client_socket)
{
	int	i = 0;
	char	buffer[1024] = {0};
	write(1, "\033[H\033[J", 7);
	read(client_socket, buffer, sizeof(buffer));
	printf("NEW MSM : %s \n", buffer);
	system(buffer);
	while(i < 1024)
		buffer[i++] = '\0';
	close(client_socket);
}

int	main(void)
{
	int					server_fd;
	int					new_socket;
	struct sockaddr_in	address;
	int					opt = 1;
	int					addrlen = sizeof(address);

	print_server_ip();
	server_fd = socket(AF_INET, SOCK_STREAM, 0);
	if (server_fd == 0)
	{
		perror("socket failed");
		exit(EXIT_FAILURE);
	}
	if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt)))
	{
		perror("setsockopt");
		exit(EXIT_FAILURE);
	}
	address.sin_family = AF_INET;
	address.sin_addr.s_addr = INADDR_ANY;
	address.sin_port = htons(PORT);
	if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0)
	{
		perror("bind failed");
		exit(EXIT_FAILURE);
	}
	if (listen(server_fd, 3) < 0)
	{
		perror("listen");
		exit(EXIT_FAILURE);
	}
	printf("Server listening on port %d...\n", PORT);
	while (1)
	{
		new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t *)&addrlen);
		if (new_socket < 0)
		{
			perror("accept");
			exit(EXIT_FAILURE);
		}
		handle_client(new_socket);
	}
	return (0);
}
*/
