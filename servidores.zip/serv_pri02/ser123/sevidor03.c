#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <pthread.h>

#define PORT 8080
#define BUFFER_SIZE 8192
#define DATA_FILE "./web_root/messages.txt"
#define IMAGE_DIR "./web_root/images"

void	*handle_request(void *client_socket_ptr);
void	send_response(int client_socket, const char *header, const char *body);
void	handle_get_request(int client_socket, const char *path);
void	handle_post_request(const char *body);
void	save_image(const char *image_data, const char *filename);

void	send_response(int client_socket, const char *header, const char *body)
{
	char	response[BUFFER_SIZE];

	snprintf(response, sizeof(response),
		"%s\r\n"
		"Access-Control-Allow-Origin: *\r\n"
		"Access-Control-Allow-Headers: Content-Type\r\n"
		"%s",
		header, body);
	send(client_socket, response, strlen(response), 0);
}

void	handle_get_request(int client_socket, const char *path)
{
	if (strcmp(path, "/") == 0)
		handle_get_index(client_socket);
	else if (strcmp(path, "/styles.css") == 0)
		handle_get_styles(client_socket);
	else if (strcmp(path, "/script.js") == 0)
		handle_get_script(client_socket);
	else if (strstr(path, "/images/") == path)
		handle_get_image(client_socket, path);
	else
		send_response(client_socket,
			"HTTP/1.1 404 Not Found\r\nContent-Type: text/plain\r\n\r\n",
			"404 Not Found");
}

void	handle_get_index(int client_socket)
{
	FILE	*file;
	char	response[BUFFER_SIZE];

	file = fopen("./web_root/index.html", "r");
	if (file != NULL)
	{
		fread(response, 1, sizeof(response), file);
		send_response(client_socket,
			"HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n", response);
		fclose(file);
	}
	else
		send_response(client_socket,
			"HTTP/1.1 404 Not Found\r\nContent-Type: text/plain\r\n\r\n",
			"404 Not Found");
}

void	handle_get_styles(int client_socket)
{
	FILE	*file;
	char	response[BUFFER_SIZE];

	file = fopen("./web_root/styles.css", "r");
	if (file != NULL)
	{
		fread(response, 1, sizeof(response), file);
		send_response(client_socket,
			"HTTP/1.1 200 OK\r\nContent-Type: text/css\r\n\r\n", response);
		fclose(file);
	}
	else
		send_response(client_socket,
			"HTTP/1.1 404 Not Found\r\nContent-Type: text/plain\r\n\r\n",
			"404 Not Found");
}

void	handle_get_script(int client_socket)
{
	FILE	*file;
	char	response[BUFFER_SIZE];

	file = fopen("./web_root/script.js", "r");
	if (file != NULL)
	{
		fread(response, 1, sizeof(response), file);
		send_response(client_socket,
			"HTTP/1.1 200 OK\r\nContent-Type: application/javascript\r\n\r\n", response);
		fclose(file);
	}
	else
		send_response(client_socket,
			"HTTP/1.1 404 Not Found\r\nContent-Type: text/plain\r\n\r\n",
			"404 Not Found");
}

void	handle_get_image(int client_socket, const char *path)
{
	char	full_path[512];
	FILE	*file;
	char	response[BUFFER_SIZE];

	snprintf(full_path, sizeof(full_path), "./web_root%s", path);
	file = fopen(full_path, "rb");
	if (file != NULL)
	{
		fread(response, 1, sizeof(response), file);
		send_response(client_socket,
			"HTTP/1.1 200 OK\r\nContent-Type: image/png\r\n\r\n", response);
		fclose(file);
	}
	else
		send_response(client_socket,
			"HTTP/1.1 404 Not Found\r\nContent-Type: text/plain\r\n\r\n",
			"404 Not Found");
}

void	*handle_request(void *client_socket_ptr)
{
	int		client_socket;
	char	buffer[BUFFER_SIZE];
	char	method[16];
	char	path[256];
	char	protocol[16];
	int		received;

	client_socket = (intptr_t)client_socket_ptr;
	received = recv(client_socket, buffer, sizeof(buffer) - 1, 0);
	if (received < 0)
	{
		perror("Failed to read request");
		close(client_socket);
		pthread_exit(NULL);
	}
	buffer[received] = '\0';
	sscanf(buffer, "%15s %255s %15s", method, path, protocol);
	if (strcmp(method, "GET") == 0)
		handle_get_request(client_socket, path);
	else if (strcmp(method, "POST") == 0 && strcmp(path, "/") == 0)
		handle_post_request(client_socket, buffer);
	else
		send_response(client_socket,
			"HTTP/1.1 404 Not Found\r\nContent-Type: text/plain\r\n\r\n",
			"404 Não Encontrado");
	close(client_socket);
	pthread_exit(NULL);
}

void	handle_post_request(const char *body)
{
	char	*name_start;
	char	*email_start;
	char	*message_start;
	char	*image_start;
	char	name[256];
	char	email[256];
	char	message[8192];
	char	image[8192];
	FILE	*file;

	name_start = strstr(body, "name=");
	email_start = strstr(body, "&email=");
	message_start = strstr(body, "&message=");
	image_start = strstr(body, "&image=");
	if (!name_start || !email_start || !message_start)
		return;
	name_start += 5;
	email_start += 7;
	message_start += 9;
	if (image_start)
	{
		image_start += 7;
		sscanf(image_start, "%8191s", image);
	}
	else
		image[0] = '\0';
	sscanf(name_start, "%255[^&]", name);
	sscanf(email_start, "%255[^&]", email);
	sscanf(message_start, "%8191[^&]", message);

	file = fopen(DATA_FILE, "a");
	if (file == NULL)
	{
		perror("Failed to open file");
		return;
	}
	save_post_data(file, name, email, message, image);
	fclose(file);
}

void	save_post_data(FILE *file, const char *name, const char *email,
		const char *message, const char *image)
{
	char	image_filename[512];

	if (strlen(image) > 0)
	{
		snprintf(image_filename, sizeof(image_filename), "%s/%s.png",
			IMAGE_DIR, email);
		save_image(image, image_filename);
		fprintf(file,
			"{\"name\":\"%s\", \"email\":\"%s\", \"message\":\"%s\", \"image\":\"%s\"},\n",
			name, email, message, image_filename);
	}
	else
		fprintf(file,
			"{\"name\":\"%s\", \"email\":\"%s\", \"message\":\"%s\", \"image\":\"N/A\"},\n",
			name, email, message);
}

void	save_image(const char *image_data, const char *filename)
{
	FILE	*file;

	file = fopen(filename, "wb");
	if (file == NULL)
	{
		perror("Failed to save image");
		return;
	}
	fwrite(image_data, 1, strlen(image_data), file);
	fclose(file);
}

