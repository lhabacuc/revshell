#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <pthread.h>

#define PORT 8080
#define BUFFER_SIZE 8192
#define DATA_FILE "./web_root/messages.txt"

void	*handle_request(void *client_socket_ptr);
void	send_response(int client_socket, const char *header, const char *body);
void	handle_post_request(const char *body);
void	handle_get_request(int client_socket, const char *path);
void	send_file(int client_socket, const char *file_path);
void	send_error(int client_socket, int error_code, const char *message);
void	send_file_content(int client_socket, FILE *file);
void	send_file_header(int client_socket, size_t content_length);

int	main(void)
{
	int					server_socket;
	int					client_socket;
	struct sockaddr_in	server_addr;
	struct sockaddr_in	client_addr;
	socklen_t			client_len;
	int					option;
	pthread_t			thread_id;

	client_len = sizeof(client_addr);
	option = 1;
	server_socket = socket(AF_INET, SOCK_STREAM, 0);
	if (server_socket < 0)
	{
		perror("Socket creation failed");
		exit(EXIT_FAILURE);
	}
	if (setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR, &option,
			sizeof(option)) < 0)
	{
		perror("setsockopt failed");
		close(server_socket);
		exit(EXIT_FAILURE);
	}
	server_addr.sin_family = AF_INET;
	server_addr.sin_addr.s_addr = INADDR_ANY;
	server_addr.sin_port = htons(PORT);
	if (bind(server_socket, (struct sockaddr *)&server_addr,
			sizeof(server_addr)) < 0)
	{
		perror("Bind failed");
		close(server_socket);
		exit(EXIT_FAILURE);
	}
	if (listen(server_socket, 5) < 0)
	{
		perror("Listen failed");
		close(server_socket);
		exit(EXIT_FAILURE);
	}
	printf("Servidor HTTP rodando na porta %d...\n", PORT);
	while (1)
	{
		client_socket = accept(server_socket, (struct sockaddr *)&client_addr,
				&client_len);
		if (client_socket < 0)
		{
			perror("Accept failed");
			continue;
		}
		if (pthread_create(&thread_id, NULL, handle_request,
				(void *)(intptr_t)client_socket) != 0)
		{
			perror("Failed to create thread");
			close(client_socket);
		}
		else
			pthread_detach(thread_id);
	}
	close(server_socket);
	return (0);
}

void	*handle_request(void *client_socket_ptr)
{
	int		client_socket;
	char	buffer[BUFFER_SIZE];
	int		bytes_received;

	client_socket = (intptr_t)client_socket_ptr;
	bytes_received = recv(client_socket, buffer, sizeof(buffer) - 1, 0);
	if (bytes_received <= 0)
	{
		close(client_socket);
		return (NULL);
	}
	buffer[bytes_received] = '\0';
	if (strncmp(buffer, "POST", 4) == 0)
		handle_post_request(buffer);
	else if (strncmp(buffer, "GET", 3) == 0)
		handle_get_request(client_socket, buffer);
	else
		send_error(client_socket, 405, "Method Not Allowed");
	close(client_socket);
	return (NULL);
}

void	handle_post_request(const char *body)
{
	char	*name_start;
	char	*message_start;
	char	name[256];
	char	message[8192];

	name_start = strstr(body, "name=");
	message_start = strstr(body, "&message=");
	if (!name_start || !message_start)
		return ;
	name_start += 5;
	message_start += 9;
	sscanf(name_start, "%255[^&]", name);
	sscanf(message_start, "%8191s", message);
	save_message(name, message);
}

void	save_message(const char *name, const char *message)
{
	FILE	*file;

	file = fopen(DATA_FILE, "a");
	if (file == NULL)
	{
		perror("Failed to open file");
		return ;
	}
	fprintf(file, "{\"name\":\"%s\", \"message\":\"%s\"},\n", name, message);
	fclose(file);
}

void	handle_get_request(int client_socket, const char *buffer)
{
	char	*path_start;
	char	*path_end;
	char	path[BUFFER_SIZE];

	path_start = strchr(buffer, ' ') + 1;
	path_end = strchr(path_start, ' ');
	if (path_end)
	{
		*path_end = '\0';
		strncpy(path, path_start, sizeof(path) - 1);
		path[sizeof(path) - 1] = '\0';
		handle_file_request(client_socket, path);
	}
	else
		send_error(client_socket, 400, "Bad Request");
}

void	handle_file_request(int client_socket, const char *path)
{
	if (strcmp(path, "/") == 0 || strcmp(path, "/index.html") == 0)
		send_file(client_socket, "./web_root/index.html");
	else if (strcmp(path, "/styles.css") == 0)
		send_file(client_socket, "./web_root/styles.css");
	else if (strcmp(path, "/script.js") == 0)
		send_file(client_socket, "./web_root/script.js");
	else if (strcmp(path, "/messages.txt") == 0)
		handle_data_file_request(client_socket);
	else
		send_error(client_socket, 404, "Not Found");
}

void	handle_data_file_request(int client_socket)
{
	FILE	*file;

	file = fopen(DATA_FILE, "r");
	if (file == NULL)
	{
		send_error(client_socket, 500, "Internal Server Error");
		return ;
	}
	send_file_content(client_socket, file);
	fclose(file);
}

void	send_file_content(int client_socket, FILE *file)
{
	char	file_content[BUFFER_SIZE];
	size_t	bytes_read;

	bytes_read = fread(file_content, 1, sizeof(file_content) - 1, file);
	file_content[bytes_read] = '\0';
	send_file_header(client_socket, bytes_read);
	send(client_socket, file_content, bytes_read, 0);
}

void	send_file_header(int client_socket, size_t content_length)
{
	char	header[BUFFER_SIZE];

	snprintf(header, sizeof(header), "HTTP/1.1 200 OK\r\n"
			"Content-Length: %zu\r\n"
			"Content-Type: text/html\r\n"
			"Access-Control-Allow-Origin: *\r\n"
			"Access-Control-Allow-Headers: Content-Type\r\n"
			"\r\n", content_length);
	send(client_socket, header, strlen(header), 0);
}

void	send_file(int client_socket, const char *file_path)
{
	FILE	*file;

	file = fopen(file_path, "r");
	if (file == NULL)
	{
		send_error(client_socket, 404, "Not Found");
		return ;
	}
	send_file_content(client_socket, file);
	fclose(file);
}

void	send_response(int client_socket, const char *header, const char *body)
{
	char	response[BUFFER_SIZE];

	snprintf(response, sizeof(response),
			"%s\r\n"
			"Access-Control-Allow-Origin: *\r\n"
			"Access-Control-Allow-Headers: Content-Type\r\n"
			"\r\n"
			"%s",
			header, body);
	send(client_socket, response, strlen(response), 0);
}

void	send_error(int client_socket, int error_code, const char *message)
{
	char	header[BUFFER_SIZE];
	char	body[BUFFER_SIZE];

	snprintf(header, sizeof(header), "HTTP/1.1 %d %s\r\n"
			"Content-Type: text/html\r\n"
			"Access-Control-Allow-Origin: *\r\n"
			"Access-Control-Allow-Headers: Content-Type\r\n"
			"\r\n", error_code, message);
	snprintf(body, sizeof(body), "<html><body><h1>%d %s</h1></body></html>",
			error_code, message);
	send_response(client_socket, header, body);
}

