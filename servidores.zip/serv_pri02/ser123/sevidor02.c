#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <pthread.h>
#include <errno.h>

#define PORT 8081
#define BUFFER_SIZE 8192
#define DATA_FILE "./web_root/messages.txt"
#define IMAGE_DIR "./web_root/images"

void	*handle_request(void *client_socket_ptr);
void	send_response(int client_socket, const char *header, const char *body);
void	handle_post_request(const char *body);
void	handle_get_request(int client_socket, const char *path);
void	save_image(const char *image_data, const char *filename);

void	send_response(int client_socket, const char *header, const char *body)
{
	char	response[BUFFER_SIZE];
	snprintf(response, sizeof(response),
		"%s\r\n"
		"Access-Control-Allow-Origin: *\r\n"
		"Access-Control-Allow-Headers: Content-Type\r\n"
		"\r\n%s",
		header, body);
	send(client_socket, response, strlen(response), 0);
}

int	main(void)
{
	int					server_socket;
	int					client_socket;
	struct sockaddr_in	server_addr;
	struct sockaddr_in	client_addr;
	socklen_t			client_len = sizeof(client_addr);
	int					option = 1;
	pthread_t			thread_id;

	server_socket = socket(AF_INET, SOCK_STREAM, 0);
	if (server_socket < 0)
	{
		perror("Socket creation failed");
		exit(EXIT_FAILURE);
	}
	if (setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR, &option,
			sizeof(option)) < 0)
	{
		perror("setsockopt failed");
		close(server_socket);
		exit(EXIT_FAILURE);
	}
	server_addr.sin_family = AF_INET;
	server_addr.sin_addr.s_addr = INADDR_ANY;
	server_addr.sin_port = htons(PORT);
	if (bind(server_socket, (struct sockaddr *)&server_addr,
			sizeof(server_addr)) < 0)
	{
		perror("Bind failed");
		close(server_socket);
		exit(EXIT_FAILURE);
	}
	if (listen(server_socket, 10) < 0)
	{
		perror("Listen failed");
		close(server_socket);
		exit(EXIT_FAILURE);
	}
	printf("Servidor HTTP rodando na porta %d...\n", PORT);
	while (1)
	{
		client_socket = accept(server_socket, (struct sockaddr *)&client_addr,
				&client_len);
		if (client_socket < 0)
		{
			perror("Accept failed");
			continue;
		}
		if (pthread_create(&thread_id, NULL, handle_request,
				(void *)(intptr_t)client_socket) != 0)
		{
			perror("Failed to create thread");
			close(client_socket);
		}
		else
			pthread_detach(thread_id);
	}
	close(server_socket);
	return (0);
}

void	*handle_request(void *client_socket_ptr)
{
	int		client_socket;
	char	buffer[BUFFER_SIZE];
	char	method[16];
	char	path[256];
	char	protocol[16];
	int		received;

	client_socket = (intptr_t)client_socket_ptr;
	received = recv(client_socket, buffer, sizeof(buffer) - 1, 0);
	if (received < 0)
	{
		perror("Failed to read request");
		close(client_socket);
		pthread_exit(NULL);
	}
	buffer[received] = '\0';
	sscanf(buffer, "%15s %255s %15s", method, path, protocol);
	if (strcmp(method, "GET") == 0)
		handle_get_request(client_socket, path);
	else if (strcmp(method, "POST") == 0 && strcmp(path, "/") == 0)
	{
		char	*body;

		body = strstr(buffer, "\r\n\r\n");
		if (body)
		{
			body += 4;
			handle_post_request(body);
			send_response(client_socket,
				"HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n",
				"Mensagem enviada com sucesso.");
		}
		else
			send_response(client_socket,
				"HTTP/1.1 400 Bad Request\r\nContent-Type: text/plain\r\n\r\n",
				"Corpo da mensagem inválido.");
	}
	else
		send_response(client_socket,
			"HTTP/1.1 404 Not Found\r\nContent-Type: text/plain\r\n\r\n",
			"404 Não Encontrado");
	close(client_socket);
	pthread_exit(NULL);
}

void	handle_get_request(int client_socket, const char *path)
{
	if (strcmp(path, "/") == 0)
	{
		FILE	*file;
		char	response[BUFFER_SIZE];
		size_t	bytes_read;

		file = fopen("./web_root/index.html", "r");
		if (file != NULL)
		{
			bytes_read = fread(response, 1, sizeof(response), file);
			while (bytes_read > 0)
			{
				send(client_socket, response, bytes_read, 0);
				bytes_read = fread(response, 1, sizeof(response), file);
			}
			fclose(file);
		}
		else
			send_response(client_socket,
				"HTTP/1.1 404 Not Found\r\nContent-Type: text/plain\r\n\r\n",
				"404 Not Found");
	}
	else if (strcmp(path, "/styles.css") == 0)
	{
		FILE	*file;
		char	response[BUFFER_SIZE];
		size_t	bytes_read;

		file = fopen("./web_root/styles.css", "r");
		if (file != NULL)
		{
			bytes_read = fread(response, 1, sizeof(response), file);
			while (bytes_read > 0)
			{
				send(client_socket, response, bytes_read, 0);
				bytes_read = fread(response, 1, sizeof(response), file);
			}
			fclose(file);
		}
		else
			send_response(client_socket,
				"HTTP/1.1 404 Not Found\r\nContent-Type: text/plain\r\n\r\n",
				"404 Not Found");
	}
	else if (strcmp(path, "/script.js") == 0)
	{
		FILE	*file;
		char	response[BUFFER_SIZE];
		size_t	bytes_read;

		file = fopen("./web_root/script.js", "r");
		if (file != NULL)
		{
			bytes_read = fread(response, 1, sizeof(response), file);
			while (bytes_read > 0)
			{
				send(client_socket, response, bytes_read, 0);
				bytes_read = fread(response, 1, sizeof(response), file);
			}
			fclose(file);
		}
		else
			send_response(client_socket,
				"HTTP/1.1 404 Not Found\r\nContent-Type: text/plain\r\n\r\n",
				"404 Not Found");
	}
	else if (strstr(path, "/images/") == path)
	{
		char	full_path[512];
		FILE	*file;
		char	response[BUFFER_SIZE];
		size_t	bytes_read;

		snprintf(full_path, sizeof(full_path), "./web_root%s", path);
		file = fopen(full_path, "rb");
		if (file != NULL)
		{
			bytes_read = fread(response, 1, sizeof(response), file);
			while (bytes_read > 0)
			{
				send(client_socket, response, bytes_read, 0);
				bytes_read = fread(response, 1, sizeof(response), file);
			}
			fclose(file);
		}
		else
			send_response(client_socket,
				"HTTP/1.1 404 Not Found\r\nContent-Type: text/plain\r\n\r\n",
				"404 Not Found");
	}
	else
		send_response(client_socket,
			"HTTP/1.1 404 Not Found\r\nContent-Type: text/plain\r\n\r\n",
			"404 Not Found");
}

void	handle_post_request(const char *body)
{
	char	*name_start;
	char	*email_start;
	char	*message_start;
	char	*image_start;
	char	name[256];
	char	email[256];
	char	message[8192];
	char	image[8192];
	FILE	*file;

	name_start = strstr(body, "name=");
	email_start = strstr(body, "&email=");
	message_start = strstr(body, "&message=");
	image_start = strstr(body, "&image=");
	if (!name_start || !email_start || !message_start)
		return;
	name_start += 5;
	email_start += 7;
	message_start += 9;
	if (image_start)
	{
		image_start += 7;
		sscanf(image_start, "%8191s", image);
	}
	else
		image[0] = '\0';
	sscanf(name_start, "%255[^&]", name);
	sscanf(email_start, "%255[^&]", email);
	sscanf(message_start, "%8191[^&]", message);

	file = fopen(DATA_FILE, "a");
	if (file == NULL)
	{
		perror("Failed to open file");
		return;
	}
	if (strlen(image) > 0)
	{
		char	image_filename[512];

		snprintf(image_filename, sizeof(image_filename), "%s/%s.png",
			IMAGE_DIR, email);
		save_image(image, image_filename);
		fprintf(file, "{\"name\":\"%s\", \"email\":\"%s\", \"message\":\"%s\", \"image\":\"%s\"},\n",
			name, email, message, image_filename);
	}
	else
		fprintf(file, "{\"name\":\"%s\", \"email\":\"%s\", \"message\":\"%s\", \"image\":\"N/A\"},\n",
			name, email, message);
	fclose(file);
}

void	save_image(const char *image_data, const char *filename)
{
	FILE	*file;
	size_t	data_len;

	file = fopen(filename, "wb");
	if (file == NULL)
	{
		perror("Failed to save image");
		return;
	}
	data_len = strlen(image_data);
	fwrite(image_data, 1, data_len, file);
	fclose(file);
}

