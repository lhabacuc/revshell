document.querySelector('#message-form').addEventListener('submit', function(e) {
    e.preventDefault();
    
    var formData = new FormData(this);
    var xhr = new XMLHttpRequest();
    
    xhr.open('POST', '/', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    
    xhr.onload = function() {
        if (xhr.status === 200) {
            alert('Mensagem enviada com sucesso!');
            loadMessages();
        } else {
            alert('Erro ao enviar a mensagem.');
        }
    };
    
    var data = new URLSearchParams(formData).toString();
    xhr.send(data);
});

function loadMessages() {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', '/messages', true);
    
    xhr.onload = function() {
        if (xhr.status === 200) {
            var messages = JSON.parse(xhr.responseText);
            var messagesDiv = document.querySelector('#messages');
            messagesDiv.innerHTML = '';
            
            messages.forEach(function(message) {
                var messageDiv = document.createElement('div');
                messageDiv.className = 'message';
                messageDiv.innerHTML = `<strong>${message.name} (${message.email}):</strong> <p>${message.message}</p>`;
                messagesDiv.appendChild(messageDiv);
            });
        } else {
            console.error('Erro ao carregar as mensagens.');
        }
    };
    
    xhr.send();
}

// Carregar mensagens ao carregar a página
window.onload = function() {
    loadMessages();
};

