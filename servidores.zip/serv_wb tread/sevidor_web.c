#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <pthread.h>

#define PORT 8080
#define BUFFER_SIZE 8192
#define DATA_FILE "./web_root/messages.txt"
#define IMAGE_DIR "./web_root/images"

void	*handle_request(void *client_socket_ptr);
void	send_response(int client_socket, const char *header, const char *body);
void	handle_post_request(const char *body);
void	save_image(const char *image_data, const char *filename);
void	extract_data(const char *body, char *name, char *email,
		char *message, char *image);
void	store_data(const char *name, const char *email, const char *message,
		const char *image_filename);

void	send_response(int client_socket, const char *header, const char *body)
{
	char	response[BUFFER_SIZE];

	snprintf(response, sizeof(response),
			"%s\r\n"
			"Access-Control-Allow-Origin: *\r\n"
			"Access-Control-Allow-Headers: Content-Type\r\n"
			"%s",
			header, body);
	send(client_socket, response, strlen(response), 0);
}

int	main(void)
{
	int					server_socket;
	int					client_socket;
	struct sockaddr_in	server_addr;
	struct sockaddr_in	client_addr;
	socklen_t			client_len;
	int					option;
	pthread_t			thread_id;

	client_len = sizeof(client_addr);
	option = 1;
	server_socket = socket(AF_INET, SOCK_STREAM, 0);
	if (server_socket < 0)
	{
		perror("Socket creation failed");
		exit(EXIT_FAILURE);
	}
	if (setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR, &option,
			sizeof(option)) < 0)
	{
		perror("setsockopt failed");
		close(server_socket);
		exit(EXIT_FAILURE);
	}
	server_addr.sin_family = AF_INET;
	server_addr.sin_addr.s_addr = INADDR_ANY;
	server_addr.sin_port = htons(PORT);
	if (bind(server_socket, (struct sockaddr *)&server_addr,
			sizeof(server_addr)) < 0)
	{
		perror("Bind failed");
		close(server_socket);
		exit(EXIT_FAILURE);
	}
	if (listen(server_socket, 5) < 0)
	{
		perror("Listen failed");
		close(server_socket);
		exit(EXIT_FAILURE);
	}
	printf("Servidor HTTP rodando na porta %d...\n", PORT);
	while (1)
	{
		client_socket = accept(server_socket, (struct sockaddr *)&client_addr,
				&client_len);
		if (client_socket < 0)
		{
			perror("Accept failed");
			continue;
		}
		if (pthread_create(&thread_id, NULL, handle_request,
				(void *)(intptr_t)client_socket) != 0)
		{
			perror("Failed to create thread");
			close(client_socket);
		}
		else
			pthread_detach(thread_id);
	}
	close(server_socket);
	return (0);
}

void	handle_post_request(const char *body)
{
	char	name[256];
	char	email[256];
	char	message[8192];
	char	image[8192];
	char	image_filename[512];

	extract_data(body, name, email, message, image);
	snprintf(image_filename, sizeof(image_filename), "%s/%s.png",
			IMAGE_DIR, email);
	save_image(image, image_filename);
	store_data(name, email, message, image_filename);
}

void	extract_data(const char *body, char *name, char *email,
		char *message, char *image)
{
	char	*name_start;
	char	*email_start;
	char	*message_start;
	char	*image_start;

	name_start = strstr(body, "name=");
	email_start = strstr(body, "&email=");
	message_start = strstr(body, "&message=");
	image_start = strstr(body, "&image=");
	if (!name_start || !email_start || !message_start)
		return ;
	name_start += 5;
	email_start += 7;
	message_start += 9;
	sscanf(name_start, "%255[^&]", name);
	sscanf(email_start, "%255[^&]", email);
	sscanf(message_start, "%8191[^&]", message);
	sscanf(image_start, "%8191s", image);
}

void	store_data(const char *name, const char *email, const char *message,
		const char *image_filename)
{
	FILE	*file;

	file = fopen(DATA_FILE, "a");
	if (file == NULL)
	{
		perror("Failed to open file");
		return ;
	}
	fprintf(file, "{\"name\":\"%s\", \"email\":\"%s\", \"message\":\"%s\", "
			"\"image\":\"%s\"},\n", name, email, message, image_filename);
	fclose(file);
}

void	save_image(const char *image_data, const char *filename)
{
	FILE	*file;

	file = fopen(filename, "wb");
	if (file == NULL)
	{
		perror("Failed to save image");
		return ;
	}
	fwrite(image_data, 1, strlen(image_data), file);
	fclose(file);
}

