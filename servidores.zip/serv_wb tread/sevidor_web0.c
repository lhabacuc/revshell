#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <pthread.h>

#define PORT 8080
#define BUFFER_SIZE 8192
#define WEB_ROOT "./web_root"
#define DATA_FILE "./web_root/contact_data.txt"

void	*handle_request(void *client_socket_ptr);
void	send_response(int client_socket, const char *header, const char *body);
void	handle_post_request(const char *body);

int	main(void)
{
	int					server_socket;
	int					client_socket;
	struct sockaddr_in	server_addr;
	struct sockaddr_in	client_addr;
	socklen_t			client_len;
	int					option;
	pthread_t			thread_id;

	client_len = sizeof(client_addr);
	option = 1;
	server_socket = socket(AF_INET, SOCK_STREAM, 0);
	if (server_socket < 0)
	{
		perror("Socket creation failed");
		exit(EXIT_FAILURE);
	}
	if (setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR, &option,
			sizeof(option)) < 0)
	{
		perror("setsockopt failed");
		close(server_socket);
		exit(EXIT_FAILURE);
	}
	server_addr.sin_family = AF_INET;
	server_addr.sin_addr.s_addr = INADDR_ANY;
	server_addr.sin_port = htons(PORT);
	if (bind(server_socket, (struct sockaddr *)&server_addr,
			sizeof(server_addr)) < 0)
	{
		perror("Bind failed");
		close(server_socket);
		exit(EXIT_FAILURE);
	}
	if (listen(server_socket, 5) < 0)
	{
		perror("Listen failed");
		close(server_socket);
		exit(EXIT_FAILURE);
	}
	printf("Servidor HTTP rodando na porta %d...\n", PORT);
	while (1)
	{
		client_socket = accept(server_socket, (struct sockaddr *)&client_addr,
				&client_len);
		if (client_socket < 0)
		{
			perror("Accept failed");
			continue;
		}
		if (pthread_create(&thread_id, NULL, handle_request,
				(void *)(intptr_t)client_socket) != 0)
		{
			perror("Failed to create thread");
			close(client_socket);
		}
		else
			pthread_detach(thread_id);
	}
	close(server_socket);
	return (0);
}

void	*handle_request(void *client_socket_ptr)
{
	int		client_socket;
	char	buffer[BUFFER_SIZE];
	int		bytes_read;
	char	method[16];
	char	path[256];
	char	version[16];
	char	full_path[512];
	int		file;

	client_socket = (int)(intptr_t)client_socket_ptr;
	bytes_read = read(client_socket, buffer, sizeof(buffer) - 1);
	if (bytes_read < 0)
	{
		perror("Read failed");
		close(client_socket);
		return (NULL);
	}
	buffer[bytes_read] = '\0';
	sscanf(buffer, "%s %s %s", method, path, version);
	if (strcmp(method, "POST") == 0)
	{
		char	*body;

		body = strstr(buffer, "\r\n\r\n");
		if (body != NULL)
		{
			body += 4;
			handle_post_request(body);
		}
		send_response(client_socket, "HTTP/1.1 200 OK\r\n",
				"Dados recebidos com sucesso");
		close(client_socket);
		return (NULL);
	}
	if (strcmp(method, "GET") != 0)
	{
		send_response(client_socket, "HTTP/1.1 405 Method Not Allowed\r\n",
				"Método não permitido");
		close(client_socket);
		return (NULL);
	}
	if (path[0] == '/')
		memmove(path, path + 1, strlen(path));
	snprintf(full_path, sizeof(full_path), "%s/%s", WEB_ROOT, path);
	if (strlen(full_path) == strlen(WEB_ROOT))
		snprintf(full_path, sizeof(full_path), "%s/index.html", WEB_ROOT);
	file = open(full_path, O_RDONLY);
	if (file < 0)
	{
		send_response(client_socket, "HTTP/1.1 404 Not Found\r\n",
				"Arquivo não encontrado");
		close(client_socket);
		return (NULL);
	}
	snprintf(buffer, sizeof(buffer),
			"HTTP/1.1 200 OK\r\n"
			"Content-Type: text/html\r\n"
			"Connection: close\r\n"
			"\r\n");
	send(client_socket, buffer, strlen(buffer), 0);
	while ((bytes_read = read(file, buffer, sizeof(buffer))) > 0)
		send(client_socket, buffer, bytes_read, 0);
	close(file);
	close(client_socket);
	return (NULL);
}

void	handle_post_request(const char *body)
{
	FILE	*file;

	file = fopen(DATA_FILE, "a");
	if (file == NULL)
	{
		perror("Failed to open file");
		return;
	}
	fprintf(file, "%s\n", body);
	fclose(file);
}

void	send_response(int client_socket, const char *header, const char *body)
{
	char	response[BUFFER_SIZE];

	snprintf(response, sizeof(response), "%s\r\n%s", header, body);
	send(client_socket, response, strlen(response), 0);
}

