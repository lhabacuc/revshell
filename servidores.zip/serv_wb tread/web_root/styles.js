function sendMessage() {
    const profileImage = document.getElementById('profile-image').files[0];
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;

    if (!name || !email || !message || !profileImage) {
        alert("Por favor, preencha todos os campos.");
        return;
    }

    const formData = new FormData();
    formData.append('profile_image', profileImage);
    formData.append('name', name);
    formData.append('email', email);
    formData.append('message', message);

    fetch(`${serverUrl}/send`, {
        method: 'POST',
        body: formData
    }).then(response => response.json())
      .then(data => {
          if (data.success) {
              displayMessage(data.message);
              document.getElementById('message').value = '';
          } else {
              alert("Erro ao enviar a mensagem.");
          }
      }).catch(error => {
          console.error('Error:', error);
      });
}

function displayMessage(msg) {
    const chatbox = document.getElementById('chatbox');
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('message');
    messageDiv.innerHTML = `
        <strong>${msg.name}</strong> <br>
        <img src="${msg.image}" alt="Profile Image" style="width:50px;height:50px;border-radius:50%;"> <br>
        ${msg.message}
    `;
    chatbox.appendChild(messageDiv);
    chatbox.scrollTop = chatbox.scrollHeight;
}

